import {
  useState,
  useMemo,
  useEffect,
  useRef,
  type Dispatch,
  type SetStateAction,
} from "react";
import "./App.css";
import { useReasoning } from "./engine/useReasoning";
import { analyzeEvidence } from "./engine/evidence";
import { compareEvents, rebuildStatus, isAliveAt, diedByExecution, seats } from "./engine/game";
import {
  eventId, loadSnapshot, saveSnapshot, loadCheckpoints, CHECKPOINT_KEY, SAVE_KEY,
  downloadSnapshot, validateSnapshot, deleteEventGroup, type LogKey,
  loadGameLogs, saveGameLogs, createGameLogEntry, updateGameLogEntry,
  downloadGameLogEntry, downloadGameLogs,
} from "./storage";
import { WarningBadges, PlayerSummary, AnalysisPanel, ManualReadForm, NominationCard, AdvicePanel, type AnalysisTab } from "./ui/ReasoningUI";
import { GameLogPanel } from "./ui/GameLogUI";
import { DemonModePanel } from "./ui/DemonModeUI";
import { MinionModePanel } from "./ui/MinionModeUI";
import { ReportedInfoForm } from "./ui/ReportedInfoForm";
import { L } from "./ui/text";
import {
  ROLES,
  type Role,
  type RoleId,
  type RoleTag,
  type RoleType,
} from "./roles";
import {
  ALL_CORE_ROLE_IDS,
  BUILT_IN_SCRIPTS,
  allScripts,
  createCustomScript,
  getScriptById,
  getSnapshotScriptName,
  getSnapshotScriptRoleIds,
  loadCustomScripts,
  saveCustomScripts,
  type ScriptDefinition,
} from "./scripts";

import type { Screen, ClaimVisibility, RoleClaimType, ClaimSubjectKind, ClaimableRoleTag, ClaimSubject, RoleClaimEvent, AbilityClaimEvent, PlayerStatus, DeathReasonId, DeathEvent, RevivalEvent, DeathReasonDefinition, NominationEvent, TalkTopic, TalkEvent, AbilityTriggerEvent, TriggerDraft, SelfRoleState, SelfInfoEvent, SelfActionEvent, DemonState, DemonActionEvent, MinionState, MinionActionEvent, PlayerPanel, SelfPanel, ManualRead, GameSnapshot, GameLogEntry, GameLogOutcome } from "./types";

const LEFT_PLAYERS = ["7L", "6L", "5L", "4L", "3L", "2L", "1L"];
const RIGHT_PLAYERS = ["7R", "6R", "5R", "4R", "3R", "2R", "1R"];
const ALL_PLAYERS = [...LEFT_PLAYERS, ...RIGHT_PLAYERS];

const CLAIMABLE_ROLE_TAGS: ClaimableRoleTag[] = [
  "FIRST_NIGHT_INFO",
  "CONTINUOUS_INFO",
  "LACK_OF_INFO",
  "WANTS_DEMON_TARGET",
  "HIGH_SURVIVAL_VALUE",
];

const CLAIMABLE_TAG_LABELS: Record<ClaimableRoleTag, string> = {
  FIRST_NIGHT_INFO: "初夜情報",
  CONTINUOUS_INFO: "継続情報",
  LACK_OF_INFO: "情報なし",
  WANTS_DEMON_TARGET: "デーモンに狙われたい",
  HIGH_SURVIVAL_VALUE: "生存価値が高い",
};

const CLAIMABLE_TAG_SYMBOLS: Record<ClaimableRoleTag, string> = {
  FIRST_NIGHT_INFO: "初",
  CONTINUOUS_INFO: "継",
  LACK_OF_INFO: "無",
  WANTS_DEMON_TARGET: "狙",
  HIGH_SURVIVAL_VALUE: "存",
};

const DEATH_REASONS: DeathReasonDefinition[] = [
  { id: "storyteller", label: "ストーリーテラー", phase: "any" },
  { id: "execution", label: "処刑", phase: "day" },
  { id: "night_death", label: "夜死亡", phase: "night" },
  { id: "ability", label: "能力", phase: "any" },
  { id: "other", label: "その他", phase: "any" },
];

const TALK_TOPIC_LABELS: Record<TalkTopic, string> = {
  role_claim: "役職",
  ability_claim: "能力",
  info: "情報",
  strategy: "作戦",
  other: "その他",
};

const STRUCTURED_INFO_ROLES: RoleId[] = [
  "washerwoman",
  "librarian",
  "investigator",
  "chef",
  "empath",
  "fortune_teller",
  "undertaker",
  "ravenkeeper",
];

function isStructuredInfoRole(roleId: RoleId | null | undefined): roleId is RoleId {
  return !!roleId && STRUCTURED_INFO_ROLES.includes(roleId);
}

function makeEmptyNames(): Record<string, string> {
  return Object.fromEntries(ALL_PLAYERS.map((player) => [player, ""])) as Record<
    string,
    string
  >;
}

function makeInitialStatus(): Record<string, PlayerStatus> {
  return Object.fromEntries(
    ["self", ...ALL_PLAYERS].map((player) => [
      player,
      { alive: true, deadVoteAvailable: true },
    ])
  ) as Record<string, PlayerStatus>;
}

function makeEmptyDemonState(): DemonState {
  return { knownMinions: [], storytellerBluffs: [], bluffPlans: {} };
}

function makeEmptyMinionState(): MinionState {
  return {
    knownDemon: null,
    knownMinions: [],
    sharedStorytellerBluffs: [],
    bluffPlans: {},
    spyInitialRoles: {},
    spyRedHerring: null,
    becameDemonAt: null,
  };
}

function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [playerCount, setPlayerCount] = useState(15);
  const [playset, setPlayset] = useState("trouble_brewing");
  const [night, setNight] = useState(1);
  const [menuOpen, setMenuOpen] = useState(false);
  const [endGameOpen, setEndGameOpen] = useState(false);
  const [customScripts, setCustomScripts] = useState<ScriptDefinition[]>(loadCustomScripts);
  const [scriptManagerOpen, setScriptManagerOpen] = useState(false);
  const [scriptEditorOpen, setScriptEditorOpen] = useState(false);
  const [scriptEditorId, setScriptEditorId] = useState<string | null>(null);
  const [scriptEditorReadOnly, setScriptEditorReadOnly] = useState(false);
  const [scriptEditorRoles, setScriptEditorRoles] = useState<RoleId[]>([]);
  const [gameScriptName, setGameScriptName] = useState(BUILT_IN_SCRIPTS[0].name);
  const [gameScriptRoleIds, setGameScriptRoleIds] = useState<RoleId[]>([...BUILT_IN_SCRIPTS[0].roleIds]);

  // Player menu / identity
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);
  const [playerPanel, setPlayerPanel] = useState<PlayerPanel>("menu");
  const [playerNames, setPlayerNames] = useState<Record<string, string>>(
    makeEmptyNames
  );
  const [pendingPlayerName, setPendingPlayerName] = useState("");

  // Role claims, including broad tag/category claims
  const [roleClaimLog, setRoleClaimLog] = useState<RoleClaimEvent[]>([]);
  const [claimSubjectKind, setClaimSubjectKind] =
    useState<ClaimSubjectKind>("role");
  const [pendingClaimRole, setPendingClaimRole] = useState<RoleId | null>(null);
  const [pendingClaimTag, setPendingClaimTag] =
    useState<ClaimableRoleTag | null>(null);
  const [roleClaimType, setRoleClaimType] =
    useState<RoleClaimType>("normal");
  const [claimVisibility, setClaimVisibility] =
    useState<ClaimVisibility>("public");
  const [claimRecipients, setClaimRecipients] = useState<string[]>([]);
  const [claimWhen, setClaimWhen] = useState("D1");

  // Ability claims are social statements, not mechanical triggers.
  const [abilityClaimLog, setAbilityClaimLog] = useState<AbilityClaimEvent[]>([]);
  const [abilityClaimRole, setAbilityClaimRole] = useState<RoleId | null>(null);
  const [abilityClaimWhen, setAbilityClaimWhen] = useState("D1");
  const [abilityClaimTargets, setAbilityClaimTargets] = useState<string[]>([]);
  const [abilityClaimResult, setAbilityClaimResult] = useState("");
  const [abilityClaimVisibility, setAbilityClaimVisibility] =
    useState<ClaimVisibility>("public");
  const [abilityClaimRecipients, setAbilityClaimRecipients] = useState<string[]>(
    []
  );

  // Status / death
  const [playerStatus, setPlayerStatus] = useState<Record<string, PlayerStatus>>(
    makeInitialStatus
  );
  const [deathLog, setDeathLog] = useState<DeathEvent[]>([]);
  const [revivalLog, setRevivalLog] = useState<RevivalEvent[]>([]);
  const [pendingDeathReason, setPendingDeathReason] =
    useState<DeathReasonId>("night_death");
  const [deathWhen, setDeathWhen] = useState("N1");

  // Nominations / votes
  const [nominationLog, setNominationLog] = useState<NominationEvent[]>([]);
  const [pendingNominee, setPendingNominee] = useState<string | null>(null);
  const [pendingVoters, setPendingVoters] = useState<string[]>([]);
  const [nominationWhen, setNominationWhen] = useState("D1");

  // Mechanical ability trigger events: currently Virgin + Slayer.
  const [abilityTriggerLog, setAbilityTriggerLog] = useState<
    AbilityTriggerEvent[]
  >([]);
  const [triggerDraft, setTriggerDraft] = useState<TriggerDraft | null>(null);

  // Conversation graph
  const [talkLog, setTalkLog] = useState<TalkEvent[]>([]);
  const [talkParticipants, setTalkParticipants] = useState<string[]>([]);
  const [talkWhen, setTalkWhen] = useState("D1");
  const [talkTopic, setTalkTopic] = useState<TalkTopic | null>(null);
  const [talkDetails, setTalkDetails] = useState("");

  // Self role / information / actions. Townsfolk first.
  const [selfMenuOpen, setSelfMenuOpen] = useState(false);
  const [selfPanel, setSelfPanel] = useState<SelfPanel>("menu");
  const [selfRole, setSelfRole] = useState<SelfRoleState>({ shownRole: null });
  const [pendingSelfRole, setPendingSelfRole] = useState<RoleId | null>(null);
  const [selfInfoLog, setSelfInfoLog] = useState<SelfInfoEvent[]>([]);
  const [selfInfoWhen, setSelfInfoWhen] = useState("N1");
  const [selfInfoPlayers, setSelfInfoPlayers] = useState<string[]>([]);
  const [selfInfoShownRole, setSelfInfoShownRole] =
    useState<RoleId | null>(null);
  const [selfInfoNumber, setSelfInfoNumber] = useState<number | null>(null);
  const [selfInfoYesNo, setSelfInfoYesNo] = useState<"yes" | "no" | null>(null);
  const [librarianNoOutsiders, setLibrarianNoOutsiders] = useState(false);
  const [selfActionLog, setSelfActionLog] = useState<SelfActionEvent[]>([]);
  const [selfActionTarget, setSelfActionTarget] = useState<string | null>(null);
  const [selfActionWhen, setSelfActionWhen] = useState("N2");
  const [selfSlayerKilled, setSelfSlayerKilled] = useState(false);
  const [demonState, setDemonState] = useState<DemonState>(makeEmptyDemonState);
  const [demonActionLog, setDemonActionLog] = useState<DemonActionEvent[]>([]);
  const [minionState, setMinionState] = useState<MinionState>(makeEmptyMinionState);
  const [minionActionLog, setMinionActionLog] = useState<MinionActionEvent[]>([]);

  const [manualReads, setManualReads] = useState<Record<string, ManualRead>>({});
  const [completedNights, setCompletedNights] = useState<number[]>([]);
  const [noExecutionDays, setNoExecutionDays] = useState<number[]>([]);
  const [analysisOpen, setAnalysisOpen] = useState(false);
  const [analysisPlayer, setAnalysisPlayer] = useState<string | null>(null);
  const [analysisInitialTab, setAnalysisInitialTab] = useState<AnalysisTab>("overview");
  const [gameLogOpen, setGameLogOpen] = useState(false);
  const [gameLogs, setGameLogs] = useState<GameLogEntry[]>(loadGameLogs);
  const [pendingType, setPendingType] = useState<RoleType>("townsfolk");
  const [pendingAlignment, setPendingAlignment] = useState<"good" | "evil">("good");
  const [nominationReason, setNominationReason] = useState("");
  const [virginResult, setVirginResult] = useState<boolean | null>(null);
  const [savedGame, setSavedGame] = useState<GameSnapshot | null>(loadSnapshot);
  const [saveFailed, setSaveFailed] = useState(false);
  const [checkpoints, setCheckpoints] = useState<GameSnapshot[]>(loadCheckpoints);
  const importRef = useRef<HTMLInputElement>(null);
  const snapshot = useMemo<GameSnapshot>(() => ({
    schemaVersion: 2, playerCount, playset, scriptName: gameScriptName, scriptRoleIds: gameScriptRoleIds, night, playerNames, playerStatus,
    roleClaimLog, abilityClaimLog, deathLog, revivalLog, nominationLog, abilityTriggerLog,
    talkLog, selfRole, selfInfoLog, selfActionLog, demonState, demonActionLog,
    minionState, minionActionLog, manualReads,
    completedNights, noExecutionDays,
  }), [playerCount, playset, gameScriptName, gameScriptRoleIds, night, playerNames, playerStatus, roleClaimLog,
    abilityClaimLog, deathLog, revivalLog, nominationLog, abilityTriggerLog, talkLog,
    selfRole, selfInfoLog, selfActionLog, demonState, demonActionLog,
    minionState, minionActionLog, manualReads, completedNights, noExecutionDays]);
  const reasoning = useReasoning(snapshot, screen === "game");
  const analysis = useMemo(() => analyzeEvidence(snapshot, reasoning.result), [snapshot, reasoning.result]);
  useEffect(() => {
    if (screen !== "game") return;
    const timer = setTimeout(() => setSaveFailed(!saveSnapshot(snapshot)), 150);
    return () => clearTimeout(timer);
  }, [snapshot, screen]);
  useEffect(() => {
    try { localStorage.setItem(CHECKPOINT_KEY, JSON.stringify(checkpoints)); }
    catch { setSaveFailed(true); }
  }, [checkpoints]);

  function applySnapshot(g: GameSnapshot) {
    setPlayerCount(g.playerCount); setPlayset(g.playset); setGameScriptName(getSnapshotScriptName(g)); setGameScriptRoleIds([...getSnapshotScriptRoleIds(g)]); setNight(g.night);
    setPlayerNames({...makeEmptyNames(), ...g.playerNames});
    setPlayerStatus({...makeInitialStatus(), ...rebuildStatus(g)});
    setRoleClaimLog(g.roleClaimLog); setAbilityClaimLog(g.abilityClaimLog);
    setDeathLog(g.deathLog); setRevivalLog(g.revivalLog ?? []); setNominationLog(g.nominationLog);
    setAbilityTriggerLog(g.abilityTriggerLog); setTalkLog(g.talkLog);
    setSelfRole(g.selfRole); setSelfInfoLog(g.selfInfoLog); setSelfActionLog(g.selfActionLog);
    setDemonState(g.demonState ?? makeEmptyDemonState()); setDemonActionLog(g.demonActionLog ?? []);
    setMinionState(g.minionState ?? makeEmptyMinionState()); setMinionActionLog(g.minionActionLog ?? []);
    setManualReads(g.manualReads); setCompletedNights(g.completedNights);
    setNoExecutionDays(g.noExecutionDays);
  }

  function openAnalysis(player: string | null = null, initialTab: AnalysisTab = "overview") {
    setAnalysisPlayer(player);
    setAnalysisInitialTab(initialTab);
    setAnalysisOpen(true);
  }

  function persistGameLogs(next: GameLogEntry[]) {
    const sorted = [...next].sort((a, b) => b.savedAt - a.savedAt).slice(0, 40);
    const ok = saveGameLogs(sorted);
    if (!ok) setSaveFailed(true);
    setGameLogs(sorted);
    return ok;
  }

  function archiveCurrentGame(status: "snapshot" | "finished", outcome: GameLogOutcome = "unknown") {
    const entry = { ...createGameLogEntry(snapshot, reasoning.result, status), outcome };
    const ok = persistGameLogs([entry, ...gameLogs]);
    if (ok && status === "snapshot") window.alert("現在のゲームをログに保存しました。");
    return ok;
  }

  function updateArchivedGame(id: string, patch: Partial<Pick<GameLogEntry, "label" | "note" | "outcome" | "status">>) {
    persistGameLogs(updateGameLogEntry(gameLogs, id, patch));
  }

  function deleteArchivedGame(id: string) {
    persistGameLogs(gameLogs.filter(log => log.id !== id));
  }

  function loadArchivedGame(log: GameLogEntry, openWorlds: boolean) {
    if (screen === "game" && !window.confirm("現在のゲームをログの内容で置き換えますか？")) return;
    applySnapshot(log.game);
    setCheckpoints([]);
    setSavedGame(log.game);
    saveSnapshot(log.game);
    setMenuOpen(false);
    setGameLogOpen(false);
    setSelectedPlayer(null);
    setSelfMenuOpen(false);
    setScreen("game");
    if (openWorlds) openAnalysis(null, "worlds");
  }

  function deleteHistory(key: LogKey, id: number) {
    applySnapshot(deleteEventGroup(snapshot, key, id));
  }

  function confirmDeleteHistory(key: LogKey, id: number, label = "この記録") {
    if (!window.confirm(`${label}を削除しますか？\n連動して作られた記録も一緒に削除されます。`)) return;
    deleteHistory(key, id);
  }

  function setCompleteness(n: number, kind: "night" | "day", value: boolean) {
    if (kind === "day" && value && deathLog.some(d => d.when === `D${n}` && diedByExecution(d))) {
      window.alert("\u3053\u306e\u65e5\u306e\u51e6\u5211\u304c\u8a18\u9332\u3055\u308c\u3066\u3044\u307e\u3059\u3002"); return;
    }
    const setter = kind === "night" ? setCompletedNights : setNoExecutionDays;
    setter(current => value ? [...new Set([...current,n])] : current.filter(k => k !== n));
  }

  async function importGame(file: File | undefined) {
    if (!file) return;
    try {
      if (file.size > 3000000) throw new Error("File too large");
      const parsed: unknown = JSON.parse(await file.text());
      if (!validateSnapshot(parsed)) throw new Error("Invalid game format");
      if (screen === "game" && !window.confirm("\u73fe\u5728\u306e\u8a18\u9332\u3092\u8aad\u307f\u8fbc\u3093\u3060\u30b2\u30fc\u30e0\u3067\u7f6e\u304d\u63db\u3048\u307e\u3059\u304b\uff1f")) return;
      applySnapshot(parsed); setCheckpoints([]); setMenuOpen(false); setSelectedPlayer(null);
      setSelfMenuOpen(false); setSavedGame(parsed); setScreen("game");
    } catch { window.alert("\u8aad\u307f\u8fbc\u3081\u307e\u305b\u3093\u3002\u3053\u306e\u30d0\u30fc\u30b8\u30e7\u30f3\u306eJSON\u30b2\u30fc\u30e0\u8a18\u9332\u3092\u9078\u3093\u3067\u304f\u3060\u3055\u3044\u3002"); }
    if (importRef.current) importRef.current.value = "";
  }

  function saveReportedInfo(event: AbilityClaimEvent) {
    setAbilityClaimLog(xs => [...xs,event]);
    if ((!event.sourcePlayerId || event.sourcePlayerId === event.playerId) && !hasExactRoleClaim(event.playerId)) {
      setRoleClaimLog(xs => [...xs, {
        id: event.id+1, sourceEventId: event.id, playerId: event.playerId,
        subject:{kind:"role",roleId:event.roleId}, claimType:"normal",origin:"ability_claim",
        when:event.reportedWhen ?? event.when, visibility:event.visibility,recipients:event.recipients,
      }]);
    }
    returnFromPlayerPanel();
  }

  function needsVirginCheck(target: string | null, when: string) {
    if (!target) return false;
    const claimed = target === "self" ? selfRole.shownRole : getLatestExactRoleClaim(target);
    return claimed === "virgin" && !nominationLog.some(n => n.nominee === target && compareEvents(n,{when,id:Infinity}) < 0);
  }

  const otherPlayerCount = playerCount - 1;
  const activeLeftCount = Math.ceil(otherPlayerCount / 2);
  const activeRightCount = Math.floor(otherPlayerCount / 2);

  const currentScriptRoleIds = gameScriptRoleIds;
  const currentScriptRoles = currentScriptRoleIds.map((roleId) => ROLES[roleId]).filter(Boolean);
  const currentScriptHasReviver = currentScriptRoles.some((role) => role.tags.includes("REVIVES"));

  const activeClaimableTags = CLAIMABLE_ROLE_TAGS.filter((tag) =>
    currentScriptRoles.some((role) => role.tags.includes(tag))
  );

  function isPlayerActive(player: string) {
    const seatNumber = Number.parseInt(player, 10);

    if (player.endsWith("L")) {
      return seatNumber <= activeLeftCount;
    }

    return seatNumber <= activeRightCount;
  }

  function getActivePlayers() {
    return ALL_PLAYERS.filter((player) => isPlayerActive(player));
  }

  function getPhaseOptions() {
    const options: string[] = [];

    for (let i = 1; i <= night; i += 1) {
      options.push(`N${i}`);
      options.push(`D${i}`);
    }

    return options;
  }

  function getDayOptions() {
    return getPhaseOptions().filter((phase) => phase.startsWith("D"));
  }

  function getNightOptions(startAt = 1) {
    return getPhaseOptions().filter((phase) => {
      if (!phase.startsWith("N")) {
        return false;
      }

      return Number.parseInt(phase.slice(1), 10) >= startAt;
    });
  }

  function togglePlayerInList(
    player: string,
    setList: Dispatch<SetStateAction<string[]>>
  ) {
    setList((current) =>
      current.includes(player)
        ? current.filter((item) => item !== player)
        : [...current, player]
    );
  }

  function toggleLimitedSelfInfoPlayer(player: string, max: number) {
    setSelfInfoPlayers((current) => {
      if (current.includes(player)) {
        return current.filter((item) => item !== player);
      }

      if (current.length >= max) {
        return current;
      }

      return [...current, player];
    });
  }

  function getPlayerDisplayName(player: string) {
    if (player === "self") {
      return "自分";
    }

    const name = playerNames[player];
    return name ? `${name} (${player})` : player;
  }

  function getClockwiseVoteOrder(nominee: string): string[] {
    const order = seats(playerCount);
    const index = order.indexOf(nominee);
    if (index < 0) return order;
    // The Storyteller sweeps clockwise and returns to the nominee, so the
    // nominee is shown last in the voting controls.
    return [...order.slice(index + 1), ...order.slice(0, index + 1)];
  }

  function formatStructuredClaim(claim: AbilityClaimEvent): string {
    const data = claim.structured;
    if (!data) {
      if (claim.result) return claim.result;
      return isStructuredInfoRole(claim.roleId)
        ? "旧形式・詳細なし（取り消して「情報を記録」から再入力）"
        : "内容未記録";
    }
    if (data.kind === "number") return String(data.value);
    if (data.kind === "pairRole") {
      return `${data.players.map(getPlayerDisplayName).join(" / ")} → ${ROLES[data.shownRole].symbol} ${ROLES[data.shownRole].name}`;
    }
    if (data.kind === "noOutsiders") return "アウトサイダーなし";
    if (data.kind === "pairYesNo") {
      return `${data.players.map(getPlayerDisplayName).join(" / ")} → ${data.result === "yes" ? "YES" : "NO"}`;
    }
    if (data.kind === "roleReveal") {
      return `${getPlayerDisplayName(data.player)} → ${ROLES[data.shownRole].symbol} ${ROLES[data.shownRole].name}`;
    }
    return getPlayerDisplayName(data.target);
  }

  function formatSelfInfoEvent(event: SelfInfoEvent): string {
    if (event.roleId === "washerwoman" || event.roleId === "investigator") {
      return `${event.players.map(getPlayerDisplayName).join(" / ")} → ${ROLES[event.shownRole].symbol} ${ROLES[event.shownRole].name}`;
    }
    if (event.roleId === "librarian") {
      if (event.noOutsiders) return "アウトサイダーなし";
      if (event.players && event.shownRole) {
        return `${event.players.map(getPlayerDisplayName).join(" / ")} → ${ROLES[event.shownRole].symbol} ${ROLES[event.shownRole].name}`;
      }
      return "詳細なし";
    }
    if (event.roleId === "chef" || event.roleId === "empath") return String(event.number);
    if (event.roleId === "fortune_teller") {
      return `${event.players.map(getPlayerDisplayName).join(" / ")} → ${event.result === "yes" ? "YES" : "NO"}`;
    }
    if (event.roleId === "undertaker" || event.roleId === "ravenkeeper") {
      return `${getPlayerDisplayName(event.player)} → ${ROLES[event.shownRole].symbol} ${ROLES[event.shownRole].name}`;
    }
    return "詳細なし";
  }

  function getLatestClaim(playerId: string): RoleClaimEvent | null {
    return roleClaimLog.filter(c => c.playerId === playerId).sort(compareEvents).at(-1) ?? null;
  }

  function getLatestExactRoleClaim(playerId: string): RoleId | null {
    if (playerId === "self") return selfRole.shownRole;
    const claim = roleClaimLog.filter(c => c.playerId === playerId && c.subject.kind === "role").sort(compareEvents).at(-1);
    return claim?.subject.kind === "role" ? claim.subject.roleId : null;
  }

  function hasExactRoleClaim(playerId: string) {
    return getLatestExactRoleClaim(playerId) !== null;
  }

  function getClaimSymbol(claim: RoleClaimEvent | null): string {
    if (!claim) return "?";
    const s = claim.subject;
    if (s.kind === "role") return ROLES[s.roleId].symbol;
    if (s.kind === "tag") return CLAIMABLE_TAG_SYMBOLS[s.tag];
    if (s.kind === "type") return {townsfolk:"\u753a",outsider:"\u5916",minion:"\u624b",demon:"\u9b54"}[s.roleType];
    return s.alignment === "good" ? L.good : L.evil;
  }

  function getClaimLabel(claim: RoleClaimEvent | null): string {
    if (!claim) return L.none;
    const s = claim.subject;
    if (s.kind === "role") return `${ROLES[s.roleId].symbol} ${ROLES[s.roleId].name}`;
    if (s.kind === "tag") return `${CLAIMABLE_TAG_SYMBOLS[s.tag]} ${CLAIMABLE_TAG_LABELS[s.tag]}`;
    if (s.kind === "type") return L.nominalTypes[["townsfolk","outsider","minion","demon"].indexOf(s.roleType)];
    return L[s.alignment];
  }

  function formatAudience(
    visibility: ClaimVisibility,
    recipients: string[]
  ) {
    if (visibility === "public") {
      return "公開";
    }

    if (recipients.length === 0) {
      return "非公開 → 相手未記録";
    }

    return `非公開 → ${recipients.map(getPlayerDisplayName).join("・")}`;
  }

  function getDeathReasonLabel(reasonId: DeathReasonId) {
    return DEATH_REASONS.find((reason) => reason.id === reasonId)?.label ?? reasonId;
  }

  function getDeathPhaseOptions(reasonId: DeathReasonId) {
    const reason = DEATH_REASONS.find((item) => item.id === reasonId);
    const phases = getPhaseOptions();

    if (reason?.phase === "day") {
      return phases.filter((phase) => phase.startsWith("D"));
    }

    if (reason?.phase === "night") {
      return phases.filter((phase) => phase.startsWith("N"));
    }

    return phases;
  }

  function getSelfInfoNightOptions(roleId: RoleId) {
    if (
      roleId === "washerwoman" ||
      roleId === "librarian" ||
      roleId === "investigator" ||
      roleId === "chef"
    ) {
      return ["N1"];
    }

    if (roleId === "undertaker" || roleId === "ravenkeeper") {
      return getNightOptions(2);
    }

    return getNightOptions(1);
  }

  function getSelfInfoRoleOptions(roleId: RoleId): Role[] {
    if (roleId === "washerwoman") {
      return currentScriptRoles.filter((role) => role.type === "townsfolk");
    }

    if (roleId === "librarian") {
      return currentScriptRoles.filter((role) => role.type === "outsider");
    }

    if (roleId === "investigator") {
      return currentScriptRoles.filter((role) => role.type === "minion");
    }

    return currentScriptRoles;
  }

  function getPossibleHiddenSelfRoles(shownRoleId: RoleId) {
    const shownType = ROLES[shownRoleId].type;

    const tagByType: Record<string, RoleTag> = {
      townsfolk: "THINKS_TOWNSFOLK",
      outsider: "THINKS_OUTSIDER",
      minion: "THINKS_MINION",
      demon: "THINKS_DEMON",
    };

    const hiddenTag = tagByType[shownType];

    return currentScriptRoles.filter((role) => role.tags.includes(hiddenTag));
  }

  function resetClaimForm() {
    setClaimSubjectKind("role");
    setPendingClaimRole(null);
    setPendingClaimTag(null);
    setRoleClaimType("normal");
    setClaimVisibility("public");
    setClaimRecipients([]);
    setClaimWhen(`D${night}`);
  }

  function resetAbilityClaimForm() {
    setAbilityClaimRole(null);
    setAbilityClaimWhen(`D${night}`);
    setAbilityClaimTargets([]);
    setAbilityClaimResult("");
    setAbilityClaimVisibility("public");
    setAbilityClaimRecipients([]);
  }

  function resetNominationForm() {
    setPendingNominee(null);
    setPendingVoters([]);
    setVirginResult(null);
    setNominationReason("");
    setNominationWhen(`D${night}`);
  }

  function resetTalkForm() {
    setTalkParticipants([]);
    setTalkWhen(`D${night}`);
    setTalkTopic(null);
    setTalkDetails("");
  }

  function resetSelfInfoForm() {
    setSelfInfoWhen("N1");
    setSelfInfoPlayers([]);
    setSelfInfoShownRole(null);
    setSelfInfoNumber(null);
    setSelfInfoYesNo(null);
    setLibrarianNoOutsiders(false);
  }

  function resetSelfActionForm() {
    setSelfActionTarget(null);
    setSelfActionWhen("N2");
    setSelfSlayerKilled(false);
  }

  function resetGameData() {
    setNight(1);
    setManualReads({}); setCompletedNights([]); setNoExecutionDays([]);
    setCheckpoints([]); setAnalysisOpen(false); setSavedGame(null);
    setMenuOpen(false);
    setSelectedPlayer(null);
    setPlayerPanel("menu");
    setPlayerNames(makeEmptyNames());
    setPendingPlayerName("");
    setRoleClaimLog([]);
    resetClaimForm();
    setAbilityClaimLog([]);
    resetAbilityClaimForm();
    setPlayerStatus(makeInitialStatus());
    setDeathLog([]);
    setRevivalLog([]);
    setPendingDeathReason("night_death");
    setDeathWhen("N1");
    setNominationLog([]);
    resetNominationForm();
    setAbilityTriggerLog([]);
    setTriggerDraft(null);
    setTalkLog([]);
    resetTalkForm();
    setSelfMenuOpen(false);
    setSelfPanel("menu");
    setSelfRole({ shownRole: null });
    setPendingSelfRole(null);
    setSelfInfoLog([]);
    resetSelfInfoForm();
    setSelfActionLog([]);
    resetSelfActionForm();
    setDemonState(makeEmptyDemonState());
    setDemonActionLog([]);
    setMinionState(makeEmptyMinionState());
    setMinionActionLog([]);
  }

  function startGame() {
    const selected = getScriptById(playset, customScripts) ?? BUILT_IN_SCRIPTS[0];
    const counts = { townsfolk: 0, outsider: 0, minion: 0, demon: 0 };
    for (const roleId of selected.roleIds) counts[ROLES[roleId].type] += 1;
    if (counts.townsfolk === 0 || counts.minion === 0 || counts.demon === 0) {
      if (!window.confirm("このスクリプトは標準ゲームに必要な役職タイプが不足しています。\nそれでも開始しますか？")) return;
    }
    setGameScriptName(selected.name);
    setGameScriptRoleIds([...selected.roleIds]);
    resetGameData();
    setScreen("game");
  }

  function confirmNextNight() {
    if (night >= 99) return;
    if (!window.confirm(`\u7b2c${night + 1}\u591c\u306b\u9032\u307f\u307e\u3059\u304b\uff1f`)) return;
    setCheckpoints(xs => [...xs,snapshot].slice(-20));
    setNight(n => n+1);
  }

  function confirmUndoNight() {
    if (night <= 1 || checkpoints.length === 0) return;
    if (!window.confirm("\u524d\u306e\u591c\u306b\u623b\u3057\u307e\u3059\u304b\uff1f\n\u591c\u3092\u9032\u3081\u305f\u5f8c\u306e\u5165\u529b\u30fb\u4fee\u6b63\u3082\u5143\u306b\u623b\u308a\u307e\u3059\u3002")) return;
    const previous = checkpoints[checkpoints.length-1];
    applySnapshot(previous); setCheckpoints(xs => xs.slice(0,-1));
    setMenuOpen(false); setSelectedPlayer(null); setSelfMenuOpen(false);
  }

  function confirmEndGame() {
    setMenuOpen(false);
    setEndGameOpen(true);
  }

  function finishCurrentGame(outcome: Exclude<GameLogOutcome, "unknown">) {
    const logSaved = archiveCurrentGame("finished", outcome);
    if (!logSaved) {
      setSaveFailed(true);
      window.alert("ゲームログを保存できませんでした。終了を中止します。");
      return;
    }

    try {
      localStorage.removeItem(SAVE_KEY);
      localStorage.removeItem(CHECKPOINT_KEY);
    } catch {
      setSaveFailed(true);
    }

    setSavedGame(null);
    setCheckpoints([]);
    setEndGameOpen(false);
    setSelectedPlayer(null);
    setSelfMenuOpen(false);
    setAnalysisOpen(false);
    setScreen("home");
  }
  function openPlayerMenu(player: string) {
    setSelectedPlayer(player);
    setPlayerPanel("menu");
  }

  function openClaimPanel() {
    resetClaimForm();
    setPlayerPanel("claim");
  }

  function openAbilityClaimPanel() {
    resetAbilityClaimForm();

    if (selectedPlayer) {
      const exactRole = getLatestExactRoleClaim(selectedPlayer);
      if (isStructuredInfoRole(exactRole)) {
        setPlayerPanel("reported_info");
        return;
      }
      setAbilityClaimRole(exactRole);
    }

    setPlayerPanel("ability_claim");
  }

  function openIdentityPanel() {
    if (!selectedPlayer) {
      return;
    }

    setPendingPlayerName(playerNames[selectedPlayer] ?? "");
    setPlayerPanel("identity");
  }

  function openStatusPanel() {
    setPlayerPanel("status");
  }

  function openDeathPanel() {
    setPendingDeathReason("night_death");
    setDeathWhen(`N${night}`);
    setPlayerPanel("death");
  }

  function openNominationPanel() {
    resetNominationForm();
    setPlayerPanel("nomination");
  }

  function openTalkPanel() {
    resetTalkForm();
    setPlayerPanel("talk");
  }

  function saveRoleClaim() {
    if (!selectedPlayer) {
      return;
    }

    let subject: ClaimSubject | null = null;

    if (claimSubjectKind === "role" && pendingClaimRole) {
      subject = { kind: "role", roleId: pendingClaimRole };
    }

    if (claimSubjectKind === "tag" && pendingClaimTag) {
      subject = { kind: "tag", tag: pendingClaimTag };
    }

    if (claimSubjectKind === "type") subject = {kind:"type",roleType:pendingType};
    if (claimSubjectKind === "alignment") subject = {kind:"alignment",alignment:pendingAlignment};
    if (!subject) {
      return;
    }

    const claim: RoleClaimEvent = {
      id: eventId(),
      playerId: selectedPlayer,
      subject,
      claimType: roleClaimType,
      origin: "manual",
      visibility: claimVisibility,
      recipients: claimVisibility === "private" ? claimRecipients : [],
      when: claimWhen,
    };

    setRoleClaimLog((current) => [...current, claim]);
    resetClaimForm();
    returnFromPlayerPanel();
  }

  function saveAbilityClaim() {
    if (!selectedPlayer || !abilityClaimRole) {
      return;
    }

    const id = eventId();
    const claim: AbilityClaimEvent = {
      id,
      playerId: selectedPlayer,
      roleId: abilityClaimRole,
      when: abilityClaimWhen,
      targets: abilityClaimTargets,
      result: abilityClaimResult.trim() || null,
      visibility: abilityClaimVisibility,
      recipients:
        abilityClaimVisibility === "private" ? abilityClaimRecipients : [],
    };

    setAbilityClaimLog((current) => [...current, claim]);

    // Ability claiming an exact role also establishes that role claim unless
    // they have already made an exact role claim. Broad tag claims do not block this.
    if (!hasExactRoleClaim(selectedPlayer)) {
      const automaticRoleClaim: RoleClaimEvent = {
        id: id + 1,
        sourceEventId: id,
        playerId: selectedPlayer,
        subject: { kind: "role", roleId: abilityClaimRole },
        claimType: "normal",
        origin: "ability_claim",
        visibility: abilityClaimVisibility,
        recipients:
          abilityClaimVisibility === "private" ? abilityClaimRecipients : [],
        when: abilityClaimWhen,
      };

      setRoleClaimLog((current) => [...current, automaticRoleClaim]);
    }

    resetAbilityClaimForm();
    returnFromPlayerPanel();
  }

  function createDeathEvent(event: DeathEvent) {
    if (!isAliveAt(snapshot, event.playerId, event.when, event.id)) {
      window.alert("この時点ではすでに死亡しています。復活後の再死亡は記録できます。");
      return;
    }
    const deaths = [...deathLog,event];
    setDeathLog(deaths);
    setPlayerStatus({...makeInitialStatus(),...rebuildStatus({...snapshot,deathLog:deaths,revivalLog})});
    if (diedByExecution(event)) setNoExecutionDays(xs => xs.filter(n => `D${n}` !== event.when));
  }

  function revivePlayer(player: string) {
    if (!currentScriptHasReviver || playerStatus[player]?.alive || night < 2) return;
    const event: RevivalEvent = { id: eventId(), playerId: player, when: `N${night}` };
    const revivals = [...revivalLog, event];
    setRevivalLog(revivals);
    setPlayerStatus({...makeInitialStatus(),...rebuildStatus({...snapshot,revivalLog:revivals})});
  }

  function saveManualDeath() {
    if (!selectedPlayer) {
      return;
    }

    createDeathEvent({
      id: eventId(),
      playerId: selectedPlayer,
      when: deathWhen,
      reason: pendingDeathReason,
    });

    setPlayerPanel("status");
  }

  function setDeathReason(reasonId: DeathReasonId) {
    setPendingDeathReason(reasonId);
    const options = getDeathPhaseOptions(reasonId);

    if (options.length > 0 && !options.includes(deathWhen)) {
      setDeathWhen(options[options.length - 1]);
    }
  }

  function canPlayerVote(player: string) {
    const historical = rebuildStatus({...snapshot,
      deathLog: deathLog.filter(d => compareEvents(d,{when:nominationWhen,id:Infinity}) < 0),
      revivalLog: revivalLog.filter(r => compareEvents(r,{when:nominationWhen,id:Infinity}) < 0),
      nominationLog: nominationLog.filter(n => compareEvents(n,{when:nominationWhen,id:Infinity}) < 0),
    });
    const status = historical[player] ?? {alive:true,deadVoteAvailable:true};
    return status.alive || status.deadVoteAvailable;
  }

  function saveNomination() {
    if (!selectedPlayer || !pendingNominee) return;
    if (!isAliveAt(snapshot,selectedPlayer,nominationWhen)) {
      window.alert("\u6b7b\u4ea1\u3057\u305f\u4eba\u306f\u6307\u540d\u3067\u304d\u307e\u305b\u3093\u3002"); return;
    }
    if (nominationLog.some(n => n.when === nominationWhen && (n.nominator === selectedPlayer || n.nominee === pendingNominee))) {
      window.alert("\u305d\u306e\u65e5\u306e\u6307\u540d\u56de\u6570\u3092\u78ba\u8a8d\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u8a02\u6b63\u306f\u5c65\u6b74\u304b\u3089\u884c\u3048\u307e\u3059\u3002"); return;
    }
    if (deathLog.some(d => d.when === nominationWhen && diedByExecution(d))) {
      window.alert("\u3053\u306e\u65e5\u306f\u51e6\u5211\u6e08\u307f\u3067\u3059\u3002\u904e\u53bb\u306e\u6307\u540d\u306f\u51e6\u5211\u8a18\u9332\u3092\u4e00\u5ea6\u8a02\u6b63\u3057\u3066\u304b\u3089\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002"); return;
    }
    const virgin = needsVirginCheck(pendingNominee,nominationWhen);
    if (virgin && virginResult === null) return;
    const id = eventId();
    const triggered = virgin && virginResult === true;
    const nomination: NominationEvent = {
      id,nominator:selectedPlayer,nominee:pendingNominee,when:nominationWhen,
      voters: triggered
        ? []
        : getClockwiseVoteOrder(pendingNominee).filter(
            (player) => pendingVoters.includes(player) && canPlayerVote(player)
          ),
      votingOccurred:!triggered,reason:nominationReason.trim(),
    };
    const nominations = [...nominationLog,nomination];
    let deaths = deathLog;
    setNominationLog(nominations);
    if (virgin) {
      const trigger: AbilityTriggerEvent = {id:id+1,roleId:"virgin",rolePlayerId:pendingNominee,targetPlayerId:selectedPlayer,when:nominationWhen,triggered,sourceEventId:id};
      setAbilityTriggerLog(xs=>[...xs,trigger]);
      if (triggered) {
        deaths=[...deathLog,{id:id+2,playerId:selectedPlayer,when:nominationWhen,reason:"execution",isExecution:true,sourceRoleId:"virgin",sourcePlayerId:pendingNominee,sourceEventId:id+1}];
        setDeathLog(deaths); setNoExecutionDays(xs=>xs.filter(n=>`D${n}`!==nominationWhen));
      }
    }
    setPlayerStatus({...makeInitialStatus(),...rebuildStatus({...snapshot,deathLog:deaths,nominationLog:nominations})});
    resetNominationForm(); returnFromPlayerPanel();
  }

  function openSlayerTriggerPanel() {
    if (!selectedPlayer) {
      return;
    }

    setTriggerDraft({
      kind: "slayer",
      rolePlayerId: selectedPlayer,
      targetPlayerId: null,
      when: `D${night}`,
      result: null,
    });
    setPlayerPanel("trigger");
  }

  function saveAbilityTrigger() {
    if (!triggerDraft || triggerDraft.result === null) {
      return;
    }

    if (!triggerDraft.targetPlayerId) {
      return;
    }

    const id = eventId();
    const event: AbilityTriggerEvent = {
      id,
      roleId: triggerDraft.kind,
      rolePlayerId: triggerDraft.rolePlayerId,
      targetPlayerId: triggerDraft.targetPlayerId,
      when: triggerDraft.when,
      triggered: triggerDraft.result,
      sourceEventId: triggerDraft.sourceEventId,
    };

    setAbilityTriggerLog((current) => [...current, event]);

    if (triggerDraft.result) {
      createDeathEvent({
        id: id + 1,
        playerId: triggerDraft.targetPlayerId,
        when: triggerDraft.when,
        reason: triggerDraft.kind === "virgin" ? "execution" : "ability",
        isExecution: triggerDraft.kind === "virgin",
        sourceRoleId: triggerDraft.kind,
        sourcePlayerId: triggerDraft.rolePlayerId,
        sourceEventId: id,
      });
    }

    setTriggerDraft(null);
    resetNominationForm();
    setPlayerPanel("menu");
  }

  function saveTalk() {
    if (!selectedPlayer || talkParticipants.length === 0) {
      return;
    }

    const participants = [...new Set([selectedPlayer, ...talkParticipants])];
    if (participants.length < 2) return;
    const event: TalkEvent = {
      id: eventId(),
      participants,
      when: talkWhen,
      topic: talkTopic,
      details: talkTopic === null ? null : talkDetails.trim() || null,
    };

    setTalkLog((current) => [...current, event]);
    resetTalkForm();
    returnFromPlayerPanel();
  }

  function openSelfMenu() {
    setSelectedPlayer(null);
    setPlayerPanel("menu");
    setSelfPanel("menu");
    setPendingSelfRole(selfRole.shownRole);
    setSelfMenuOpen(true);
  }

  function openSelfPlayerPanel(panel: PlayerPanel) {
    setSelfMenuOpen(false);
    setSelectedPlayer("self");

    if (panel === "claim") {
      resetClaimForm();
    } else if (panel === "ability_claim") {
      resetAbilityClaimForm();
      setAbilityClaimRole(getLatestExactRoleClaim("self"));
    } else if (panel === "nomination") {
      resetNominationForm();
    } else if (panel === "talk") {
      resetTalkForm();
    }

    setPlayerPanel(panel);
  }

  function returnFromPlayerPanel() {
    if (selectedPlayer === "self") {
      setSelectedPlayer(null);
      setPlayerPanel("menu");
      setSelfPanel("menu");
      setSelfMenuOpen(true);
      return;
    }

    setPlayerPanel("menu");
  }

  function openSelfInfoPanel() {
    if (!selfRole.shownRole) {
      return;
    }

    resetSelfInfoForm();
    const options = getSelfInfoNightOptions(selfRole.shownRole);

    if (options.length > 0) {
      setSelfInfoWhen(options[options.length - 1]);
    }

    setSelfPanel("info");
  }

  function openSelfActionPanel() {
    if (!selfRole.shownRole) {
      return;
    }

    resetSelfActionForm();

    if (selfRole.shownRole === "monk" || selfRole.shownRole === "exorcist") {
      const options = getNightOptions(2);
      setSelfActionWhen(options[options.length - 1] ?? "N2");
    } else {
      setSelfActionWhen(`D${night}`);
    }

    setSelfPanel("action");
  }

  function saveSelfPairInfo(roleId: "washerwoman" | "investigator") {
    if (selfInfoPlayers.length !== 2 || !selfInfoShownRole) {
      return;
    }

    setSelfInfoLog((current) => [
      ...current,
      {
        id: eventId(),
        roleId,
        when: "N1",
        players: [selfInfoPlayers[0], selfInfoPlayers[1]],
        shownRole: selfInfoShownRole,
      },
    ]);

    resetSelfInfoForm();
    setSelfPanel("menu");
  }

  function saveSelfLibrarianInfo() {
    if (librarianNoOutsiders) {
      setSelfInfoLog((current) => [
        ...current,
        {
          id: eventId(),
          roleId: "librarian",
          when: "N1",
          noOutsiders: true,
        },
      ]);
    } else {
      if (selfInfoPlayers.length !== 2 || !selfInfoShownRole) {
        return;
      }

      setSelfInfoLog((current) => [
        ...current,
        {
          id: eventId(),
          roleId: "librarian",
          when: "N1",
          noOutsiders: false,
          players: [selfInfoPlayers[0], selfInfoPlayers[1]],
          shownRole: selfInfoShownRole,
        },
      ]);
    }

    resetSelfInfoForm();
    setSelfPanel("menu");
  }

  function saveSelfChefInfo() {
    if (selfInfoNumber === null) return;
    setSelfInfoLog((current) => [
      ...current,
      {
        id: eventId(),
        roleId: "chef",
        when: "N1",
        number: selfInfoNumber,
      },
    ]);

    resetSelfInfoForm();
    setSelfPanel("menu");
  }

  function saveSelfEmpathInfo() {
    if (selfInfoNumber === null || !getSelfInfoNightOptions("empath").includes(selfInfoWhen)) return;
    setSelfInfoLog((current) => [
      ...current,
      {
        id: eventId(),
        roleId: "empath",
        when: selfInfoWhen,
        number: selfInfoNumber as 0 | 1 | 2,
      },
    ]);

    resetSelfInfoForm();
    setSelfPanel("menu");
  }

  function saveSelfFortuneTellerInfo() {
    if (selfInfoPlayers.length !== 2 || selfInfoYesNo === null || !getSelfInfoNightOptions("fortune_teller").includes(selfInfoWhen)) {
      return;
    }

    setSelfInfoLog((current) => [
      ...current,
      {
        id: eventId(),
        roleId: "fortune_teller",
        when: selfInfoWhen,
        players: [selfInfoPlayers[0], selfInfoPlayers[1]],
        result: selfInfoYesNo,
      },
    ]);

    resetSelfInfoForm();
    setSelfPanel("menu");
  }

  function saveSelfRoleRevealInfo(roleId: "undertaker" | "ravenkeeper") {
    if (selfInfoPlayers.length !== 1 || !selfInfoShownRole || !getSelfInfoNightOptions(roleId).includes(selfInfoWhen)) {
      return;
    }

    const id = eventId();
    const player = selfInfoPlayers[0];
    const shownRole = selfInfoShownRole;

    if (roleId === "undertaker") {
      setSelfInfoLog((current) => [
        ...current,
        {
          id,
          roleId: "undertaker",
          when: selfInfoWhen,
          player,
          shownRole,
        },
      ]);
    } else {
      setSelfInfoLog((current) => [
        ...current,
        {
          id,
          roleId: "ravenkeeper",
          when: selfInfoWhen,
          player,
          shownRole,
        },
      ]);
    }

    resetSelfInfoForm();
    setSelfPanel("menu");
  }

  function saveSelfMonkAction() {
    if (!selfActionTarget || selfActionTarget === "self" || !getNightOptions(2).includes(selfActionWhen)) {
      return;
    }

    const duplicate = selfActionLog.some(
      (event) => event.roleId === "monk" && event.when === selfActionWhen
    );

    if (duplicate) {
      const replace = window.confirm(
        `${selfActionWhen}の僧侶の行動は既にあります。置き換えますか？`
      );

      if (!replace) {
        return;
      }
    }

    setSelfActionLog((current) => [
      ...current.filter(
        (event) => !(event.roleId === "monk" && event.when === selfActionWhen)
      ),
      {
        id: eventId(),
        roleId: "monk",
        when: selfActionWhen,
        target: selfActionTarget,
      },
    ]);

    resetSelfActionForm();
    setSelfPanel("menu");
  }

  function saveSelfExorcistAction() {
    if (!selfActionTarget || !getNightOptions(2).includes(selfActionWhen)) {
      return;
    }

    const previous = selfActionLog
      .filter((event) => event.roleId === "exorcist" && compareEvents(event, { when: selfActionWhen, id: Infinity }) < 0)
      .sort(compareEvents)
      .at(-1);

    if (previous?.target === selfActionTarget) {
      window.alert("祓魔師は前の夜と同じ人を選べません。");
      return;
    }

    const duplicate = selfActionLog.some(
      (event) => event.roleId === "exorcist" && event.when === selfActionWhen
    );

    if (duplicate) {
      const replace = window.confirm(
        `${selfActionWhen}の祓魔師の行動は既にあります。置き換えますか？`
      );
      if (!replace) return;
    }

    setSelfActionLog((current) => [
      ...current.filter(
        (event) => !(event.roleId === "exorcist" && event.when === selfActionWhen)
      ),
      {
        id: eventId(),
        roleId: "exorcist",
        when: selfActionWhen,
        target: selfActionTarget,
      },
    ]);

    resetSelfActionForm();
    setSelfPanel("menu");
  }

  function saveSelfSlayerAction() {
    if (!selfActionTarget) {
      return;
    }

    if (selfActionLog.some((event) => event.roleId === "slayer")) {
      return;
    }

    const id = eventId();
    setSelfActionLog((current) => [
      ...current,
      {
        id,
        roleId: "slayer",
        when: selfActionWhen,
        target: selfActionTarget,
        killed: selfSlayerKilled,
      },
    ]);

    setAbilityTriggerLog((current) => [
      ...current,
      {
        id: id + 1,
        roleId: "slayer",
        rolePlayerId: "self",
        sourceEventId: id,
        when: selfActionWhen,
        targetPlayerId: selfActionTarget,
        triggered: selfSlayerKilled,
      },
    ]);

    if (selfSlayerKilled) {
      createDeathEvent({
        id: id + 2,
        playerId: selfActionTarget,
        when: selfActionWhen,
        reason: "ability",
        sourceRoleId: "slayer",
        sourcePlayerId: "self",
        sourceEventId: id + 1,
      });
    }

    resetSelfActionForm();
    setSelfPanel("menu");
  }

  function hasTalked(player: string) {
    return talkLog.some((talk) => talk.participants.includes(player));
  }

  function renderPlayerButton(player: string) {
    const active=isPlayerActive(player),claim=active?getLatestClaim(player):null;
    const dead=active && playerStatus[player]?.alive===false;
    const selfType=selfRole.shownRole?ROLES[selfRole.shownRole].type:null;
    const fellowMinion=active && (
      (selfRole.shownRole==="imp" && demonState.knownMinions.some(m=>m.playerId===player)) ||
      (selfType==="minion" && minionState.knownMinions.some(m=>m.playerId===player))
    );
    const knownDemon=active && selfType==="minion" && minionState.knownDemon?.playerId===player;
    const ally=fellowMinion||knownDemon;
    const name=playerNames[player];
    return <div className="player-slot" key={player}>
      <button className={`player-button${dead?" player-dead":""}${ally?" player-evil-ally":""}`} disabled={!active} onClick={()=>openPlayerMenu(player)} aria-label={`${getPlayerDisplayName(player)} ${getClaimLabel(claim)}`}>
        {active&&hasTalked(player)&&<span className="talk-indicator" title="会話記録あり"/>}
        {knownDemon&&<span className="evil-ally-indicator evil-demon-indicator" title="既知のデーモン">魔</span>}
        {!knownDemon&&fellowMinion&&<span className="evil-ally-indicator" title="既知のミニオン">味</span>}
        <span className="player-symbol">{active?getClaimSymbol(claim):""}</span>
        {active&&name?<><span className="player-name">{name}</span><span className="player-seat">{player}</span></>:<span className="player-seat">{player}</span>}
      </button>
      {active&&<WarningBadges warnings={analysis.players[player]?.warnings??[]} onOpen={()=>openAnalysis(player)}/>}
    </div>;
  }

  if (screen === "home") {
    return (
      <main className="app">
        <h1>時計盤</h1>
        {savedGame && <button className="main-button" onClick={()=>{applySnapshot(savedGame);setScreen("game");}}>{L.resume}</button>}
        <button className="secondary-button" onClick={()=>setGameLogOpen(true)}>ゲームログ ({gameLogs.length})</button>
        <button className="secondary-button" onClick={()=>importRef.current?.click()}>{L.import}</button>
        <input hidden type="file" accept=".json,application/json" ref={importRef} onChange={e=>void importGame(e.target.files?.[0])}/>
        <button className="secondary-button" onClick={() => setScriptManagerOpen(true)}>スクリプト管理</button>
        <button className="main-button" onClick={() => setScreen("setup")}>
          ゲーム開始
        </button>
        {gameLogOpen&&<GameLogPanel logs={gameLogs} onClose={()=>setGameLogOpen(false)} onLoad={loadArchivedGame} onDelete={deleteArchivedGame} onUpdate={updateArchivedGame} onExportOne={downloadGameLogEntry} onExportAll={()=>downloadGameLogs(gameLogs)}/>}
        {scriptManagerOpen && (
          <div className="menu-overlay" onClick={() => { setScriptManagerOpen(false); setScriptEditorOpen(false); }}>
            <div className="script-manager" onClick={event => event.stopPropagation()}>
              {!scriptEditorOpen ? (
                <>
                  <h2>スクリプト管理</h2>
                  <button className="menu-option main-button" onClick={() => { setScriptEditorId(null); setScriptEditorReadOnly(false); setScriptEditorRoles([]); setScriptEditorOpen(true); }}>新規スクリプト</button>
                  <div className="script-list">
                    {BUILT_IN_SCRIPTS.map(script => (
                      <button key={script.id} className="script-list-item" onClick={() => { setScriptEditorId(script.id); setScriptEditorReadOnly(true); setScriptEditorRoles([...script.roleIds]); setScriptEditorOpen(true); }}>
                        <strong>{script.name}</strong><span>{script.roleIds.length}役職</span>
                      </button>
                    ))}
                    {customScripts.map(script => (
                      <div className="script-list-row" key={script.id}>
                        <button className="script-list-item" onClick={() => { setScriptEditorId(script.id); setScriptEditorReadOnly(false); setScriptEditorRoles([...script.roleIds]); setScriptEditorOpen(true); }}>
                          <strong>{script.name}</strong><span>{script.roleIds.length}役職 / カスタム</span>
                        </button>
                        <button className="compact-danger" onClick={() => {
                          if (!window.confirm(`${script.name}を削除しますか？`)) return;
                          const next = customScripts.filter(item => item.id !== script.id);
                          if (saveCustomScripts(next)) setCustomScripts(next);
                          if (playset === script.id) setPlayset("trouble_brewing");
                        }}>削除</button>
                      </div>
                    ))}
                  </div>
                  <button className="menu-option" onClick={() => setScriptManagerOpen(false)}>閉じる</button>
                </>
              ) : (
                <>
                  <h2>{scriptEditorReadOnly ? (getScriptById(scriptEditorId ?? "", customScripts)?.name ?? "スクリプト") : scriptEditorId ? "スクリプト編集" : "新規スクリプト"}</h2>
                  <p className="panel-note">役職をタップして ON / OFF。表示・主張・候補盤面はこのリストだけを使います。</p>
                  <div className="script-counts">
                    {(["townsfolk","outsider","minion","demon"] as RoleType[]).map(type => <span key={type}>{type}: {scriptEditorRoles.filter(id => ROLES[id].type === type).length}</span>)}
                  </div>
                  {(["townsfolk","outsider","minion","demon"] as RoleType[]).map(type => (
                    <section key={type} className="script-role-section">
                      <h3>{type === "townsfolk" ? "Townsfolk" : type === "outsider" ? "Outsider" : type === "minion" ? "Minion" : "Demon"}</h3>
                      <div className="script-role-grid">
                        {ALL_CORE_ROLE_IDS.filter(id => ROLES[id].type === type).map(id => {
                          const role = ROLES[id], on = scriptEditorRoles.includes(id);
                          return <button key={id} disabled={scriptEditorReadOnly} className={`script-role-toggle${on ? " is-on" : ""}${role.solverSupport === "generic" ? " generic-role" : ""}`} onClick={() => setScriptEditorRoles(current => current.includes(id) ? current.filter(x => x !== id) : [...current,id])}>
                            <span className="role-choice-symbol">{role.symbol}</span><span>{role.name}</span><small>{on ? "ON" : "OFF"}{role.solverSupport === "generic" ? " / 汎用推理" : ""}</small>
                          </button>;
                        })}
                      </div>
                    </section>
                  ))}
                  {!scriptEditorReadOnly && <button className="menu-option confirm-claim-button" onClick={() => {
                    if (scriptEditorRoles.length === 0) { window.alert("少なくとも1役職をONにしてください。"); return; }
                    const existing = scriptEditorId ? customScripts.find(x => x.id === scriptEditorId) : null;
                    const name = window.prompt("スクリプト名を入力してください", existing?.name ?? "");
                    if (!name?.trim()) return;
                    let next: ScriptDefinition[];
                    if (existing) next = customScripts.map(item => item.id === existing.id ? { ...item, name: name.trim(), roleIds: [...scriptEditorRoles] } : item);
                    else next = [...customScripts, createCustomScript(name, scriptEditorRoles)];
                    if (!saveCustomScripts(next)) { window.alert("スクリプトを保存できませんでした。"); return; }
                    setCustomScripts(next); setScriptEditorOpen(false); setScriptEditorId(null); setScriptEditorRoles([]);
                  }}>保存</button>}
                  <button className="menu-option" onClick={() => { setScriptEditorOpen(false); setScriptEditorId(null); setScriptEditorRoles([]); }}>戻る</button>
                </>
              )}
            </div>
          </div>
        )}
      </main>
    );
  }

  if (screen === "setup") {
    return (
      <main className="app setup-screen">
        <h1>ゲーム設定</h1>

        <div className="setup-box">
          <label>プレイヤー人数</label>
          <select
            value={playerCount}
            onChange={(event) => setPlayerCount(Number(event.target.value))}
          >
            {Array.from({ length: 11 }, (_, index) => index + 5).map(
              (number) => (
                <option key={number} value={number}>
                  {number}人
                </option>
              )
            )}
          </select>
        </div>

        <div className="setup-box">
          <label>プレイセット</label>
          <select
            value={playset}
            onChange={(event) => setPlayset(event.target.value)}
          >
            {allScripts(customScripts).map(script => (
              <option key={script.id} value={script.id}>{script.name}</option>
            ))}
          </select>
        </div>

        <div className="button-row">
          <button className="secondary-button" onClick={() => setScreen("home")}>
            戻る
          </button>
          <button className="main-button" onClick={startGame}>
            開始
          </button>
        </div>
      </main>
    );
  }

  const selectedLatestClaim = selectedPlayer
    ? getLatestClaim(selectedPlayer)
    : null;
  const selectedPlayerClaims = selectedPlayer
    ? roleClaimLog.filter((claim) => claim.playerId === selectedPlayer)
    : [];
  const selectedAbilityClaims = selectedPlayer
    ? abilityClaimLog.filter((claim) => claim.playerId === selectedPlayer).sort(compareEvents)
    : [];
  const selectedOtherAbilityClaims = selectedAbilityClaims.filter(
    (claim) => !claim.structured && !isStructuredInfoRole(claim.roleId)
  );
  const selectedDeaths = selectedPlayer
    ? deathLog.filter((death) => death.playerId === selectedPlayer)
    : [];
  const selectedRevivals = selectedPlayer
    ? revivalLog.filter((event) => event.playerId === selectedPlayer).sort(compareEvents)
    : [];
  const selectedLatestRoleClaimToUndo = [...selectedPlayerClaims].sort(compareEvents).at(-1);
  const selectedLatestInfoRecordToUndo = selectedAbilityClaims.at(-1);
  const selectedLatestOtherAbilityToUndo = selectedOtherAbilityClaims.at(-1);
  const latestSelfInfoToUndo = selfRole.shownRole
    ? selfInfoLog.filter((event) => event.roleId === selfRole.shownRole).sort(compareEvents).at(-1)
    : undefined;
  const latestSelfActionToUndo = selfRole.shownRole
    ? selfActionLog.filter((event) => event.roleId === selfRole.shownRole).sort(compareEvents).at(-1)
    : undefined;

  const selfHiddenRolePossibilities = selfRole.shownRole && analysis.players.self?.confirmedRole !== selfRole.shownRole
    ? getPossibleHiddenSelfRoles(selfRole.shownRole)
    : [];

  return (
    <main className="game-screen">
      <div className="top-bar">
        <span>N{night} / D{night}</span>
        <button className="analysis-open" onClick={()=>openAnalysis()}>{L.analysis}{reasoning.status === "running" ? " ..." : ""}</button>
        <span>{playerCount}人</span>
      </div>

      <div className="board">
        <div className="player-column">{LEFT_PLAYERS.map(renderPlayerButton)}</div>
        <div className="player-column">{RIGHT_PLAYERS.map(renderPlayerButton)}</div>
      </div>

      <div className="player-slot self-slot">
      <button className={`self-button${playerStatus.self?.alive===false?" player-dead":""}`} onClick={openSelfMenu}>
        {selfRole.shownRole && (
          <span className="player-symbol">{ROLES[selfRole.shownRole].symbol}</span>
        )}
        <span className="player-seat self-label">自分</span>
      </button>
      <WarningBadges warnings={analysis.players.self?.warnings??[]} onOpen={()=>openAnalysis("self")}/>
      </div>
      {saveFailed&&<div className="save-error" role="alert">{L.saveError}</div>}
      <input hidden type="file" accept=".json,application/json" ref={importRef} onChange={e=>void importGame(e.target.files?.[0])}/>
      {analysisOpen&&<AnalysisPanel g={snapshot} e={analysis} query={reasoning} player={analysisPlayer} initialTab={analysisInitialTab} onClose={()=>setAnalysisOpen(false)} onCompleteness={setCompleteness} onDelete={deleteHistory}/>}
      {gameLogOpen&&<GameLogPanel logs={gameLogs} onClose={()=>setGameLogOpen(false)} onLoad={loadArchivedGame} onDelete={deleteArchivedGame} onUpdate={updateArchivedGame} onExportOne={downloadGameLogEntry} onExportAll={()=>downloadGameLogs(gameLogs)}/>}

      <button
        className="corner-button menu-button"
        onClick={() => setMenuOpen(true)}
      >
        メニュー
      </button>

      <button
        className="corner-button night-button"
        onClick={confirmNextNight}
      >
        次の夜
      </button>

      {selectedPlayer && (
        <div className="menu-overlay" onClick={() => setSelectedPlayer(null)}>
          <div className="player-menu" onClick={(event) => event.stopPropagation()}>
            {playerPanel === "menu" && (
              <>
                <h2>
                  {playerNames[selectedPlayer] || selectedPlayer}
                  {playerNames[selectedPlayer] && (
                    <span className="player-menu-seat"> ({selectedPlayer})</span>
                  )}
                </h2>

                <div className="current-claim">
                  現在の主張：<strong>{getClaimLabel(selectedLatestClaim)}</strong>
                </div>

                <div className="status-detail">
                  状態：{playerStatus[selectedPlayer].alive ? "生存" : "死亡"}
                  {!playerStatus[selectedPlayer].alive &&
                    ` / 死者投票 ${
                      playerStatus[selectedPlayer].deadVoteAvailable
                        ? "使用可能"
                        : "使用済み"
                    }`}
                </div>

                <div className="claim-history">
                  <div className="claim-history-title">主張履歴</div>
                  {selectedPlayerClaims.length === 0 ? (
                    <div className="claim-history-empty">履歴なし</div>
                  ) : (
                    selectedPlayerClaims.map((claim) => (
                      <div className="claim-history-item" key={claim.id}>
                        <span className="claim-history-role">
                          {getClaimSymbol(claim)}
                        </span>
                        <span>{claim.when}</span>
                        <span>
                          {claim.claimType === "bluff" ? "ブラフ / " : ""}
                          {formatAudience(claim.visibility, claim.recipients)}
                          {claim.origin === "ability_claim" ? " / 自動追加" : ""}
                        </span>
                      </div>
                    ))
                  )}
                </div>

                {selectedAbilityClaims.length > 0 && (
                  <div className="claim-history">
                    <div className="claim-history-title">情報記録</div>
                    {selectedAbilityClaims.map((claim) => {
                      const source = claim.sourcePlayerId || claim.playerId;
                      return (
                        <div className="claim-history-item" key={claim.id}>
                          <span className="claim-history-role">{ROLES[claim.roleId].symbol}</span>
                          <span>{claim.when}</span>
                          <span>
                            {source !== claim.playerId ? `元: ${getPlayerDisplayName(source)} / ` : ""}
                            {formatStructuredClaim(claim)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}

                <PlayerSummary g={snapshot} p={selectedPlayer} r={reasoning.result} e={analysis} onOpen={()=>openAnalysis(selectedPlayer)}/>
                <button className="menu-option" onClick={()=>setPlayerPanel("reported_info")}>情報を記録</button>
                {selectedPlayer !== "self" && (
                  <button className="menu-option" onClick={openIdentityPanel}>
                    プレイヤー情報
                  </button>
                )}
                <button className="menu-option" onClick={openClaimPanel}>
                  役職主張
                </button>
                <button className="menu-option" onClick={openNominationPanel}>
                  指名
                </button>
                <button className="menu-option" onClick={openTalkPanel}>
                  会話
                </button>
                <button className="menu-option" onClick={openStatusPanel}>
                  状態
                </button>

                <button
                  className="menu-option"
                  disabled={!currentScriptRoleIds.includes("slayer")}
                  onClick={openSlayerTriggerPanel}
                >
                  能力発動
                </button>

                <button className="menu-option" onClick={()=>setPlayerPanel("read")}>{L.read}</button>

                <button
                  className="menu-option"
                  onClick={() => setSelectedPlayer(null)}
                >
                  閉じる
                </button>
              </>
            )}

            {playerPanel === "read" && <ManualReadForm g={snapshot} player={selectedPlayer} onBack={returnFromPlayerPanel} onSave={read=>{setManualReads(xs=>({...xs,[selectedPlayer]:read}));returnFromPlayerPanel();}} onClear={()=>{setManualReads(xs=>{const next={...xs};delete next[selectedPlayer];return next;});returnFromPlayerPanel();}}/>}
            {playerPanel === "reported_info" && <ReportedInfoForm g={snapshot} speaker={selectedPlayer} onSave={saveReportedInfo} onUndo={selectedLatestInfoRecordToUndo ? () => deleteHistory("abilityClaimLog", selectedLatestInfoRecordToUndo.id) : undefined} onBack={returnFromPlayerPanel}/>}
            {playerPanel === "identity" && (
              <>
                <h2>{selectedPlayer} — プレイヤー情報</h2>
                <div className="form-section">
                  <label htmlFor="player-name">名前</label>
                  <input
                    id="player-name"
                    type="text"
                    value={pendingPlayerName}
                    placeholder="名前を入力"
                    maxLength={20}
                    onChange={(event) => setPendingPlayerName(event.target.value)}
                  />
                </div>
                <button
                  className="menu-option confirm-claim-button"
                  onClick={() => {
                    setPlayerNames((current) => ({
                      ...current,
                      [selectedPlayer]: pendingPlayerName.trim(),
                    }));
                    setPlayerPanel("menu");
                  }}
                >
                  確定
                </button>
                <button className="menu-option" onClick={returnFromPlayerPanel}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "claim" && (
              <>
                <h2>{selectedPlayer} — 役職主張</h2>

                <div className="claim-option-title">主張内容</div>
                <div className="visibility-switch">
                  <button
                    className={
                      claimSubjectKind === "role"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => {
                      setClaimSubjectKind("role");
                      setPendingClaimTag(null);
                    }}
                  >
                    役職
                  </button>
                  <button
                    className={
                      claimSubjectKind === "tag"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => {
                      setClaimSubjectKind("tag");
                      setPendingClaimRole(null);
                    }}
                  >
                    カテゴリ
                  </button>
                </div>

                <div className="compact-row">
                  <button className="visibility-button" onClick={()=>setClaimSubjectKind("type")}>{"\u5f79\u8077\u533a\u5206"}</button>
                  <button className="visibility-button" onClick={()=>setClaimSubjectKind("alignment")}>{L.alignment}</button>
                </div>
                {claimSubjectKind === "type" && <div className="player-toggle-grid">{(["townsfolk","outsider","minion","demon"] as RoleType[]).map((t,i)=><button key={t} className={`player-toggle ${pendingType===t?"selected":""}`} onClick={()=>setPendingType(t)}>{L.nominalTypes[i]}</button>)}</div>}
                {claimSubjectKind === "alignment" && <div className="visibility-switch">{(["good","evil"] as const).map(a=><button key={a} className={`visibility-button ${pendingAlignment===a?"visibility-selected":""}`} onClick={()=>setPendingAlignment(a)}>{L[a]}</button>)}</div>}
                {(claimSubjectKind === "role" || claimSubjectKind === "tag") && <>
                {claimSubjectKind === "role" ? (
                  <div className="role-grid">
                    {currentScriptRoles.map((role) => (
                      <button
                        key={role.id}
                        className={
                          pendingClaimRole === role.id
                            ? "role-choice role-choice-selected"
                            : "role-choice"
                        }
                        onClick={() => setPendingClaimRole(role.id)}
                      >
                        <span className="role-choice-symbol">{role.symbol}</span>
                        <span className="role-choice-name">{role.name}</span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="player-toggle-grid">
                    {activeClaimableTags.map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        className={
                          pendingClaimTag === tag
                            ? "player-toggle selected"
                            : "player-toggle"
                        }
                        onClick={() => setPendingClaimTag(tag)}
                      >
                        {CLAIMABLE_TAG_SYMBOLS[tag]} {CLAIMABLE_TAG_LABELS[tag]}
                      </button>
                    ))}
                  </div>
                )}

                </>}
                <div className="claim-option-title">主張タイプ</div>
                <div className="visibility-switch">
                  <button
                    className={
                      roleClaimType === "normal"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => setRoleClaimType("normal")}
                  >
                    通常
                  </button>
                  <button
                    className={
                      roleClaimType === "bluff"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => setRoleClaimType("bluff")}
                  >
                    ブラフ
                  </button>
                </div>

                <div className="form-section">
                  <label>いつ</label>
                  <select
                    value={claimWhen}
                    onChange={(event) => setClaimWhen(event.target.value)}
                  >
                    {getPhaseOptions().map((phase) => (
                      <option key={phase} value={phase}>
                        {phase}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="claim-option-title">公開範囲</div>
                <div className="visibility-switch">
                  <button
                    className={
                      claimVisibility === "public"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => {
                      setClaimVisibility("public");
                      setClaimRecipients([]);
                    }}
                  >
                    公開
                  </button>
                  <button
                    className={
                      claimVisibility === "private"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => {
                      setClaimVisibility("private");
                      setClaimRecipients([]);
                    }}
                  >
                    非公開
                  </button>
                </div>

                {claimVisibility === "private" && (
                  <div className="form-section">
                    <label>伝えた相手</label>
                    <div className="player-toggle-grid">
                      <button
                        type="button"
                        className={
                          claimRecipients.includes("self")
                            ? "player-toggle selected"
                            : "player-toggle"
                        }
                        onClick={() =>
                          togglePlayerInList("self", setClaimRecipients)
                        }
                      >
                        自分
                      </button>
                      {getActivePlayers()
                        .filter((player) => player !== selectedPlayer)
                        .map((player) => (
                          <button
                            key={player}
                            type="button"
                            className={
                              claimRecipients.includes(player)
                                ? "player-toggle selected"
                                : "player-toggle"
                            }
                            onClick={() =>
                              togglePlayerInList(player, setClaimRecipients)
                            }
                          >
                            {getPlayerDisplayName(player)}
                          </button>
                        ))}
                    </div>
                  </div>
                )}

                <button
                  className="menu-option confirm-claim-button"
                  disabled={
                    claimSubjectKind === "role"
                      ? !pendingClaimRole
                      : claimSubjectKind === "tag" ? !pendingClaimTag : false
                  }
                  onClick={saveRoleClaim}
                >
                  確定
                </button>
                <button
                  className="menu-option"
                  disabled={!selectedLatestRoleClaimToUndo}
                  onClick={() => selectedLatestRoleClaimToUndo && deleteHistory("roleClaimLog", selectedLatestRoleClaimToUndo.id)}
                >
                  取り消し
                </button>
                <button className="menu-option" onClick={returnFromPlayerPanel}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "ability_claim" && (
              <>
                <h2>{selectedPlayer} — その他の能力主張</h2>
                <div className="panel-note">
                  洗・図・探・料・感・占・墓・烏の情報は「情報主張」から役職別の形式で入力します。
                </div>

                <div className="form-section">
                  <label>主張している役職</label>
                  <select
                    value={abilityClaimRole ?? ""}
                    onChange={(event) =>
                      setAbilityClaimRole(
                        event.target.value ? (event.target.value as RoleId) : null
                      )
                    }
                  >
                    <option value="">選択</option>
                    {currentScriptRoles
                      .filter((role) => !isStructuredInfoRole(role.id))
                      .map((role) => (
                        <option key={role.id} value={role.id}>
                          {role.symbol} {role.name}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="form-section">
                  <label>いつ</label>
                  <select
                    value={abilityClaimWhen}
                    onChange={(event) => setAbilityClaimWhen(event.target.value)}
                  >
                    {getPhaseOptions().map((phase) => (
                      <option key={phase} value={phase}>
                        {phase}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="claim-option-title">対象（分かる場合）</div>
                <div className="player-toggle-grid">
                  <button
                    type="button"
                    className={
                      abilityClaimTargets.includes("self")
                        ? "player-toggle selected"
                        : "player-toggle"
                    }
                    onClick={() =>
                      togglePlayerInList("self", setAbilityClaimTargets)
                    }
                  >
                    自分
                  </button>
                  {getActivePlayers()
                    .filter((player) => player !== selectedPlayer)
                    .map((player) => (
                      <button
                        key={player}
                        type="button"
                        className={
                          abilityClaimTargets.includes(player)
                            ? "player-toggle selected"
                            : "player-toggle"
                        }
                        onClick={() =>
                          togglePlayerInList(player, setAbilityClaimTargets)
                        }
                      >
                        {getPlayerDisplayName(player)}
                      </button>
                    ))}
                </div>

                <div className="form-section">
                  <label>内容 / 結果（任意）</label>
                  <textarea
                    value={abilityClaimResult}
                    placeholder="例：1、YES、3Lを守った など"
                    onChange={(event) => setAbilityClaimResult(event.target.value)}
                  />
                </div>

                <div className="claim-option-title">公開範囲</div>
                <div className="visibility-switch">
                  <button
                    className={
                      abilityClaimVisibility === "public"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => {
                      setAbilityClaimVisibility("public");
                      setAbilityClaimRecipients([]);
                    }}
                  >
                    公開
                  </button>
                  <button
                    className={
                      abilityClaimVisibility === "private"
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() => {
                      setAbilityClaimVisibility("private");
                      setAbilityClaimRecipients([]);
                    }}
                  >
                    非公開
                  </button>
                </div>

                {abilityClaimVisibility === "private" && (
                  <div className="form-section">
                    <label>伝えた相手</label>
                    <div className="player-toggle-grid">
                      <button
                        type="button"
                        className={
                          abilityClaimRecipients.includes("self")
                            ? "player-toggle selected"
                            : "player-toggle"
                        }
                        onClick={() =>
                          togglePlayerInList("self", setAbilityClaimRecipients)
                        }
                      >
                        自分
                      </button>
                      {getActivePlayers()
                        .filter((player) => player !== selectedPlayer)
                        .map((player) => (
                          <button
                            key={player}
                            type="button"
                            className={
                              abilityClaimRecipients.includes(player)
                                ? "player-toggle selected"
                                : "player-toggle"
                            }
                            onClick={() =>
                              togglePlayerInList(player, setAbilityClaimRecipients)
                            }
                          >
                            {getPlayerDisplayName(player)}
                          </button>
                        ))}
                    </div>
                  </div>
                )}

                <div className="panel-note">
                  能力主張を確定すると、まだ正確な役職主張がない場合だけ同じ役職を自動で役職主張に追加します。
                </div>

                <button
                  className="menu-option confirm-claim-button"
                  disabled={!abilityClaimRole}
                  onClick={saveAbilityClaim}
                >
                  確定
                </button>
                <button
                  className="menu-option"
                  disabled={!selectedLatestOtherAbilityToUndo}
                  onClick={() => selectedLatestOtherAbilityToUndo && deleteHistory("abilityClaimLog", selectedLatestOtherAbilityToUndo.id)}
                >
                  取り消し
                </button>
                <button className="menu-option" onClick={returnFromPlayerPanel}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "nomination" && (
              <>
                <h2>{selectedPlayer} — 指名</h2>

                <div className="claim-option-title">指名された人</div>
                <div className="player-toggle-grid">
                  {getActivePlayers()
                    .map((player) => (
                      <button
                        key={player}
                        type="button"
                        className={
                          pendingNominee === player
                            ? "player-toggle selected"
                            : "player-toggle"
                        }
                        onClick={() => {
                          setPendingNominee(player);
                          setPendingVoters([]); setVirginResult(null);
                        }}
                      >
                        {getPlayerDisplayName(player)}
                      </button>
                    ))}
                  <button
                    type="button"
                    className={
                      pendingNominee === "self"
                        ? "player-toggle selected"
                        : "player-toggle"
                    }
                    onClick={() => {
                      setPendingNominee("self");
                      setPendingVoters([]); setVirginResult(null);
                    }}
                  >
                    自分
                  </button>
                </div>

                <div className="form-section">
                  <label>いつ</label>
                  <select
                    value={nominationWhen}
                    onChange={(event) => {setNominationWhen(event.target.value);setVirginResult(null);setPendingVoters([]);}}
                  >
                    {getDayOptions().map((phase) => (
                      <option key={phase} value={phase}>
                        {phase}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-section"><label>{L.nominationReason}</label><textarea value={nominationReason} onChange={e=>setNominationReason(e.target.value)} maxLength={1000}/></div>
                {pendingNominee&&<NominationCard g={snapshot} r={reasoning.result} p={pendingNominee} nominator={selectedPlayer} compact/>}
                {needsVirginCheck(pendingNominee,nominationWhen)&&<section className="analysis-card"><h3>{L.virginQuestion}</h3><p className="panel-note">{L.virginBefore}</p><div className="visibility-switch">{([true,false] as const).map(v=><button type="button" key={String(v)} className={`visibility-button ${virginResult===v?"visibility-selected":""}`} onClick={()=>{setVirginResult(v);setPendingVoters([]);}}>{v?L.yes:L.no}</button>)}</div></section>}
                {pendingNominee && (!needsVirginCheck(pendingNominee,nominationWhen)||virginResult===false) && (
                  <>
                    <div className="claim-option-title">
                      投票 — {pendingVoters.length}票
                    </div>
                    <div className="panel-note">選択中 = 挙手</div>
                    <div className="panel-note">
                      時計回りの投票順です。最後が指名された本人です。
                    </div>
                    <div className="player-toggle-grid vote-order-grid">
                      {getClockwiseVoteOrder(pendingNominee).map((player, index) => {
                        const status = player === "self"
                          ? playerStatus.self
                          : playerStatus[player];
                        return (
                          <button
                            key={player}
                            type="button"
                            disabled={!canPlayerVote(player)}
                            className={
                              pendingVoters.includes(player)
                                ? "player-toggle selected"
                                : "player-toggle"
                            }
                            onClick={() => togglePlayerInList(player, setPendingVoters)}
                          >
                            <span className="vote-order-number">{index + 1}</span> {getPlayerDisplayName(player)}
                            {status && !status.alive && !status.deadVoteAvailable && " ×"}
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}

                <button
                  className="menu-option confirm-claim-button"
                  disabled={!pendingNominee || (needsVirginCheck(pendingNominee,nominationWhen)&&virginResult===null)}
                  onClick={saveNomination}
                >
                  確定
                </button>
                <button className="menu-option" onClick={returnFromPlayerPanel}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "status" && (
              <>
                <h2>{selectedPlayer} — 状態</h2>
                <div className="status-display">
                  {playerStatus[selectedPlayer].alive ? "生存" : "死亡"}
                </div>

                {selectedDeaths.length > 0 && (
                  <div className="claim-history">
                    <div className="claim-history-title">死亡履歴</div>
                    {selectedDeaths.map((death) => (
                      <div className="claim-history-item" key={death.id}>
                        <span>{death.when}</span>
                        <span>{getDeathReasonLabel(death.reason)}</span>
                        <span>
                          {death.sourceRoleId
                            ? `${ROLES[death.sourceRoleId].symbol} ${ROLES[death.sourceRoleId].name}`
                            : ""}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {selectedRevivals.length > 0 && (
                  <div className="claim-history">
                    <div className="claim-history-title">復活履歴</div>
                    {selectedRevivals.map((event) => (
                      <div className="claim-history-item" key={event.id}>
                        <span>{event.when}</span>
                        <span>復活</span>
                      </div>
                    ))}
                  </div>
                )}

                {playerStatus[selectedPlayer].alive ? (
                  <button className="menu-option danger-button" onClick={openDeathPanel}>
                    キル
                  </button>
                ) : (
                  <>
                    <div className="status-detail">
                      死者投票：
                      {playerStatus[selectedPlayer].deadVoteAvailable
                        ? "使用可能"
                        : "使用済み"}
                    </div>
                    {currentScriptHasReviver && night >= 2 && (
                      <button className="menu-option confirm-claim-button" onClick={() => revivePlayer(selectedPlayer)}>
                        復活
                      </button>
                    )}
                    <button className="menu-option" onClick={()=>openAnalysis(selectedPlayer)}>{L.history}</button>
                    <p className="panel-note">{"\u6b7b\u8005\u6295\u7968\u306f\u78ba\u5b9a\u3057\u305f\u6295\u7968\u8a18\u9332\u304b\u3089\u8a08\u7b97\u3057\u307e\u3059\u3002\u8aa4\u5165\u529b\u306f\u8a18\u9332\u304b\u3089\u8a02\u6b63\u3057\u3066\u304f\u3060\u3055\u3044\u3002"}</p>
                  </>
                )}

                <button className="menu-option" onClick={returnFromPlayerPanel}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "death" && (
              <>
                <h2>{selectedPlayer} — キル</h2>
                <div className="claim-option-title">理由</div>
                <div className="player-toggle-grid">
                  {DEATH_REASONS.map((reason) => (
                    <button
                      key={reason.id}
                      type="button"
                      className={
                        pendingDeathReason === reason.id
                          ? "player-toggle selected"
                          : "player-toggle"
                      }
                      onClick={() => setDeathReason(reason.id)}
                    >
                      {reason.label}
                    </button>
                  ))}
                </div>

                <div className="form-section">
                  <label>いつ</label>
                  <select
                    value={deathWhen}
                    onChange={(event) => setDeathWhen(event.target.value)}
                  >
                    {getDeathPhaseOptions(pendingDeathReason).map((phase) => (
                      <option key={phase} value={phase}>
                        {phase}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="panel-note">
                  生 / 殺 などの特定能力による死亡は、能力発動イベントから自動で死亡イベントを作ります。
                </div>

                <button
                  className="menu-option confirm-claim-button"
                  onClick={saveManualDeath}
                >
                  確定
                </button>
                <button className="menu-option" onClick={() => setPlayerPanel("status")}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "talk" && (
              <>
                <h2>{selectedPlayer} — 会話</h2>
                <div className="claim-option-title">話した相手</div>
                <div className="player-toggle-grid">
                  <button
                    type="button"
                    disabled={selectedPlayer === "self"}
                    className={
                      talkParticipants.includes("self")
                        ? "player-toggle selected"
                        : "player-toggle"
                    }
                    onClick={() =>
                      togglePlayerInList("self", setTalkParticipants)
                    }
                  >
                    自分
                  </button>
                  {getActivePlayers()
                    .filter((player) => player !== selectedPlayer)
                    .map((player) => (
                      <button
                        key={player}
                        type="button"
                        className={
                          talkParticipants.includes(player)
                            ? "player-toggle selected"
                            : "player-toggle"
                        }
                        onClick={() =>
                          togglePlayerInList(player, setTalkParticipants)
                        }
                      >
                        {getPlayerDisplayName(player)}
                      </button>
                    ))}
                </div>

                <div className="form-section">
                  <label>いつ</label>
                  <select
                    value={talkWhen}
                    onChange={(event) => setTalkWhen(event.target.value)}
                  >
                    {getDayOptions().map((phase) => (
                      <option key={phase} value={phase}>
                        {phase}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="claim-option-title">話題</div>
                <div className="player-toggle-grid">
                  <button
                    type="button"
                    className={
                      talkTopic === null
                        ? "player-toggle selected"
                        : "player-toggle"
                    }
                    onClick={() => setTalkTopic(null)}
                  >
                    不明
                  </button>
                  {(Object.keys(TALK_TOPIC_LABELS) as TalkTopic[]).map((topic) => (
                    <button
                      key={topic}
                      type="button"
                      className={
                        talkTopic === topic
                          ? "player-toggle selected"
                          : "player-toggle"
                      }
                      onClick={() => setTalkTopic(topic)}
                    >
                      {TALK_TOPIC_LABELS[topic]}
                    </button>
                  ))}
                </div>

                {talkTopic !== null && (
                  <div className="form-section">
                    <label>内容（任意）</label>
                    <textarea
                      value={talkDetails}
                      placeholder="分かる範囲で入力"
                      onChange={(event) => setTalkDetails(event.target.value)}
                    />
                  </div>
                )}

                <button
                  className="menu-option confirm-claim-button"
                  disabled={talkParticipants.length === 0}
                  onClick={saveTalk}
                >
                  確定
                </button>
                <button className="menu-option" onClick={returnFromPlayerPanel}>
                  戻る
                </button>
              </>
            )}

            {playerPanel === "trigger" && triggerDraft && (
              <>
                <h2>
                  {triggerDraft.kind === "virgin" ? "処女" : "処刑人"} — 能力発動
                </h2>

                {triggerDraft.kind === "virgin" ? (
                  <>
                    <div className="panel-note">
                      {getPlayerDisplayName(triggerDraft.targetPlayerId ?? "")} → {" "}
                      {getPlayerDisplayName(triggerDraft.rolePlayerId)} を指名
                    </div>
                    <div className="claim-option-title">処女は発動しましたか？</div>
                  </>
                ) : (
                  <>
                    <div className="claim-option-title">対象</div>
                    <div className="player-toggle-grid">
                      {getActivePlayers()
                        .filter((player) => player !== triggerDraft.rolePlayerId)
                        .map((player) => (
                          <button
                            key={player}
                            type="button"
                            className={
                              triggerDraft.targetPlayerId === player
                                ? "player-toggle selected"
                                : "player-toggle"
                            }
                            onClick={() =>
                              setTriggerDraft((current) =>
                                current
                                  ? { ...current, targetPlayerId: player }
                                  : current
                              )
                            }
                          >
                            {getPlayerDisplayName(player)}
                          </button>
                        ))}
                    </div>
                    <div className="form-section">
                      <label>いつ</label>
                      <select
                        value={triggerDraft.when}
                        onChange={(event) =>
                          setTriggerDraft((current) =>
                            current ? { ...current, when: event.target.value } : current
                          )
                        }
                      >
                        {getDayOptions().map((phase) => (
                          <option key={phase} value={phase}>
                            {phase}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="claim-option-title">対象は死亡しましたか？</div>
                  </>
                )}

                <div className="visibility-switch">
                  <button
                    className={
                      triggerDraft.result === true
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() =>
                      setTriggerDraft((current) =>
                        current ? { ...current, result: true } : current
                      )
                    }
                  >
                    はい
                  </button>
                  <button
                    className={
                      triggerDraft.result === false
                        ? "visibility-button visibility-selected"
                        : "visibility-button"
                    }
                    onClick={() =>
                      setTriggerDraft((current) =>
                        current ? { ...current, result: false } : current
                      )
                    }
                  >
                    いいえ
                  </button>
                </div>

                <button
                  className="menu-option confirm-claim-button"
                  disabled={
                    triggerDraft.result === null || !triggerDraft.targetPlayerId
                  }
                  onClick={saveAbilityTrigger}
                >
                  確定
                </button>
                <button
                  className="menu-option"
                  onClick={() => {
                    setTriggerDraft(null);
                    setPlayerPanel("menu");
                  }}
                >
                  戻る
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {selfMenuOpen && (
        <div className="menu-overlay" onClick={() => setSelfMenuOpen(false)}>
          <div className="player-menu" onClick={(event) => event.stopPropagation()}>
            {selfPanel === "menu" && (
              <>
                <h2>自分</h2>
                <PlayerSummary g={snapshot} p="self" r={reasoning.result} e={analysis} onOpen={()=>openAnalysis("self")}/>
                <button className="menu-option" onClick={()=>setSelfPanel("advice")}>{L.advice}</button>
                <div className="current-claim">
                  表示役職：
                  <strong>
                    {selfRole.shownRole
                      ? `${ROLES[selfRole.shownRole].symbol} ${ROLES[selfRole.shownRole].name}`
                      : "未設定"}
                  </strong>
                </div>

                {selfRole.shownRole && selfHiddenRolePossibilities.length > 0 && (
                  <div className="self-role-warning">
                    <strong>役職未確定</strong>
                    {selfHiddenRolePossibilities.map((role) => (
                      <div key={role.id}>
                        {role.symbol} {role.name} の可能性あり
                      </div>
                    ))}
                  </div>
                )}

                {selfRole.shownRole && selfHiddenRolePossibilities.length === 0 && (
                  <div className="self-role-confirmed">役職確認済み</div>
                )}

                <div className="status-detail">
                  {selfRole.shownRole && ROLES[selfRole.shownRole].type === "demon"
                    ? `味方：${demonState.knownMinions.length}人${selfRole.shownRole === "imp" ? ` / 襲撃記録：${demonActionLog.length}件` : ""}`
                    : selfRole.shownRole && ROLES[selfRole.shownRole].type === "minion"
                      ? `デーモン：${minionState.knownDemon ? "確認" : "未確認"} / ミニオン行動：${minionActionLog.length}件`
                    : `自分の情報：${selfInfoLog.length}件 / 行動：${selfActionLog.length}件`}
                </div>

                <button
                  className="menu-option"
                  onClick={() => {
                    setPendingSelfRole(selfRole.shownRole);
                    setSelfPanel("role");
                  }}
                >
                  自分の役職
                </button>

                <button
                  className="menu-option"
                  disabled={
                    !selfRole.shownRole ||
                    !ROLES[selfRole.shownRole].tags.includes("INFO_SOURCE")
                  }
                  onClick={openSelfInfoPanel}
                >
                  自分の情報
                </button>

                <button
                  className="menu-option"
                  disabled={
                    selfRole.shownRole !== "monk" &&
                    selfRole.shownRole !== "exorcist" &&
                    selfRole.shownRole !== "slayer"
                  }
                  onClick={openSelfActionPanel}
                >
                  自分の行動
                </button>

                <div className="claim-option-title">主張・公開行動</div>
                <button className="menu-option" onClick={() => openSelfPlayerPanel("claim")}>
                  自分の役職主張
                </button>
                <button className="menu-option" onClick={() => openSelfPlayerPanel("reported_info")}>
                  自分の情報を記録
                </button>
                <button className="menu-option" onClick={() => openSelfPlayerPanel("nomination")}>
                  指名
                </button>
                <button className="menu-option" onClick={() => openSelfPlayerPanel("talk")}>
                  会話
                </button>
                <button className="menu-option" onClick={() => openSelfPlayerPanel("status")}>
                  状態・死亡
                </button>

                {selfRole.shownRole && ROLES[selfRole.shownRole].type === "demon" && (
                  <button className="menu-option evil-mode-button" onClick={() => setSelfPanel("demon")}>
                    デーモンモード
                  </button>
                )}

                {selfRole.shownRole && ROLES[selfRole.shownRole].type === "minion" && (
                  <button className="menu-option evil-mode-button" onClick={() => setSelfPanel("minion")}>
                    ミニオンモード
                  </button>
                )}

                <button className="menu-option" onClick={() => setSelfMenuOpen(false)}>
                  閉じる
                </button>
              </>
            )}

            {selfPanel === "advice" && <><AdvicePanel g={snapshot} r={reasoning.result}/><button className="menu-option" onClick={()=>setSelfPanel("menu")}>{L.back}</button></>}
            {selfPanel === "demon" && selfRole.shownRole && ROLES[selfRole.shownRole].type === "demon" && (
              <DemonModePanel
                g={snapshot}
                state={demonState}
                actions={demonActionLog}
                result={reasoning.result}
                onChange={setDemonState}
                onChangeActions={setDemonActionLog}
                onBack={() => setSelfPanel("menu")}
              />
            )}
            {selfPanel === "minion" && selfRole.shownRole && ROLES[selfRole.shownRole].type === "minion" && (
              <MinionModePanel
                g={snapshot}
                state={minionState}
                actions={minionActionLog}
                demonActions={demonActionLog}
                result={reasoning.result}
                onChange={setMinionState}
                onChangeActions={setMinionActionLog}
                onChangeDemonActions={setDemonActionLog}
                onBack={() => setSelfPanel("menu")}
              />
            )}
            {selfPanel === "role" && (
              <>
                <h2>自分の役職</h2>
                <div className="panel-note">
                  Townsfolk / Minion / Demon を選べます。悪役職は専用モードで味方情報と能力を記録します。
                </div>
                <div className="claim-option-title">Townsfolk</div>
                <div className="role-grid">
                  {currentScriptRoles
                    .filter((role) => role.type === "townsfolk")
                    .map((role) => (
                      <button
                        key={role.id}
                        className={
                          pendingSelfRole === role.id
                            ? "role-choice role-choice-selected"
                            : "role-choice"
                        }
                        onClick={() => setPendingSelfRole(role.id)}
                      >
                        <span className="role-choice-symbol">{role.symbol}</span>
                        <span className="role-choice-name">{role.name}</span>
                      </button>
                    ))}
                </div>
                <div className="claim-option-title">Outsider</div>
                <div className="role-grid">
                  {currentScriptRoles.filter((role) => role.type === "outsider").map((role) => (
                    <button key={role.id} className={pendingSelfRole === role.id ? "role-choice role-choice-selected" : "role-choice"} onClick={() => setPendingSelfRole(role.id)}>
                      <span className="role-choice-symbol">{role.symbol}</span><span className="role-choice-name">{role.name}</span>
                    </button>
                  ))}
                </div>
                <div className="claim-option-title">Minion</div>
                <div className="role-grid minion-role-grid">
                  {currentScriptRoles.filter((role) => role.type === "minion").map((role) => (
                    <button
                      key={role.id}
                      className={pendingSelfRole === role.id ? "role-choice role-choice-selected evil-role-selected" : "role-choice"}
                      onClick={() => setPendingSelfRole(role.id)}
                    >
                      <span className="role-choice-symbol">{role.symbol}</span>
                      <span className="role-choice-name">{role.name}</span>
                    </button>
                  ))}
                </div>
                <div className="claim-option-title">Demon</div>
                <div className="role-grid demon-role-grid">
                  {currentScriptRoles.filter((role) => role.type === "demon").map((role) => (
                    <button
                      key={role.id}
                      className={pendingSelfRole === role.id ? "role-choice role-choice-selected evil-role-selected" : "role-choice"}
                      onClick={() => setPendingSelfRole(role.id)}
                    >
                      <span className="role-choice-symbol">{role.symbol}</span>
                      <span className="role-choice-name">{role.name}</span>
                    </button>
                  ))}
                </div>
                <button
                  className="menu-option confirm-claim-button"
                  disabled={!pendingSelfRole}
                  onClick={() => {
                    if (!pendingSelfRole) {
                      return;
                    }
                    const oldRole = selfRole.shownRole;
                    const oldType = oldRole ? ROLES[oldRole].type : null;
                    const newType = ROLES[pendingSelfRole].type;
                    const changingRole = oldRole !== pendingSelfRole;

                    if (changingRole && oldType === "townsfolk" && (selfInfoLog.length > 0 || selfActionLog.length > 0)) {
                      if (!window.confirm("役職を切り替えると、自分のTownsfolk情報・行動記録を消去します。続けますか？")) return;
                      setSelfInfoLog([]); setSelfActionLog([]);
                    }

                    if (changingRole && oldType === "demon" && (demonState.knownMinions.length > 0 || demonState.storytellerBluffs.length > 0 || demonActionLog.length > 0)) {
                      if (!window.confirm("Demonから切り替えると、悪チーム・ブラフ・襲撃記録を消去します。続けますか？")) return;
                      setDemonState(makeEmptyDemonState()); setDemonActionLog([]);
                    }

                    if (changingRole && oldType === "minion") {
                      const hasMinionData = minionState.knownDemon !== null || minionState.knownMinions.length > 0 ||
                        minionState.sharedStorytellerBluffs.length > 0 || Object.values(minionState.bluffPlans).some(Boolean) ||
                        Object.keys(minionState.spyInitialRoles).length > 0 || minionState.becameDemonAt !== null ||
                        minionActionLog.length > 0 || demonActionLog.length > 0;
                      if (newType !== "minion" && hasMinionData) {
                        if (!window.confirm("Minionから切り替えると、悪チーム・ブラフ・能力記録を消去します。続けますか？")) return;
                        setMinionState(makeEmptyMinionState()); setMinionActionLog([]); setDemonActionLog([]);
                      } else if (newType === "minion" && oldRole !== pendingSelfRole) {
                        if (hasMinionData && !window.confirm("別のMinionに切り替えます。味方・共有ブラフは残し、役職固有記録と継承記録を消去します。続けますか？")) return;
                        setMinionState(current => ({
                          ...current,
                          spyInitialRoles: {},
                          spyRedHerring: null,
                          becameDemonAt: null,
                        }));
                        setMinionActionLog([]); setDemonActionLog([]);
                      }
                    }

                    if (changingRole && oldType !== "townsfolk" && newType === "townsfolk") {
                      setSelfInfoLog([]); setSelfActionLog([]);
                    }
                    setSelfRole({ shownRole: pendingSelfRole });
                    setSelfPanel(newType === "demon" ? "demon" : newType === "minion" ? "minion" : "menu");
                  }}
                >
                  確定
                </button>
                <button className="menu-option" onClick={() => setSelfPanel("menu")}>
                  戻る
                </button>
              </>
            )}

            {selfPanel === "info" && selfRole.shownRole && (
              <>
                <h2>自分の情報</h2>
                <div className="current-claim">
                  <strong>
                    {ROLES[selfRole.shownRole].symbol} {ROLES[selfRole.shownRole].name}
                  </strong>
                </div>

                {selfInfoLog.filter((event) => event.roleId === selfRole.shownRole).length > 0 && (
                  <div className="claim-history">
                    <div className="claim-history-title">過去の情報</div>
                    {selfInfoLog
                      .filter((event) => event.roleId === selfRole.shownRole)
                      .sort(compareEvents)
                      .map((event) => (
                        <div className="claim-history-item" key={event.id}>
                          <span className="claim-history-role">{ROLES[event.roleId].symbol}</span>
                          <span>{event.when}</span>
                          <span>{formatSelfInfoEvent(event)}</span>
                        </div>
                      ))}
                  </div>
                )}

                {(selfRole.shownRole === "washerwoman" ||
                  selfRole.shownRole === "investigator") && (
                  <>
                    <div className="claim-option-title">表示された2人</div>
                    <div className="player-toggle-grid">
                      {getActivePlayers().map((player) => (
                        <button
                          key={player}
                          type="button"
                          className={
                            selfInfoPlayers.includes(player)
                              ? "player-toggle selected"
                              : "player-toggle"
                          }
                          onClick={() => toggleLimitedSelfInfoPlayer(player, 2)}
                        >
                          {getPlayerDisplayName(player)}
                        </button>
                      ))}
                    </div>
                    <div className="form-section">
                      <label>表示された役職</label>
                      <select
                        value={selfInfoShownRole ?? ""}
                        onChange={(event) =>
                          setSelfInfoShownRole(
                            event.target.value ? (event.target.value as RoleId) : null
                          )
                        }
                      >
                        <option value="">選択</option>
                        {getSelfInfoRoleOptions(selfRole.shownRole).map((role) => (
                          <option key={role.id} value={role.id}>
                            {role.symbol} {role.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={
                        selfInfoPlayers.length !== 2 || !selfInfoShownRole
                      }
                      onClick={() =>
                        saveSelfPairInfo(
                          selfRole.shownRole as "washerwoman" | "investigator"
                        )
                      }
                    >
                      確定
                    </button>
                  </>
                )}

                {selfRole.shownRole === "librarian" && (
                  <>
                    <button
                      type="button"
                      className={
                        librarianNoOutsiders
                          ? "player-toggle selected"
                          : "player-toggle"
                      }
                      onClick={() => {
                        setLibrarianNoOutsiders((current) => !current);
                        setSelfInfoPlayers([]);
                        setSelfInfoShownRole(null);
                      }}
                    >
                      アウトサイダーなし
                    </button>

                    {!librarianNoOutsiders && (
                      <>
                        <div className="claim-option-title">表示された2人</div>
                        <div className="player-toggle-grid">
                          {getActivePlayers().map((player) => (
                            <button
                              key={player}
                              type="button"
                              className={
                                selfInfoPlayers.includes(player)
                                  ? "player-toggle selected"
                                  : "player-toggle"
                              }
                              onClick={() =>
                                toggleLimitedSelfInfoPlayer(player, 2)
                              }
                            >
                              {getPlayerDisplayName(player)}
                            </button>
                          ))}
                        </div>
                        <div className="form-section">
                          <label>表示された役職</label>
                          <select
                            value={selfInfoShownRole ?? ""}
                            onChange={(event) =>
                              setSelfInfoShownRole(
                                event.target.value
                                  ? (event.target.value as RoleId)
                                  : null
                              )
                            }
                          >
                            <option value="">選択</option>
                            {getSelfInfoRoleOptions("librarian").map((role) => (
                              <option key={role.id} value={role.id}>
                                {role.symbol} {role.name}
                              </option>
                            ))}
                          </select>
                        </div>
                      </>
                    )}

                    <button
                      className="menu-option confirm-claim-button"
                      disabled={
                        !librarianNoOutsiders &&
                        (selfInfoPlayers.length !== 2 || !selfInfoShownRole)
                      }
                      onClick={saveSelfLibrarianInfo}
                    >
                      確定
                    </button>
                  </>
                )}

                {selfRole.shownRole === "chef" && (
                  <>
                    <div className="claim-option-title">悪の隣接ペア数</div>
                    <div className="player-toggle-grid">
                      {Array.from({length:playerCount+1},(_,i)=>i).map((number) => (
                        <button
                          key={number}
                          type="button"
                          className={
                            selfInfoNumber === number
                              ? "player-toggle selected"
                              : "player-toggle"
                          }
                          onClick={() => setSelfInfoNumber(number)}
                        >
                          {number}
                        </button>
                      ))}
                    </div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={selfInfoNumber===null} onClick={saveSelfChefInfo}
                    >
                      確定
                    </button>
                  </>
                )}

                {selfRole.shownRole === "empath" && (
                  <>
                    <div className="form-section">
                      <label>いつ</label>
                      <select
                        value={selfInfoWhen}
                        onChange={(event) => setSelfInfoWhen(event.target.value)}
                      >
                        {getSelfInfoNightOptions("empath").map((phase) => (
                          <option key={phase} value={phase}>
                            {phase}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="claim-option-title">悪の隣人の数</div>
                    <div className="player-toggle-grid">
                      {[0, 1, 2].map((number) => (
                        <button
                          key={number}
                          type="button"
                          className={
                            selfInfoNumber === number
                              ? "player-toggle selected"
                              : "player-toggle"
                          }
                          onClick={() => setSelfInfoNumber(number)}
                        >
                          {number}
                        </button>
                      ))}
                    </div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={selfInfoNumber===null} onClick={saveSelfEmpathInfo}
                    >
                      確定
                    </button>
                  </>
                )}

                {selfRole.shownRole === "fortune_teller" && (
                  <>
                    <div className="form-section">
                      <label>いつ</label>
                      <select
                        value={selfInfoWhen}
                        onChange={(event) => setSelfInfoWhen(event.target.value)}
                      >
                        {getSelfInfoNightOptions("fortune_teller").map((phase) => (
                          <option key={phase} value={phase}>
                            {phase}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="claim-option-title">選んだ2人</div>
                    <div className="player-toggle-grid">
                      {["self", ...getActivePlayers()].map((player) => (
                        <button
                          key={player}
                          type="button"
                          className={
                            selfInfoPlayers.includes(player)
                              ? "player-toggle selected"
                              : "player-toggle"
                          }
                          onClick={() => toggleLimitedSelfInfoPlayer(player, 2)}
                        >
                          {getPlayerDisplayName(player)}
                        </button>
                      ))}
                    </div>
                    <div className="claim-option-title">結果</div>
                    <div className="visibility-switch">
                      <button
                        className={
                          selfInfoYesNo === "yes"
                            ? "visibility-button visibility-selected"
                            : "visibility-button"
                        }
                        onClick={() => setSelfInfoYesNo("yes")}
                      >
                        はい
                      </button>
                      <button
                        className={
                          selfInfoYesNo === "no"
                            ? "visibility-button visibility-selected"
                            : "visibility-button"
                        }
                        onClick={() => setSelfInfoYesNo("no")}
                      >
                        いいえ
                      </button>
                    </div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={selfInfoPlayers.length !== 2 || selfInfoYesNo===null}
                      onClick={saveSelfFortuneTellerInfo}
                    >
                      確定
                    </button>
                  </>
                )}

                {(selfRole.shownRole === "undertaker" ||
                  selfRole.shownRole === "ravenkeeper") && (
                  <>
                    <div className="form-section">
                      <label>いつ</label>
                      <select
                        value={selfInfoWhen}
                        onChange={(event) => setSelfInfoWhen(event.target.value)}
                      >
                        {getSelfInfoNightOptions(selfRole.shownRole).map((phase) => (
                          <option key={phase} value={phase}>
                            {phase}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="claim-option-title">
                      {selfRole.shownRole === "undertaker"
                        ? "処刑された人"
                        : "選んだ人"}
                    </div>
                    <div className="player-toggle-grid">
                      {(selfRole.shownRole === "ravenkeeper"
                        ? ["self", ...getActivePlayers()]
                        : getActivePlayers()
                      ).map((player) => (
                        <button
                          key={player}
                          type="button"
                          className={
                            selfInfoPlayers[0] === player
                              ? "player-toggle selected"
                              : "player-toggle"
                          }
                          onClick={() =>
                            setSelfInfoPlayers(
                              selfInfoPlayers[0] === player ? [] : [player]
                            )
                          }
                        >
                          {getPlayerDisplayName(player)}
                        </button>
                      ))}
                    </div>
                    <div className="form-section">
                      <label>表示された役職</label>
                      <select
                        value={selfInfoShownRole ?? ""}
                        onChange={(event) =>
                          setSelfInfoShownRole(
                            event.target.value ? (event.target.value as RoleId) : null
                          )
                        }
                      >
                        <option value="">選択</option>
                        {getSelfInfoRoleOptions(selfRole.shownRole).map((role) => (
                          <option key={role.id} value={role.id}>
                            {role.symbol} {role.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={
                        selfInfoPlayers.length !== 1 || !selfInfoShownRole || !getSelfInfoNightOptions(selfRole.shownRole).includes(selfInfoWhen)
                      }
                      onClick={() =>
                        saveSelfRoleRevealInfo(
                          selfRole.shownRole as "undertaker" | "ravenkeeper"
                        )
                      }
                    >
                      確定
                    </button>
                  </>
                )}

                <button
                  className="menu-option"
                  disabled={!latestSelfInfoToUndo}
                  onClick={() => latestSelfInfoToUndo && deleteHistory("selfInfoLog", latestSelfInfoToUndo.id)}
                >
                  取り消し
                </button>
                <button
                  className="menu-option"
                  onClick={() => {
                    resetSelfInfoForm();
                    setSelfPanel("menu");
                  }}
                >
                  戻る
                </button>
              </>
            )}

            {selfPanel === "action" && selfRole.shownRole && (
              <>
                <h2>自分の行動</h2>
                <div className="current-claim">
                  <strong>
                    {ROLES[selfRole.shownRole].symbol} {ROLES[selfRole.shownRole].name}
                  </strong>
                </div>

                {selfActionLog.filter((event) => event.roleId === selfRole.shownRole).length > 0 && (
                  <div className="claim-history">
                    <div className="claim-history-title">過去の行動</div>
                    {selfActionLog
                      .filter((event) => event.roleId === selfRole.shownRole)
                      .sort(compareEvents)
                      .map((event) => (
                        <div className="claim-history-item" key={event.id}>
                          <span className="claim-history-role">{ROLES[event.roleId].symbol}</span>
                          <span>{event.when}</span>
                          <span>{getPlayerDisplayName(event.target)}{event.roleId === "slayer" ? ` → ${event.killed ? "死亡" : "死亡なし"}` : ""}</span>
                        </div>
                      ))}
                  </div>
                )}

                {selfRole.shownRole === "monk" && (
                  <>
                    <div className="form-section">
                      <label>いつ</label>
                      <select
                        value={selfActionWhen}
                        onChange={(event) => setSelfActionWhen(event.target.value)}
                      >
                        {getNightOptions(2).map((phase) => (
                          <option key={phase} value={phase}>
                            {phase}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="claim-option-title">守った人</div>
                    <div className="player-toggle-grid">
                      {getActivePlayers().map((player) => (
                        <button
                          key={player}
                          type="button"
                          className={
                            selfActionTarget === player
                              ? "player-toggle selected"
                              : "player-toggle"
                          }
                          onClick={() =>
                            setSelfActionTarget(
                              selfActionTarget === player ? null : player
                            )
                          }
                        >
                          {getPlayerDisplayName(player)}
                        </button>
                      ))}
                    </div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={!selfActionTarget || !getNightOptions(2).includes(selfActionWhen)}
                      onClick={saveSelfMonkAction}
                    >
                      確定
                    </button>
                  </>
                )}

                {selfRole.shownRole === "exorcist" && (
                  <>
                    <div className="form-section">
                      <label>いつ</label>
                      <select
                        value={selfActionWhen}
                        onChange={(event) => setSelfActionWhen(event.target.value)}
                      >
                        {getNightOptions(2).map((phase) => (
                          <option key={phase} value={phase}>
                            {phase}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="claim-option-title">選んだ人</div>
                    <div className="player-toggle-grid">
                      {["self", ...getActivePlayers()].map((player) => {
                        const previous = selfActionLog
                          .filter((event) => event.roleId === "exorcist" && compareEvents(event, { when: selfActionWhen, id: Infinity }) < 0)
                          .sort(compareEvents)
                          .at(-1);
                        const blocked = previous?.target === player;
                        return (
                          <button
                            key={player}
                            type="button"
                            disabled={blocked}
                            className={
                              selfActionTarget === player
                                ? "player-toggle selected"
                                : "player-toggle"
                            }
                            onClick={() =>
                              setSelfActionTarget(
                                selfActionTarget === player ? null : player
                              )
                            }
                          >
                            {getPlayerDisplayName(player)}
                          </button>
                        );
                      })}
                    </div>
                    <div className="panel-note">前の夜と同じ人は選べません。死亡が0人なら、選んだ相手のデーモン疑いを弱く上げます。</div>
                    <button
                      className="menu-option confirm-claim-button"
                      disabled={!selfActionTarget || !getNightOptions(2).includes(selfActionWhen)}
                      onClick={saveSelfExorcistAction}
                    >
                      確定
                    </button>
                  </>
                )}

                {selfRole.shownRole === "slayer" && (
                  <>
                    {selfActionLog.some((event) => event.roleId === "slayer") ? (
                      <div className="panel-note">処刑人の能力は既に使用済みです。</div>
                    ) : (
                      <>
                        <div className="form-section">
                          <label>いつ</label>
                          <select
                            value={selfActionWhen}
                            onChange={(event) => setSelfActionWhen(event.target.value)}
                          >
                            {getDayOptions().map((phase) => (
                              <option key={phase} value={phase}>
                                {phase}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="claim-option-title">対象</div>
                        <div className="player-toggle-grid">
                          {getActivePlayers().map((player) => (
                            <button
                              key={player}
                              type="button"
                              className={
                                selfActionTarget === player
                                  ? "player-toggle selected"
                                  : "player-toggle"
                              }
                              onClick={() =>
                                setSelfActionTarget(
                                  selfActionTarget === player ? null : player
                                )
                              }
                            >
                              {getPlayerDisplayName(player)}
                            </button>
                          ))}
                        </div>
                        <div className="claim-option-title">結果</div>
                        <div className="visibility-switch">
                          <button
                            className={
                              !selfSlayerKilled
                                ? "visibility-button visibility-selected"
                                : "visibility-button"
                            }
                            onClick={() => setSelfSlayerKilled(false)}
                          >
                            死亡なし
                          </button>
                          <button
                            className={
                              selfSlayerKilled
                                ? "visibility-button visibility-selected"
                                : "visibility-button"
                            }
                            onClick={() => setSelfSlayerKilled(true)}
                          >
                            死亡
                          </button>
                        </div>
                        <button
                          className="menu-option confirm-claim-button"
                          disabled={!selfActionTarget}
                          onClick={saveSelfSlayerAction}
                        >
                          確定
                        </button>
                      </>
                    )}
                  </>
                )}

                <button
                  className="menu-option"
                  disabled={!latestSelfActionToUndo}
                  onClick={() => latestSelfActionToUndo && deleteHistory("selfActionLog", latestSelfActionToUndo.id)}
                >
                  取り消し
                </button>
                <button
                  className="menu-option"
                  onClick={() => {
                    resetSelfActionForm();
                    setSelfPanel("menu");
                  }}
                >
                  戻る
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {endGameOpen && (
        <div className="menu-overlay" onClick={() => setEndGameOpen(false)}>
          <div className="game-menu" onClick={(event) => event.stopPropagation()}>
            <h2>ゲーム終了</h2>
            <p className="panel-note">勝敗を選択してください。選んだ結果と現在の記録をゲームログに保存して終了します。</p>
            <button className="menu-option" onClick={() => finishCurrentGame("evil")}>
              デーモン勝利
            </button>
            <button className="menu-option" onClick={() => finishCurrentGame("good")}>
              町勝利
            </button>
            <button className="menu-option" onClick={() => finishCurrentGame("special")}>
              特殊条件勝利
            </button>
            <button className="menu-option" onClick={() => setEndGameOpen(false)}>
              戻る
            </button>
          </div>
        </div>
      )}

      {menuOpen && (
        <div className="menu-overlay" onClick={() => setMenuOpen(false)}>
          <div className="game-menu" onClick={(event) => event.stopPropagation()}>
            <h2>メニュー</h2>
            <button className="menu-option" onClick={()=>{setMenuOpen(false);openAnalysis();}}>{L.analysis} / {L.history}</button>
            <button className="menu-option" onClick={()=>{setMenuOpen(false);openAnalysis(null,"worlds");}}>候補盤面を確認</button>
            <button className="menu-option" onClick={()=>archiveCurrentGame("snapshot")}>現在のゲームをログに保存</button>
            <button className="menu-option" onClick={()=>{setMenuOpen(false);setGameLogOpen(true);}}>ゲームログ ({gameLogs.length})</button>
            <button className="menu-option" onClick={()=>downloadSnapshot(snapshot)}>{L.export}</button>
            <button className="menu-option" onClick={()=>importRef.current?.click()}>{L.import}</button>
            <p className="panel-note">{saveFailed?L.saveError:L.saved}</p>
            <button
              className="menu-option"
              onClick={confirmUndoNight}
              disabled={night <= 1 || checkpoints.length === 0}
            >
              夜を戻す
            </button>
            <button className="menu-option danger-button" onClick={confirmEndGame}>
              ゲーム終了
            </button>
            <button className="menu-option" onClick={() => setMenuOpen(false)}>
              閉じる
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

export default App;
