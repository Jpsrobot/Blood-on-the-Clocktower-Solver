import { useMemo, useState } from "react";
import { ROLES, type RoleId } from "../roles";
import { getSnapshotScriptRoleIds } from "../scripts";
import type {
  DemonActionEvent,
  GameSnapshot,
  KnownMinion,
  MinionActionEvent,
  MinionState,
} from "../types";
import type { SearchResult } from "../engine/model";
import { useSpyBluffAdvisor } from "../engine/useSpyBluffAdvisor";
import { exactClaim, seats, setupCounts } from "../engine/game";
import { eventId } from "../storage";
import { person } from "./text";

type Props = {
  g: GameSnapshot;
  state: MinionState;
  actions: MinionActionEvent[];
  demonActions: DemonActionEvent[];
  result: SearchResult | null;
  onChange: (state: MinionState) => void;
  onChangeActions: (events: MinionActionEvent[]) => void;
  onChangeDemonActions: (events: DemonActionEvent[]) => void;
  onBack: () => void;
};

type BluffStatus =
  | "shared"
  | "spy-safe"
  | "in-play"
  | "opponent"
  | "ally"
  | "unclaimed";

function latestExactClaim(g: GameSnapshot, player: string): RoleId | null {
  return exactClaim(g, player);
}

function roleLabel(roleId: RoleId | null | undefined) {
  if (!roleId) return "未確認";
  const role = ROLES[roleId];
  return `${role.symbol} ${role.name}`;
}

function poisonScore(g: GameSnapshot, p: string, result: SearchResult | null): number {
  const claim = latestExactClaim(g, p);
  const role = claim ? ROLES[claim] : null;
  let score = 0;
  if (role?.tags.includes("CONTINUOUS_INFO")) score += 5;
  if (role?.tags.includes("HIGH_SURVIVAL_VALUE")) score += 2;
  if (role?.tags.includes("PREVENTS_DEATH") || role?.tags.includes("PREVENTS_EXECUTION_DEATH")) score += 4;
  if (claim === "slayer") score += 4;
  if (claim === "virgin") score += 3;
  if (claim === "soldier") score += 3;
  if (claim === "ravenkeeper") score += 2;
  if (claim === "mayor") score += 3;
  if (role?.tags.includes("FIRST_NIGHT_INFO") && g.night > 1) score -= 2;
  if (role && role.type === "outsider") score -= 1;
  const evil = result?.players[p]?.evil;
  if (evil !== undefined) score += (0.5 - evil) * 2;
  return score;
}

function poisonReasons(g: GameSnapshot, p: string, result: SearchResult | null): string[] {
  const claim = latestExactClaim(g, p);
  const role = claim ? ROLES[claim] : null;
  const reasons: string[] = [];
  if (role?.tags.includes("CONTINUOUS_INFO")) reasons.push("継続情報を止められる主張");
  if (role?.tags.includes("PREVENTS_DEATH")) reasons.push("死亡防止能力を止められる主張");
  if (role?.tags.includes("PREVENTS_EXECUTION_DEATH")) reasons.push("処刑死防止能力を止められる主張");
  if (claim === "slayer") reasons.push("処刑人の一回能力を失敗させ得る");
  if (claim === "virgin") reasons.push("処女の公開確認を止め得る");
  if (claim === "soldier") reasons.push("兵士の耐性を止め得る");
  if (claim === "ravenkeeper") reasons.push("死亡時情報を無効化できる可能性");
  if (claim === "mayor") reasons.push("市長の能力を止め得る");
  if (result?.players[p]?.evil !== undefined && result.players[p].evil < 0.2) {
    reasons.push("候補盤面では善側寄り");
  }
  if (!claim) reasons.push("役職主張未記録");
  return reasons;
}

function phaseNumber(when: string) {
  return Number(when.slice(1));
}

export function MinionModePanel({
  g,
  state,
  actions,
  demonActions,
  result,
  onChange,
  onChangeActions,
  onChangeDemonActions,
  onBack,
}: Props) {
  const spyBluffAdvisor = useSpyBluffAdvisor(g, g.selfRole.shownRole === "spy");
  const selfRoleId = g.selfRole.shownRole;
  if (!selfRoleId || ROLES[selfRoleId].type !== "minion") {
    return <button className="menu-option" onClick={onBack}>戻る</button>;
  }

  const selfRole = ROLES[selfRoleId];
  const scriptRoles = getSnapshotScriptRoleIds(g).map(id => ROLES[id]);
  const GOOD_ROLES = scriptRoles.filter(role => role.type === "townsfolk" || role.type === "outsider");
  const MINION_ROLES = scriptRoles.filter(role => role.type === "minion");
  const getsStartingInfo = g.playerCount >= 7;
  const allPlayers = seats(g.playerCount);
  const others = allPlayers.filter((p) => p !== "self");
  const minionCount = setupCounts(g.playerCount).minion;
  const fellowMinionCount = Math.max(0, minionCount - 1);
  const knownDemon = state.knownDemon?.playerId ?? null;
  const knownMinionSet = new Set(state.knownMinions.map((m) => m.playerId));
  const knownEvilSet = new Set([
    "self",
    ...(knownDemon ? [knownDemon] : []),
    ...state.knownMinions.map((m) => m.playerId),
  ]);

  const [poisonNight, setPoisonNight] = useState(`N${Math.max(1, g.night)}`);
  const [poisonTarget, setPoisonTarget] = useState<string | null>(null);
  const [poisonNote, setPoisonNote] = useState("");
  const [spyNight, setSpyNight] = useState(`N${Math.max(1, g.night)}`);
  const [spyPoisonTarget, setSpyPoisonTarget] = useState<string | null>(null);
  const [spyNote, setSpyNote] = useState("");
  const [pitHagNight, setPitHagNight] = useState(`N${Math.max(2, g.night)}`);
  const [pitHagTarget, setPitHagTarget] = useState<string | null>(null);
  const [pitHagNewRole, setPitHagNewRole] = useState<RoleId | null>(null);
  const [pitHagNote, setPitHagNote] = useState("");
  const [demonAttackNight, setDemonAttackNight] = useState(`N${Math.max(2, g.night)}`);
  const [demonAttackTarget, setDemonAttackTarget] = useState<string | null>(null);
  const [demonAttackNote, setDemonAttackNote] = useState("");

  const nightOptions = Array.from({ length: g.night }, (_, i) => `N${i + 1}`);
  const minionAbilityNightOptions = nightOptions.filter(
    (phase) => !state.becameDemonAt || phaseNumber(phase) <= phaseNumber(state.becameDemonAt)
  );
  const pitHagNightOptions = minionAbilityNightOptions.filter((phase) => phaseNumber(phase) >= 2);
  const attackNightOptions = Array.from({ length: Math.max(0, g.night - 1) }, (_, i) => `N${i + 2}`);
  const phaseOptions = Array.from({ length: g.night }, (_, i) => [`N${i + 1}`, `D${i + 1}`]).flat();

  function setKnownDemon(playerId: string | null) {
    const nextMinions = state.knownMinions.filter((m) => m.playerId !== playerId);
    const bluffPlans = { ...state.bluffPlans };
    if (knownDemon && knownDemon !== playerId && !knownMinionSet.has(knownDemon)) delete bluffPlans[knownDemon];
    onChange({
      ...state,
      knownDemon: playerId
        ? { playerId, source: getsStartingInfo ? "minion_info" : "confirmed_later" }
        : null,
      knownMinions: nextMinions,
      bluffPlans,
    });
  }

  function toggleKnownMinion(playerId: string) {
    if (playerId === knownDemon) return;
    const existing = state.knownMinions.find((m) => m.playerId === playerId);
    if (existing) {
      const bluffPlans = { ...state.bluffPlans };
      delete bluffPlans[playerId];
      onChange({
        ...state,
        knownMinions: state.knownMinions.filter((m) => m.playerId !== playerId),
        bluffPlans,
      });
      return;
    }
    if (state.knownMinions.length >= fellowMinionCount) return;
    const item: KnownMinion = {
      playerId,
      source: getsStartingInfo ? "minion_info" : "confirmed_later",
      roleId: null,
    };
    onChange({ ...state, knownMinions: [...state.knownMinions, item] });
  }

  function setKnownMinionRole(playerId: string, roleId: RoleId | null) {
    onChange({
      ...state,
      knownMinions: state.knownMinions.map((m) =>
        m.playerId === playerId ? { ...m, roleId } : m
      ),
    });
  }

  function toggleSharedBluff(roleId: RoleId) {
    if (!getsStartingInfo) return;
    const current = state.sharedStorytellerBluffs;
    if (current.includes(roleId)) {
      onChange({ ...state, sharedStorytellerBluffs: current.filter((r) => r !== roleId) });
      return;
    }
    if (current.length >= 3) return;
    onChange({ ...state, sharedStorytellerBluffs: [...current, roleId] });
  }

  function setBluffPlan(playerId: string, roleId: RoleId | null) {
    onChange({
      ...state,
      bluffPlans: { ...state.bluffPlans, [playerId]: roleId },
    });
  }

  function setSpyInitialRole(playerId: string, roleId: RoleId | null) {
    const next = { ...state.spyInitialRoles };
    if (roleId) next[playerId] = roleId;
    else delete next[playerId];
    if (playerId === "self") next.self = "spy";
    onChange({ ...state, spyInitialRoles: next });
  }

  function savePoison() {
    if (!poisonTarget || !minionAbilityNightOptions.includes(poisonNight)) return;
    const old = actions.find((a) => a.roleId === "poisoner" && a.when === poisonNight);
    if (old && !window.confirm(`${poisonNight}の毒対象は既に記録されています。置き換えますか？`)) return;
    const next: MinionActionEvent = {
      id: eventId(),
      roleId: "poisoner",
      kind: "poison",
      when: poisonNight,
      target: poisonTarget,
      note: poisonNote.trim() || null,
    };
    onChangeActions([
      ...actions.filter((a) => !(a.roleId === "poisoner" && a.when === poisonNight)),
      next,
    ]);
    setPoisonTarget(null);
    setPoisonNote("");
  }

  function saveSpyNight() {
    if (!minionAbilityNightOptions.includes(spyNight)) return;
    const old = actions.find((a) => a.roleId === "spy" && a.when === spyNight);
    if (old && !window.confirm(`${spyNight}のグリモア記録は既にあります。置き換えますか？`)) return;
    const next: MinionActionEvent = {
      id: eventId(),
      roleId: "spy",
      kind: "grimoire",
      when: spyNight,
      poisonTarget: spyPoisonTarget,
      note: spyNote.trim() || null,
    };
    onChangeActions([
      ...actions.filter((a) => !(a.roleId === "spy" && a.when === spyNight)),
      next,
    ]);
    setSpyPoisonTarget(null);
    setSpyNote("");
  }

  function savePitHag() {
    if (!pitHagTarget || !pitHagNewRole || !pitHagNightOptions.includes(pitHagNight)) return;
    const old = actions.find((a) => a.roleId === "pit_hag" && a.when === pitHagNight);
    if (old && !window.confirm(`${pitHagNight}の変身先は既に記録されています。置き換えますか？`)) return;
    const next: MinionActionEvent = {
      id: eventId(),
      roleId: "pit_hag",
      kind: "transform",
      when: pitHagNight,
      target: pitHagTarget,
      newRole: pitHagNewRole,
      note: pitHagNote.trim() || null,
    };
    onChangeActions([
      ...actions.filter((a) => !(a.roleId === "pit_hag" && a.when === pitHagNight)),
      next,
    ]);
    setPitHagTarget(null);
    setPitHagNewRole(null);
    setPitHagNote("");
  }

  function undoLatestPitHag() {
    const latest = actions
      .filter((a): a is Extract<MinionActionEvent, { roleId: "pit_hag" }> => a.roleId === "pit_hag")
      .sort((a, b) => phaseNumber(b.when) - phaseNumber(a.when) || b.id - a.id)[0];
    if (!latest) return;
    if (window.confirm(`${latest.when}の変身記録を取り消しますか？`)) {
      onChangeActions(actions.filter((a) => a.id !== latest.id));
    }
  }

  function saveDemonAttack() {
    if (!demonAttackTarget || !attackNightOptions.includes(demonAttackNight)) return;
    const transition = state.becameDemonAt;
    // A Minion that becomes the Imp does not immediately act again in the same
    // night. Its first normal Demon attack is on the following night.
    if (!transition || phaseNumber(demonAttackNight) <= phaseNumber(transition)) return;
    const old = demonActions.find((a) => a.when === demonAttackNight);
    if (old && !window.confirm(`${demonAttackNight}の襲撃は既に記録されています。置き換えますか？`)) return;
    const next: DemonActionEvent = {
      id: eventId(),
      roleId: "imp",
      when: demonAttackNight,
      target: demonAttackTarget,
      note: demonAttackNote.trim() || null,
    };
    onChangeDemonActions([...demonActions.filter((a) => a.when !== demonAttackNight), next]);
    setDemonAttackTarget(null);
    setDemonAttackNote("");
  }

  function opponentClaimersFor(roleId: RoleId) {
    return others.filter((p) => !knownEvilSet.has(p) && latestExactClaim(g, p) === roleId);
  }

  const teamMembers = [
    "self",
    ...(knownDemon ? [knownDemon] : []),
    ...state.knownMinions.map((m) => m.playerId),
  ];
  const teamPlanUsers = new Map<RoleId, string[]>();
  for (const [player, role] of Object.entries(state.bluffPlans)) {
    if (!role) continue;
    const list = teamPlanUsers.get(role) ?? [];
    list.push(player);
    teamPlanUsers.set(role, list);
  }

  const spyEnteredRoles = {
    ...(selfRoleId === "spy" ? { self: "spy" as RoleId } : {}),
    ...Object.fromEntries(Object.entries(state.spyInitialRoles).filter(([, role]) => !!role)),
  } as Record<string, RoleId>;
  const spySetupComplete = selfRoleId === "spy" && Object.keys(spyEnteredRoles).length === g.playerCount;
  const spyInPlay = new Set(Object.values(spyEnteredRoles));

  const bluffRows = GOOD_ROLES.map((role) => {
    const claimers = opponentClaimersFor(role.id);
    const allyUsers = teamPlanUsers.get(role.id) ?? [];
    let status: BluffStatus = "unclaimed";
    if (state.sharedStorytellerBluffs.includes(role.id)) status = "shared";
    else if (selfRoleId === "spy" && spyInPlay.has(role.id)) status = "in-play";
    else if (selfRoleId === "spy" && spySetupComplete && !spyInPlay.has(role.id)) status = "spy-safe";
    else if (claimers.length) status = "opponent";
    else if (allyUsers.length) status = "ally";
    return { role, status, claimers, allyUsers };
  }).sort((a, b) => {
    const order: Record<BluffStatus, number> = {
      shared: 0,
      "spy-safe": 1,
      unclaimed: 2,
      ally: 3,
      opponent: 4,
      "in-play": 5,
    };
    return order[a.status] - order[b.status] || a.role.name.localeCompare(b.role.name, "ja");
  });

  const poisonSuggestions = useMemo(() => {
    if (selfRoleId !== "poisoner") return [];
    return others
      .filter((p) => !knownEvilSet.has(p) && g.playerStatus[p]?.alive !== false)
      .map((player) => ({
        player,
        score: poisonScore(g, player, result),
        reasons: poisonReasons(g, player, result),
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 4);
  }, [g, result, selfRoleId, state.knownDemon, state.knownMinions]);

  const poisonHint = (() => {
    if (!poisonTarget) return null;
    if (poisonTarget === "self") return "自分を選ぶ特殊ケースです。現在の推理エンジンでは有効な毒対象なしとして扱います。";
    if (poisonTarget === knownDemon) return "デーモンを毒にすると、その夜のデーモン能力が働かない可能性があります。味方と必ず連携してください。";
    if (knownMinionSet.has(poisonTarget)) return "味方ミニオンを毒にします。緋色の女などの能力も止まり得るため、作戦目的を確認してください。";
    const claim = latestExactClaim(g, poisonTarget);
    if (claim === "soldier") return "兵士が本物なら、その夜のデーモン襲撃への耐性を止められます。";
    if (claim === "monk") return "僧侶が本物なら、その夜の防御能力を止められます。";
    if (claim === "slayer") return "処刑人が本物なら、翌日の一回能力を失敗させ得ます。";
    if (claim === "virgin") return "処女が本物なら、翌日の最初の指名による公開確認を止め得ます。";
    if (claim === "ravenkeeper") return "鴉飼いが今夜死亡した場合、その情報能力を無効化できます。";
    if (claim === "mayor") return "市長が本物なら、襲撃転送や最終3人の能力を止め得ます。";
    return null;
  })();

  const adjusted = setupCounts(g.playerCount, selfRoleId === "baron");
  const base = setupCounts(g.playerCount, false);
  const outsiderClaimers = others.filter((p) => {
    const role = latestExactClaim(g, p);
    return role ? ROLES[role].type === "outsider" : false;
  });

  const currentDemonShare = result?.players.self?.demon;

  const spyBluffDisplay = (() => {
    const advisor = spyBluffAdvisor.result;
    if (!advisor) return [];
    const preferred = advisor.recommendedRoleId
      ? advisor.candidates.find((candidate) => candidate.roleId === advisor.recommendedRoleId)
      : undefined;
    return [
      ...(preferred ? [preferred] : []),
      ...advisor.candidates.filter((candidate) => candidate.roleId !== preferred?.roleId),
    ].slice(0, 6);
  })();

  return (
    <>
      <h2>ミニオンモード</h2>
      <div className="evil-mode-banner minion-mode-banner">
        <strong>{selfRole.symbol} {selfRole.name}</strong>
        <span>悪チーム情報・ブラフ・役職固有能力を記録</span>
      </div>

      <section className="evil-section">
        <h3>悪チーム</h3>
        {getsStartingInfo ? (
          <p className="panel-note">
            7人以上では、初夜にミニオンはデーモンと他のミニオンのプレイヤーを知ります。ミニオン同士の正確な役職は初夜情報では分かりません。
          </p>
        ) : (
          <p className="panel-note">
            5〜6人では開始時に悪チーム情報を受け取りません。後から確認できた相手だけ登録してください。
          </p>
        )}

        <div className="claim-option-title">デーモン</div>
        <div className="player-toggle-grid">
          {others.map((player) => (
            <button
              key={player}
              type="button"
              disabled={knownMinionSet.has(player)}
              className={knownDemon === player ? "player-toggle selected demon-known-selected" : "player-toggle"}
              onClick={() => setKnownDemon(knownDemon === player ? null : player)}
            >
              {person(g, player)}
            </button>
          ))}
        </div>
        <p className="panel-note">
          {knownDemon
            ? `${person(g, knownDemon)} をデーモンとして固定します。`
            : getsStartingInfo
              ? "初夜に示されたデーモンを選択してください。"
              : "未確認でも問題ありません。"}
        </p>

        {fellowMinionCount > 0 && (
          <>
            <div className="claim-option-title">他のミニオン {state.knownMinions.length}/{fellowMinionCount}</div>
            <div className="player-toggle-grid">
              {others.map((player) => (
                <button
                  key={player}
                  type="button"
                  disabled={player === knownDemon}
                  className={knownMinionSet.has(player) ? "player-toggle selected evil-selected" : "player-toggle"}
                  onClick={() => toggleKnownMinion(player)}
                >
                  {person(g, player)}
                </button>
              ))}
            </div>
          </>
        )}

        {state.knownMinions.length > 0 && (
          <div className="evil-team-list">
            {state.knownMinions.map((m) => (
              <div key={m.playerId} className="evil-team-row">
                <strong>{person(g, m.playerId)}</strong>
                <span>{latestExactClaim(g, m.playerId) ? `現在の主張: ${roleLabel(latestExactClaim(g, m.playerId))}` : "現在の主張: 未記録"}</span>
                <small>{m.source === "minion_info" ? "初夜のミニオン情報" : "後から味方と確認"}</small>
                <label className="evil-team-role-label">
                  実役職を後から確認した場合
                  <select
                    value={m.roleId ?? ""}
                    onChange={(e) => setKnownMinionRole(m.playerId, e.target.value ? (e.target.value as RoleId) : null)}
                  >
                    <option value="">未確認</option>
                    {MINION_ROLES.map((role) => {
                      const used = role.id === selfRoleId || state.knownMinions.some((x) => x.playerId !== m.playerId && x.roleId === role.id);
                      return (
                        <option key={role.id} value={role.id} disabled={used}>
                          {role.symbol} {role.name}{used ? " — 使用済み" : ""}
                        </option>
                      );
                    })}
                  </select>
                </label>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="evil-section">
        <h3>デーモンから共有されたSTブラフ</h3>
        {getsStartingInfo ? (
          <>
            <p className="panel-note">
              デーモンがStorytellerから受け取った3つの不在役職を共有してくれた場合だけ登録します。登録した役職は候補盤面から除外します。 {state.sharedStorytellerBluffs.length}/3
            </p>
            <div className="role-grid">
              {GOOD_ROLES.map((role) => (
                <button
                  key={role.id}
                  type="button"
                  className={state.sharedStorytellerBluffs.includes(role.id) ? "role-choice role-choice-selected evil-role-selected" : "role-choice"}
                  onClick={() => toggleSharedBluff(role.id)}
                >
                  <span className="role-choice-symbol">{role.symbol}</span>
                  <span className="role-choice-name">{role.name}</span>
                </button>
              ))}
            </div>
          </>
        ) : (
          <p className="panel-note">5〜6人では通常の開始時STブラフはありません。</p>
        )}
      </section>

      <section className="evil-section">
        <h3>味方のブラフ計画</h3>
        <p className="panel-note">作戦メモです。候補盤面の真偽には使いません。</p>
        {teamMembers.map((player) => (
          <div className="evil-plan-row" key={player}>
            <label>{person(g, player)}</label>
            <select
              value={state.bluffPlans[player] ?? ""}
              onChange={(e) => setBluffPlan(player, e.target.value ? (e.target.value as RoleId) : null)}
            >
              <option value="">未設定</option>
              {GOOD_ROLES.map((role) => (
                <option key={role.id} value={role.id}>
                  {role.symbol} {role.name}
                  {state.sharedStorytellerBluffs.includes(role.id)
                    ? " — 共有ST安全"
                    : selfRoleId === "spy" && spySetupComplete && !spyInPlay.has(role.id)
                      ? " — Spy表示不在"
                      : opponentClaimersFor(role.id).length
                        ? " — 相手主張"
                        : ""}
                </option>
              ))}
            </select>
          </div>
        ))}
      </section>

      <section className="evil-section">
        <h3>ブラフ候補 / 相手の主張</h3>
        <p className="panel-note">
          共有ST安全は本当に不在と分かる役職です。全グリモア入力時の「Spy表示不在」は密が健康なら強い情報ですが、自分が毒なら誤表示の可能性があります。未主張は安全確定ではありません。
        </p>
        <div className="bluff-board">
          {bluffRows.map(({ role, status, claimers, allyUsers }) => (
            <div className={`bluff-row bluff-${status}`} key={role.id}>
              <span className="bluff-role"><strong>{role.symbol}</strong> {role.name}</span>
              <span className="bluff-status">
                {status === "shared" && "共有ST安全"}
                {status === "spy-safe" && "Spy表示不在"}
                {status === "in-play" && "Spy表示: 実在"}
                {status === "unclaimed" && "未主張 / 不明"}
                {claimers.length > 0 && `${status === "shared" || status === "spy-safe" ? " / " : ""}相手主張: ${claimers.map((p) => person(g, p)).join(" / ")}`}
                {allyUsers.length > 0 && `${status !== "unclaimed" || claimers.length > 0 ? " / " : ""}味方使用: ${allyUsers.map((p) => person(g, p)).join(" / ")}`}
              </span>
            </div>
          ))}
        </div>
      </section>

      {selfRoleId === "poisoner" && (
        <section className="evil-section">
          <h3>毒対象</h3>
          <p className="panel-note">毎夜1人を記録します。記録した対象は候補盤面の毒スケジュールを直接固定します。</p>
          <div className="form-section">
            <label>いつ</label>
            <select value={poisonNight} onChange={(e) => setPoisonNight(e.target.value)}>
              {minionAbilityNightOptions.map((phase) => <option key={phase} value={phase}>{phase}</option>)}
            </select>
          </div>
          <div className="claim-option-title">選んだ人</div>
          <div className="player-toggle-grid">
            {allPlayers.map((player) => (
              <button
                key={player}
                type="button"
                className={poisonTarget === player ? "player-toggle selected poison-selected" : "player-toggle"}
                onClick={() => setPoisonTarget(poisonTarget === player ? null : player)}
              >
                {person(g, player)}{g.playerStatus[player]?.alive === false ? " †" : ""}
              </button>
            ))}
          </div>
          {poisonHint && <p className="panel-note poison-target-hint">{poisonHint}</p>}
          <div className="form-section">
            <label>作戦メモ（任意）</label>
            <textarea value={poisonNote} maxLength={500} onChange={(e) => setPoisonNote(e.target.value)} placeholder="例：占い師主張を止める / デーモンとノーキル連携" />
          </div>
          <button className="menu-option confirm-claim-button evil-confirm" disabled={!poisonTarget} onClick={savePoison}>毒を記録</button>

          {poisonSuggestions.length > 0 && (
            <div className="target-suggestions">
              <h4>毒候補</h4>
              <p className="panel-note">主張と現在の候補盤面を使った軽い優先候補です。味方は候補から外しています。</p>
              {poisonSuggestions.map((s) => (
                <button key={s.player} className="target-suggestion" onClick={() => setPoisonTarget(s.player)}>
                  <strong>{person(g, s.player)}</strong>
                  <span>{s.reasons.join(" / ") || "比較材料が少ない"}</span>
                </button>
              ))}
            </div>
          )}

          {actions.filter((a) => a.roleId === "poisoner").length > 0 && (
            <div className="claim-history">
              <div className="claim-history-title">毒履歴</div>
              {actions.filter((a): a is Extract<MinionActionEvent, { roleId: "poisoner" }> => a.roleId === "poisoner")
                .sort((a, b) => phaseNumber(b.when) - phaseNumber(a.when))
                .map((a) => (
                  <div className="demon-action-row" key={a.id}>
                    <div><strong>{a.when}</strong> → {person(g, a.target)}</div>
                    {a.note && <span>{a.note}</span>}
                    <button type="button" className="mini-danger-button" onClick={() => {
                      if (window.confirm(`${a.when}の毒記録を削除しますか？`)) onChangeActions(actions.filter((x) => x.id !== a.id));
                    }}>削除</button>
                  </div>
                ))}
            </div>
          )}
        </section>
      )}

      {selfRoleId === "pit_hag" && (
        <section className="evil-section">
          <h3>変身</h3>
          <p className="panel-note">
            毎夜（初夜を除く）1人と役職を選びます。その役職がその時点で不在なら対象の役職が変わります。陣営は変わりません。
            既にその役職がいる場合は何も起きません。
          </p>
          <div className="form-section">
            <label>いつ</label>
            <select value={pitHagNight} onChange={(e) => setPitHagNight(e.target.value)} disabled={pitHagNightOptions.length === 0}>
              {pitHagNightOptions.map((phase) => <option key={phase} value={phase}>{phase}</option>)}
            </select>
          </div>
          <div className="claim-option-title">選んだ人</div>
          <div className="player-toggle-grid">
            {allPlayers.map((player) => (
              <button
                key={player}
                type="button"
                className={pitHagTarget === player ? "player-toggle selected evil-selected" : "player-toggle"}
                onClick={() => setPitHagTarget(pitHagTarget === player ? null : player)}
              >
                {person(g, player)}{g.playerStatus[player]?.alive === false ? " †" : ""}
              </button>
            ))}
          </div>
          <div className="form-section">
            <label>新しい役職</label>
            <select value={pitHagNewRole ?? ""} onChange={(e) => setPitHagNewRole(e.target.value ? (e.target.value as RoleId) : null)}>
              <option value="">選択してください</option>
              {([
                ["townsfolk", "町人"],
                ["outsider", "外来者"],
                ["minion", "ミニオン"],
                ["demon", "デーモン"],
              ] as const).map(([type, label]) => (
                <optgroup key={type} label={label}>
                  {scriptRoles.filter((role) => role.type === type).map((role) => (
                    <option key={role.id} value={role.id}>{role.symbol} {role.name}</option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>
          {pitHagNewRole && ROLES[pitHagNewRole].type === "demon" && (
            <p className="panel-note warning-note">
              デーモンを新しく作れた場合、この夜の死亡はPit-Hag由来の任意死亡として扱います。通常のデーモン襲撃数では絞り込みません。
            </p>
          )}
          <div className="form-section">
            <label>メモ（任意）</label>
            <textarea value={pitHagNote} maxLength={500} onChange={(e) => setPitHagNote(e.target.value)} placeholder="例：3Lを渦へ / デーモン変更を狙う" />
          </div>
          <button
            className="menu-option confirm-claim-button evil-confirm"
            disabled={!pitHagTarget || !pitHagNewRole || !pitHagNightOptions.includes(pitHagNight)}
            onClick={savePitHag}
          >
            変身を記録
          </button>

          {actions.some((a) => a.roleId === "pit_hag") && (
            <div className="claim-history">
              <div className="claim-history-title">変身履歴</div>
              {actions
                .filter((a): a is Extract<MinionActionEvent, { roleId: "pit_hag" }> => a.roleId === "pit_hag")
                .sort((a, b) => phaseNumber(b.when) - phaseNumber(a.when) || b.id - a.id)
                .map((a) => (
                  <div className="demon-action-row" key={a.id}>
                    <div><strong>{a.when}</strong> {person(g, a.target)} → {ROLES[a.newRole].symbol} {ROLES[a.newRole].name}</div>
                    {ROLES[a.newRole].type === "demon" && <span>デーモン作成なら今夜の死亡は任意</span>}
                    {a.note && <span>{a.note}</span>}
                  </div>
                ))}
              <button type="button" className="menu-option" onClick={undoLatestPitHag}>取り消し</button>
            </div>
          )}
        </section>
      )}

      {selfRoleId === "spy" && (
        <>
          <section className="evil-section spy-bluff-advisor">
            <h3>自動ブラフ提案 — 候補盤面最大化</h3>
            <p className="panel-note">
              自分が密だという秘密、悪チーム情報、グリモア、毒対象などを相手視点から外して候補盤面を作り直します。
              その上で「自分が本当にその善役職」「自分が酔っ払いでそう思っている」「自分が悪でその役職をブラフしている」のどれかで残れる盤面数を比較します。
              ここでの世界数は探索した候補の比較値で、完全列挙ではありません。
            </p>

            {spyBluffAdvisor.status === "running" && (
              <div className="spy-advisor-status">
                <strong>ブラフ候補を自動計算中…</strong>
                <span>検討 {spyBluffAdvisor.progress.checked} / 候補 {spyBluffAdvisor.progress.unique}</span>
              </div>
            )}

            {spyBluffAdvisor.status === "error" && (
              <div className="solver-error">
                ブラフ計算に失敗しました: {spyBluffAdvisor.error}
              </div>
            )}

            {spyBluffAdvisor.result && (
              <>
                <div className="spy-advisor-summary">
                  <span>相手視点の元候補 <strong>{spyBluffAdvisor.result.baseUnique}</strong></span>
                  <span>有効候補 <strong>{spyBluffAdvisor.result.baseEffectiveWorlds.toFixed(1)}</strong></span>
                  <span>Spy表示入力 <strong>{Math.round(spyBluffAdvisor.result.spyDisplayCoverage * 100)}%</strong></span>
                </div>
                <p className="panel-note">
                  「推奨」は、既知の実在役職・相手の既存主張・味方のブラフ予定との衝突を避けた中で、最も多くの候補盤面を残す役職です。
                  「世界数1位」は衝突も無視した純粋な盤面数トップです。
                </p>

                <div className="spy-bluff-list">
                  {spyBluffDisplay.map((candidate, index) => {
                    const role = ROLES[candidate.roleId];
                    const recommended = spyBluffAdvisor.result?.recommendedRoleId === candidate.roleId;
                    const rawWinner = spyBluffAdvisor.result?.rawWorldWinnerRoleId === candidate.roleId;
                    const currentPlan = state.bluffPlans.self === candidate.roleId;
                    return (
                      <div
                        key={candidate.roleId}
                        className={`spy-bluff-card${recommended ? " spy-bluff-recommended" : ""}`}
                      >
                        <div className="spy-bluff-card-head">
                          <span className="spy-bluff-rank">#{index + 1}</span>
                          <strong>{role.symbol} {role.name}</strong>
                          {recommended && <span className="spy-bluff-chip recommend">推奨</span>}
                          {rawWinner && <span className="spy-bluff-chip worlds">世界数1位</span>}
                          {currentPlan && <span className="spy-bluff-chip current">採用中</span>}
                        </div>

                        <div className="spy-bluff-metrics">
                          <span>成立配役 <strong>{candidate.supportedAssignments}</strong></span>
                          <span>有効世界 <strong>{candidate.effectiveWorlds.toFixed(1)}</strong></span>
                          <span>善側の顔で成立 <strong>{Math.round(candidate.goodFacadeWeight * 100)}%</strong></span>
                        </div>

                        <div className="spy-bluff-flags">
                          {candidate.sharedStorytellerBluff && <span className="spy-bluff-chip safe">共有ST安全</span>}
                          {candidate.spyShownAbsent && <span className="spy-bluff-chip safe">Spy表示不在</span>}
                          {candidate.spyShownInPlayAt && (
                            <span className="spy-bluff-chip danger">
                              Spy表示で実在: {person(g, candidate.spyShownInPlayAt)}
                            </span>
                          )}
                          {candidate.opponentClaimers.length > 0 && (
                            <span className="spy-bluff-chip danger">
                              相手主張: {candidate.opponentClaimers.map((player) => person(g, player)).join(" / ")}
                            </span>
                          )}
                          {candidate.allyUsers.length > 0 && (
                            <span className="spy-bluff-chip warning">
                              味方使用: {candidate.allyUsers.map((player) => person(g, player)).join(" / ")}
                            </span>
                          )}
                          {!candidate.spyShownInPlayAt && !candidate.spyShownAbsent && !candidate.sharedStorytellerBluff && (
                            <span className="spy-bluff-chip neutral">実在未確認</span>
                          )}
                        </div>

                        <button
                          type="button"
                          className="mini-action-button"
                          disabled={currentPlan}
                          onClick={() => setBluffPlan("self", candidate.roleId)}
                        >
                          {currentPlan ? "このブラフを採用中" : "このブラフを採用"}
                        </button>
                      </div>
                    );
                  })}
                </div>

                {spyBluffAdvisor.result.baseUnique < 40 && (
                  <p className="panel-note warning-note">
                    相手視点の候補が少ないため順位が不安定です。入力不足か強い公開情報がある場合があります。
                  </p>
                )}

                <div className="button-row compact-row">
                  <button type="button" className="secondary-button" onClick={() => spyBluffAdvisor.rerun(false)}>再計算</button>
                  <button type="button" className="secondary-button" onClick={() => spyBluffAdvisor.rerun(true)}>深く再計算</button>
                </div>
              </>
            )}
          </section>

          <section className="evil-section">
            <h3>N1 グリモア — 初期役職</h3>
            <p className="panel-note">
              入力した席は、密が健康な候補盤面ではその表示どおりに照合します。密自身が毒ならグリモアが誤情報の可能性も残します。全{g.playerCount}人を入力すると、入っていない善役職を「Spy表示安全」としてブラフ表に表示できます。
              {` ${Object.keys(spyEnteredRoles).length}/${g.playerCount}`}
            </p>
            <div className="spy-grimoire-grid">
              {allPlayers.map((player) => {
                const fixedSelf = player === "self";
                const value = fixedSelf ? "spy" : state.spyInitialRoles[player] ?? "";
                return (
                  <label className="spy-role-row" key={player}>
                    <span>{person(g, player)}</span>
                    <select
                      value={value}
                      disabled={fixedSelf}
                      onChange={(e) => setSpyInitialRole(player, e.target.value ? (e.target.value as RoleId) : null)}
                    >
                      <option value="">未入力</option>
                      {scriptRoles.map((role) => {
                        const usedElsewhere = Object.entries(state.spyInitialRoles).some(([p, r]) => p !== player && r === role.id) || (player !== "self" && role.id === "spy");
                        return <option key={role.id} value={role.id} disabled={usedElsewhere}>{role.symbol} {role.name}{usedElsewhere ? " — 使用済み" : ""}</option>;
                      })}
                    </select>
                  </label>
                );
              })}
            </div>
            <div className="form-section">
              <label>占い師の赤い印</label>
              <select value={state.spyRedHerring ?? ""} onChange={(e) => onChange({ ...state, spyRedHerring: e.target.value || null })}>
                <option value="">未入力</option>
                {others.filter((p) => {
                  const role = state.spyInitialRoles[p];
                  return !role || (ROLES[role].type !== "minion" && ROLES[role].type !== "demon");
                }).map((player) => <option key={player} value={player}>{person(g, player)}</option>)}
              </select>
            </div>
          </section>

          <section className="evil-section">
            <h3>毎夜のグリモア</h3>
            <p className="panel-note">その夜に見えた毒対象だけ、分かる場合に記録します。空欄は「未記録」で、毒なしを意味しません。</p>
            <div className="form-section">
              <label>いつ</label>
              <select value={spyNight} onChange={(e) => setSpyNight(e.target.value)}>
                {minionAbilityNightOptions.map((phase) => <option key={phase} value={phase}>{phase}</option>)}
              </select>
            </div>
            <div className="form-section">
              <label>毒対象</label>
              <select value={spyPoisonTarget ?? ""} onChange={(e) => setSpyPoisonTarget(e.target.value || null)}>
                <option value="">未記録</option>
                {allPlayers.map((player) => <option key={player} value={player}>{person(g, player)}</option>)}
              </select>
            </div>
            <div className="form-section">
              <label>メモ（任意）</label>
              <textarea value={spyNote} maxLength={700} onChange={(e) => setSpyNote(e.target.value)} placeholder="例：洗の対象、死亡原因、デーモンに伝える優先標的" />
            </div>
            <button className="menu-option confirm-claim-button evil-confirm" onClick={saveSpyNight}>グリモア記録を保存</button>

            {actions.filter((a) => a.roleId === "spy").length > 0 && (
              <div className="claim-history">
                <div className="claim-history-title">グリモア履歴</div>
                {actions.filter((a): a is Extract<MinionActionEvent, { roleId: "spy" }> => a.roleId === "spy")
                  .sort((a, b) => phaseNumber(b.when) - phaseNumber(a.when))
                  .map((a) => (
                    <div className="demon-action-row" key={a.id}>
                      <div><strong>{a.when}</strong>{a.poisonTarget ? ` / 毒: ${person(g, a.poisonTarget)}` : " / 毒未記録"}</div>
                      {a.note && <span>{a.note}</span>}
                      <button type="button" className="mini-danger-button" onClick={() => {
                        if (window.confirm(`${a.when}のグリモア記録を削除しますか？`)) onChangeActions(actions.filter((x) => x.id !== a.id));
                      }}>削除</button>
                    </div>
                  ))}
              </div>
            )}
          </section>
        </>
      )}

      {selfRoleId === "scarlet_woman" && (
        <section className="evil-section">
          <h3>緋色の女 — 継承状態</h3>
          <div className="status-detail">
            現在の生存人数: {allPlayers.filter((p) => g.playerStatus[p]?.alive !== false).length}人
          </div>
          <p className="panel-note">
            デーモン死亡時に能力が有効で、死亡直前に5人以上生存していればインプを継承します。候補盤面ではこの継承を通常の役職変化として追跡します。
          </p>
          <p className="metric-line">
            現在の探索で自分がデーモン: {currentDemonShare === undefined ? "—" : `${Math.round(currentDemonShare * 100)}%`}
          </p>
        </section>
      )}

      {selfRoleId === "baron" && (
        <section className="evil-section">
          <h3>男爵 — 配役効果</h3>
          <div className="baron-count-grid">
            <span>通常 Townsfolk<strong>{base.townsfolk}</strong></span>
            <span>男爵 Townsfolk<strong>{adjusted.townsfolk}</strong></span>
            <span>通常 Outsider<strong>{base.outsider}</strong></span>
            <span>男爵 Outsider<strong>{adjusted.outsider}</strong></span>
          </div>
          <p className="panel-note">自分が男爵なので候補盤面は最初から「Townsfolk -2 / Outsider +2」で固定されます。</p>
          <div className="claim-option-title">現在のOutsider主張</div>
          <p>{outsiderClaimers.length ? outsiderClaimers.map((p) => `${person(g, p)} (${roleLabel(latestExactClaim(g, p))})`).join(" / ") : "未記録"}</p>
        </section>
      )}

      <section className="evil-section">
        <h3>デーモン継承</h3>
        <p className="panel-note">
          スターパスや緋色の女で実際に自分がインプになった場合だけ記録します。これは自分が直接知っている情報なので候補盤面を固定します。
        </p>
        <div className="form-section">
          <label>インプになった時点</label>
          <select
            value={state.becameDemonAt ?? ""}
            onChange={(e) => onChange({ ...state, becameDemonAt: e.target.value || null })}
          >
            <option value="">まだ / 未記録</option>
            {phaseOptions.map((phase) => <option key={phase} value={phase}>{phase}</option>)}
          </select>
        </div>

        {state.becameDemonAt && (
          <div className="succession-attack-box">
            <div className="claim-option-title">継承後のインプ襲撃</div>
            <div className="form-section">
              <label>いつ</label>
              <select value={demonAttackNight} onChange={(e) => setDemonAttackNight(e.target.value)}>
                {attackNightOptions.filter((phase) => phaseNumber(phase) > phaseNumber(state.becameDemonAt!)).map((phase) => <option key={phase} value={phase}>{phase}</option>)}
              </select>
            </div>
            <div className="player-toggle-grid">
              {allPlayers.map((player) => (
                <button
                  key={player}
                  type="button"
                  className={demonAttackTarget === player ? "player-toggle selected evil-selected" : "player-toggle"}
                  onClick={() => setDemonAttackTarget(demonAttackTarget === player ? null : player)}
                >
                  {person(g, player)}{g.playerStatus[player]?.alive === false ? " †" : ""}
                </button>
              ))}
            </div>
            <div className="form-section">
              <label>作戦メモ（任意）</label>
              <textarea value={demonAttackNote} maxLength={500} onChange={(e) => setDemonAttackNote(e.target.value)} />
            </div>
            <button className="menu-option confirm-claim-button evil-confirm" disabled={!demonAttackTarget} onClick={saveDemonAttack}>襲撃を記録</button>
          </div>
        )}
      </section>

      <button className="menu-option" onClick={onBack}>戻る</button>
    </>
  );
}
