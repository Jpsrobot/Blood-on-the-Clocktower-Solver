import { useState } from 'react';
import type { GameSnapshot, AbilityClaimEvent, StructuredInfo } from '../types';
import { ROLES, type RoleId } from '../roles';
import { getSnapshotScriptRoleIds } from '../scripts';
import { exactClaim, seats } from '../engine/game';
import { eventId } from '../storage';
import { L, person } from './text';

const STRUCTURED_INFO_ROLES: RoleId[] = [
  'washerwoman',
  'librarian',
  'investigator',
  'chef',
  'empath',
  'fortune_teller',
  'undertaker',
  'ravenkeeper',
];

export function ReportedInfoForm({
  g,
  speaker,
  onSave,
  onUndo,
  onBack,
}: {
  g: GameSnapshot;
  speaker: string;
  onSave: (event: AbilityClaimEvent) => void;
  onUndo?: () => void;
  onBack: () => void;
}) {
  const scriptRoleIds = getSnapshotScriptRoleIds(g);
  const scriptRoles = scriptRoleIds.map((id) => ROLES[id]).filter(Boolean);
  const players = seats(g.playerCount);

  const initial = exactClaim(g, speaker);
  const [source, setSource] = useState(speaker);
  const [role, setRole] = useState<RoleId | null>(
    initial && scriptRoleIds.includes(initial) ? initial : null,
  );
  const [firstNumber, setFirstNumber] = useState<number | null>(null);
  const [targets, setTargets] = useState<string[]>([]);
  const [seen, setSeen] = useState<RoleId | null>(null);
  const [yes, setYes] = useState<'yes' | 'no' | null>(null);
  const [zero, setZero] = useState(false);
  const [genericResult, setGenericResult] = useState('');
  const [when, setWhen] = useState(`D${g.night}`);
  const [reported, setReported] = useState(`D${g.night}`);
  const [visibility, setVisibility] = useState<'public' | 'private'>('public');
  const [recipients, setRecipients] = useState<string[]>([]);

  const structured = !!role && STRUCTURED_INFO_ROLES.includes(role);
  const pair = role === 'washerwoman' || role === 'librarian' || role === 'investigator' || role === 'fortune_teller';
  const number = role === 'chef' || role === 'empath';
  const reveal = role === 'undertaker' || role === 'ravenkeeper';
  const first = structured && role !== null && ROLES[role].tags.includes('FIRST_NIGHT_INFO');
  const minInfoNight = role === 'undertaker' || role === 'ravenkeeper' ? 2 : 1;
  const infoNightOptions = first
    ? ['N1']
    : Array.from({ length: g.night }, (_, i) => `N${i + 1}`).filter((p) => Number(p.slice(1)) >= minInfoNight);
  const phaseOptions = Array.from({ length: g.night }, (_, i) => [`N${i + 1}`, `D${i + 1}`]).flat();
  const effectiveWhen = structured ? (first ? 'N1' : when.startsWith('N') ? when : `N${g.night}`) : when;
  const validWhenOptions = structured ? infoNightOptions : phaseOptions;
  const showRoles = scriptRoles.filter((r) =>
    role === 'washerwoman'
      ? r.type === 'townsfolk'
      : role === 'librarian'
        ? r.type === 'outsider'
        : role === 'investigator'
          ? r.type === 'minion'
          : true,
  );
  const max = pair ? 2 : 1;

  const resetRoleSpecific = (nextRole: RoleId | null) => {
    setFirstNumber(null);
    setTargets([]);
    setSeen(null);
    setYes(null);
    setZero(false);
    setGenericResult('');
    if (!nextRole) {
      setWhen(`D${g.night}`);
      return;
    }
    if (STRUCTURED_INFO_ROLES.includes(nextRole)) {
      if (nextRole === 'undertaker' || nextRole === 'ravenkeeper') {
        setWhen(g.night >= 2 ? `N${g.night}` : 'N2');
      } else {
        setWhen(`N${g.night}`);
      }
    } else {
      setWhen(`D${g.night}`);
    }
  };

  const chooseSource = (nextSource: string) => {
    setSource(nextSource);
    const claimed = exactClaim(g, nextSource);
    const nextRole = claimed && scriptRoleIds.includes(claimed) ? claimed : null;
    setRole(nextRole);
    resetRoleSpecific(nextRole);
  };

  const chooseRole = (nextRole: RoleId | null) => {
    setRole(nextRole);
    resetRoleSpecific(nextRole);
  };

  const toggle = (p: string) => {
    if (!structured) {
      setTargets((xs) => (xs.includes(p) ? xs.filter((x) => x !== p) : [...xs, p]));
      return;
    }
    setTargets((xs) =>
      xs.includes(p) ? xs.filter((x) => x !== p) : xs.length >= max ? (max === 1 ? [p] : xs) : [...xs, p],
    );
  };

  let data: StructuredInfo | null = null;
  if (role === 'librarian' && zero) data = { kind: 'noOutsiders' };
  else if (number && firstNumber !== null) data = { kind: 'number', value: firstNumber };
  else if (role === 'fortune_teller' && targets.length === 2 && yes) {
    data = { kind: 'pairYesNo', players: [targets[0], targets[1]], result: yes };
  } else if (pair && role !== 'fortune_teller' && targets.length === 2 && seen) {
    data = { kind: 'pairRole', players: [targets[0], targets[1]], shownRole: seen };
  } else if (reveal && targets.length === 1 && seen) {
    data = { kind: 'roleReveal', player: targets[0], shownRole: seen };
  }

  const canSave = !!role && validWhenOptions.includes(effectiveWhen) && (!structured || !!data);

  return (
    <>
      <h2>{person(g, speaker)} — 情報を記録</h2>
      <p className="panel-note">
        今タップした人が話している内容として記録します。伝聞の場合は「元の人」に実際の能力・情報の本人を選んでください。
      </p>

      <div className="form-section">
        <label>元の人</label>
        <select value={source} onChange={(e) => chooseSource(e.target.value)}>
          {players.map((p) => (
            <option key={p} value={p}>{person(g, p)}</option>
          ))}
        </select>
      </div>

      <div className="form-section">
        <label>元の人の役職</label>
        <select value={role ?? ''} onChange={(e) => chooseRole((e.target.value as RoleId) || null)}>
          <option value="">{L.select}</option>
          {scriptRoles.map((r) => (
            <option key={r.id} value={r.id}>{r.symbol} {r.name}</option>
          ))}
        </select>
      </div>

      {role && structured && (
        <>
          <div className="form-section">
            <label>{L.infoWhen}</label>
            <select
              value={effectiveWhen}
              disabled={first || infoNightOptions.length === 0}
              onChange={(e) => setWhen(e.target.value)}
            >
              {infoNightOptions.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
            {infoNightOptions.length === 0 && (
              <p className="panel-note history-missing-detail">この役職の情報はN2以降に記録できます。</p>
            )}
          </div>

          {role === 'librarian' && (
            <label className="check-label">
              <input
                type="checkbox"
                checked={zero}
                onChange={(e) => {
                  setZero(e.target.checked);
                  setTargets([]);
                  setSeen(null);
                }}
              />
              {L.noOutsiders}
            </label>
          )}

          {number && (
            <div className="form-section">
              <label>{L.result}</label>
              <div className="player-toggle-grid">
                {Array.from({ length: role === 'empath' ? 3 : g.playerCount + 1 }, (_, i) => i).map((n) => (
                  <button
                    type="button"
                    key={n}
                    aria-pressed={firstNumber === n}
                    className={`player-toggle ${firstNumber === n ? 'selected' : ''}`}
                    onClick={() => setFirstNumber(n)}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
          )}

          {(pair || reveal) && !zero && (
            <>
              <div className="form-section">
                <label>{L.choosePlayers} ({max})</label>
                <div className="player-toggle-grid">
                  {players.map((p) => (
                    <button
                      type="button"
                      key={p}
                      aria-pressed={targets.includes(p)}
                      className={`player-toggle ${targets.includes(p) ? 'selected' : ''}`}
                      onClick={() => toggle(p)}
                    >
                      {person(g, p)}
                    </button>
                  ))}
                </div>
              </div>
              {role === 'fortune_teller' ? (
                <div className="visibility-switch">
                  {(['yes', 'no'] as const).map((x) => (
                    <button
                      key={x}
                      type="button"
                      className={`visibility-button ${yes === x ? 'visibility-selected' : ''}`}
                      onClick={() => setYes(x)}
                    >
                      {L[x]}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="form-section">
                  <label>{L.shownRole}</label>
                  <select value={seen ?? ''} onChange={(e) => setSeen((e.target.value as RoleId) || null)}>
                    <option value="">{L.select}</option>
                    {showRoles.map((r) => <option key={r.id} value={r.id}>{r.symbol} {r.name}</option>)}
                  </select>
                </div>
              )}
            </>
          )}
        </>
      )}

      {role && !structured && (
        <>
          <div className="form-section">
            <label>能力・情報の時点</label>
            <select value={effectiveWhen} onChange={(e) => setWhen(e.target.value)}>
              {phaseOptions.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <div className="claim-option-title">対象（分かる場合）</div>
          <div className="player-toggle-grid">
            {players.map((p) => (
              <button
                type="button"
                key={p}
                aria-pressed={targets.includes(p)}
                className={`player-toggle ${targets.includes(p) ? 'selected' : ''}`}
                onClick={() => toggle(p)}
              >
                {person(g, p)}
              </button>
            ))}
          </div>

          <div className="form-section">
            <label>情報 / 内容（任意）</label>
            <textarea
              value={genericResult}
              placeholder="例：3Lを守った、4Rを選んだ、能力は発動しなかった など"
              onChange={(e) => setGenericResult(e.target.value)}
            />
          </div>
          <p className="panel-note">自由記述は保存されますが、専用ロジックがない内容は候補盤面では自動解釈しません。</p>
        </>
      )}

      <div className="form-section">
        <label>{L.saidWhen}</label>
        <select value={reported} onChange={(e) => setReported(e.target.value)}>
          {phaseOptions.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      <div className="visibility-switch">
        {(['public', 'private'] as const).map((v) => (
          <button
            type="button"
            key={v}
            className={`visibility-button ${visibility === v ? 'visibility-selected' : ''}`}
            onClick={() => {
              setVisibility(v);
              if (v === 'public') setRecipients([]);
            }}
          >
            {L[v]}
          </button>
        ))}
      </div>

      {visibility === 'private' && (
        <div className="form-section">
          <label>{L.audience}</label>
          <div className="player-toggle-grid">
            {players.filter((p) => p !== speaker).map((p) => (
              <button
                type="button"
                key={p}
                aria-pressed={recipients.includes(p)}
                className={`player-toggle ${recipients.includes(p) ? 'selected' : ''}`}
                onClick={() => setRecipients((xs) => xs.includes(p) ? xs.filter((x) => x !== p) : [...xs, p])}
              >
                {person(g, p)}
              </button>
            ))}
          </div>
        </div>
      )}

      <button
        type="button"
        className="menu-option confirm-claim-button"
        disabled={!canSave}
        onClick={() => {
          if (!role || !canSave) return;
          onSave({
            id: eventId(),
            playerId: speaker,
            sourcePlayerId: source,
            roleId: role,
            when: effectiveWhen,
            reportedWhen: reported,
            structured: structured ? data ?? undefined : undefined,
            targets,
            result: structured ? null : genericResult.trim() || null,
            visibility,
            recipients: visibility === 'private' ? recipients : [],
          });
        }}
      >
        {L.confirm}
      </button>
      <button type="button" className="menu-option" disabled={!onUndo} onClick={() => onUndo?.()}>取り消し</button>
      <button type="button" className="menu-option" onClick={onBack}>{L.back}</button>
    </>
  );
}
