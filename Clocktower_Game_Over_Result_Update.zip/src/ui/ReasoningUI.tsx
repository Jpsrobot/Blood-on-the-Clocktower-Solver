import { useState, useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import type { GameSnapshot, ManualRead } from '../types';
import { ROLES, type RoleId } from '../roles';
import { getSnapshotScriptRoleIds } from '../scripts';
import type { SearchResult, EvidenceAnalysis, Reason, Warning, HistoryWorld } from '../engine/model';
import { observations, setupCounts, seats, compareEvents } from '../engine/game';
import { recommendations, nominationAdvice } from '../engine/advice';
import type { LogKey } from '../storage';
import { LOG_KEYS } from '../storage';
import { L, person, explain, worldReasons, DISPOSITION_LABELS } from './text';
function pct(n:number|undefined){return n===undefined?'\u2014':`${Math.round(n*100)}%`;}
const priority:Warning['color'][]=['red','orange','yellow','blue'];
const warningLabel={red:'\u60aa\u306e\u7591\u3044',orange:'\u4e0d\u6574\u5408',yellow:'\u898b\u7acb\u3066\u3092\u518d\u78ba\u8a8d',blue:'\u9152\u306e\u53ef\u80fd\u6027',green:'\u6bd2\u306e\u7591\u3044'};
export function WarningBadges({warnings,onOpen}:{warnings:Warning[];onOpen:()=>void}){
 const main=priority.map(c=>warnings.find(w=>w.color===c)).find(Boolean);
 const poison=warnings.filter(w=>w.color==='green').sort((a,b)=>(b.cycle??0)-(a.cycle??0))[0];
 return <>{main&&<button type="button" className={`warning-badge warning-${main.color}`} aria-label={warningLabel[main.color]} onClick={onOpen}><span>!</span></button>}{poison&&<button type="button" className="warning-badge warning-green" aria-label={`${warningLabel.green} N${poison.cycle}`} onClick={onOpen}><span>{poison.cycle}</span></button>}</>;
}
export function ReasonList({reasons,g}:{reasons:Reason[];g:GameSnapshot}){
 const unique=reasons.filter((r,i)=>reasons.findIndex(x=>x.code===r.code&&x.players.join()===r.players.join()&&x.phase===r.phase)===i);
 return unique.length?<ul className="reason-list">{unique.map((r,i)=><li key={`${r.code}-${i}`}><span className="reason-kind">{{mechanical:'\u516c\u958b\u4e8b\u8c61',conditional:'\u6761\u4ef6\u4ed8\u304d',heuristic:'\u50be\u5411',input:'\u5165\u529b\u78ba\u8a8d'}[r.strength]}</span>{explain(r,g)}{r.evidence.length>0&&<small>{'\u5bfe\u5fdc\u8a18\u9332'}: {r.evidence.map(id=>String(id).slice(-6)).join(', ')}</small>}</li>)}</ul>:<p className="panel-note">{L.noReasons}</p>;
}
export function Sheet({title,onClose,children}:{title:string;onClose:()=>void;children:ReactNode}){
 const ref=useRef<HTMLDivElement>(null);const closeRef=useRef(onClose);closeRef.current=onClose;
 useEffect(()=>{const prev=document.activeElement as HTMLElement|null;ref.current?.focus();const old=document.body.style.overflow;document.body.style.overflow='hidden';const key=(e:KeyboardEvent)=>{if(e.key==='Escape')closeRef.current();if(e.key==='Tab'){const items=ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]),input,select,textarea,[tabindex="0"]');if(!items?.length)return;const first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};document.addEventListener('keydown',key);return()=>{document.body.style.overflow=old;document.removeEventListener('keydown',key);prev?.focus();};},[]);
 return <div className="analysis-overlay" onClick={onClose}><div ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title} className="analysis-sheet" onClick={e=>e.stopPropagation()}><header className="sheet-header"><h2>{title}</h2><button type="button" onClick={onClose} aria-label={L.close}>{'\u00d7'}</button></header>{children}</div></div>;
}
export function PlayerSummary({g,p,r,e,onOpen}:{g:GameSnapshot;p:string;r:SearchResult|null;e:EvidenceAnalysis;onOpen:()=>void}){
 const s=r?.unique?r.players[p]:undefined,ev=e.players[p];
 return <button className="player-summary" onClick={onOpen}><span>{L.sampleLabel}</span><strong>{L.evil} {pct(s?.evil)} / {L.demon} {pct(s?.demon)} / {L.drunk} {pct(s?.drunk)}</strong><small>{L.goodPoints} {ev?.good.toFixed(1)??'0'} / {L.evilPoints} {ev?.evil.toFixed(1)??'0'} / {L.inconsistent} {ev?.inconsistency??0}</small><span>{person(g,p)} {'\u2014'} {L.reasons}</span></button>;
}
export function NominationCard({g,r,p,nominator='self',compact=false}:{g:GameSnapshot;r:SearchResult|null;p:string;nominator?:string;compact?:boolean}){
 const a=nominationAdvice(g,r,p,nominator);
 return <section className={`analysis-card verdict-${a.verdict}`}><h3>{person(g,p)} {'\u2014'} {L[a.verdict]}</h3>{r?.unique!==0&&r&&<p className="metric-line">{L.evil}: {pct(r.players[p]?.evil)} / {L.demon}: {pct(r.players[p]?.demon)} / {L.drunk}: {pct(r.players[p]?.drunk)}</p>}<details open={!compact}><summary>{L.reasons}</summary><ReasonList reasons={a.reasons} g={g}/>{a.risks.length>0&&<><h4>{L.risk}</h4><ReasonList reasons={a.risks} g={g}/></>}</details></section>;
}
export function AdvicePanel({g,r}:{g:GameSnapshot;r:SearchResult|null}){
 const a=recommendations(g,r);
 return <><p className="panel-note">{'\u4ee5\u4e0b\u306f\u6bd4\u8f03\u7528\u306e\u884c\u52d5\u5019\u88dc\u3067\u3059\u3002\u6700\u9069\u89e3\u3084\u52dd\u5229\u306e\u4fdd\u8a3c\u3067\u306f\u3042\u308a\u307e\u305b\u3093\u3002'}</p>{a.nominations.map(x=><NominationCard key={x.player} g={g} r={r} p={x.player}/>)}{a.talks.length>0&&<section className="analysis-card"><h3>{L.talk}</h3><ul className="reason-list">{a.talks.map(p=><li key={p}>{person(g,p)}: {'\u5177\u4f53\u7684\u306a\u5f79\u8077\u4e3b\u5f35\u304c\u672a\u8a18\u9332\u3067\u3059\u3002\u591c\u306e\u60c5\u5831\u306e\u6709\u7121\u3092\u805e\u304f\u3068\u6bd4\u8f03\u306e\u6750\u6599\u306b\u306a\u308a\u307e\u3059\u3002'}</li>)}</ul></section>}{a.targets.length>0&&<section className="analysis-card"><h3>{L.targets}</h3><p>{a.targets.map(p=>person(g,p)).join(' / ')}</p><p className="panel-note">{g.selfRole.shownRole==='monk'?'\u751f\u5b58\u4fa1\u5024\u306e\u9ad8\u3044\u4e3b\u5f35\u8005\u3092\u91cd\u8996\u3057\u305f\u5019\u88dc\u3067\u3059\u3002\u60aa\u306e\u653b\u6483\u5148\u306f\u4e0d\u660e\u3067\u3059\u3002':'\u4e0a\u4f4d\u306e\u4ee3\u8868\u5019\u88dc\u3092\u5206\u3051\u3084\u3059\u3044\u7d44\u5408\u305b\u3067\u3059\u3002\u7bed\u3084\u9152\u30fb\u6bd2\u306e\u5f71\u97ff\u3092\u542b\u3080\u6700\u9069\u5316\u3067\u306f\u3042\u308a\u307e\u305b\u3093\u3002'}</p></section>}</>;
}
function seatNumber(player:string){return Number.parseInt(player,10)||0;}
function WorldSeat({g,w,p}:{g:GameSnapshot;w:HistoryWorld;p:string}){
 const initial=w.initial[p],current=w.current[p],alive=w.alive.includes(p);
 return <div className={`world-seat${p==='self'?' world-seat-self':''}${alive?'':' world-seat-dead'}`}>
  <span className="world-seat-person">{person(g,p)}</span>
  <span className="world-seat-role"><strong>{ROLES[initial].symbol}{initial!==current?` → ${ROLES[current].symbol}`:''}</strong><small>{L[w.currentAlignment[p]]}</small></span>
 </div>;
}
function WorldBoard({g,w}:{g:GameSnapshot;w:HistoryWorld}){
 const order=seats(g.playerCount);
 const left=order.filter(p=>p.endsWith('L')).sort((a,b)=>seatNumber(b)-seatNumber(a));
 const right=order.filter(p=>p.endsWith('R')).sort((a,b)=>seatNumber(b)-seatNumber(a));
 return <div className="world-board">
  <div className="world-board-top">上</div>
  <div className="world-board-columns">
   <div className="world-board-column">{left.map(p=><WorldSeat key={p} g={g} w={w} p={p}/>)}</div>
   <div className="world-board-column">{right.map(p=><WorldSeat key={p} g={g} w={w} p={p}/>)}</div>
  </div>
  <div className="world-board-self"><WorldSeat g={g} w={w} p="self"/></div>
  <p className="world-clockwise-hint">時計回り: 自分 → 左側を上へ → 右側を下へ → 自分</p>
 </div>;
}
type Query={result:SearchResult|null;status:string;progress:{checked:number;unique:number};error:string;meta:boolean;rerun:(deep?:boolean)=>void;setMeta:(v:boolean)=>void};
export type AnalysisTab='overview'|'info'|'worlds'|'history'|'advice';
type Props={g:GameSnapshot;e:EvidenceAnalysis;query:Query;player:string|null;initialTab?:AnalysisTab;onClose:()=>void;onCompleteness:(n:number,kind:'night'|'day',value:boolean)=>void;onDelete:(key:LogKey,id:number)=>void};
export function AnalysisPanel({g,e,query:q,player,initialTab='overview',onClose,onCompleteness,onDelete}:Props){
 const [tab,setTab]=useState<AnalysisTab>(initialTab);
 useEffect(()=>setTab(initialTab),[initialTab]);
 const [n,setN]=useState(g.night);const r=q.result,p=player;
 const obs=observations(g).filter(o=>!p||o.source===p);const ev=p?e.players[p]:null;
 const titles={overview:L.analysis,info:L.info,worlds:L.worlds,history:L.history,advice:L.advice};
 const [detail,setDetail]=useState<number|null>(null);
 const events=LOG_KEYS.flatMap(key=>(g[key]??[]).map(ev=>({key,event:ev}))).sort((a,b)=>compareEvents(b.event,a.event));
 return <Sheet title={p?`${person(g,p)} / ${L.analysis}`:L.analysis} onClose={onClose}>
  <p className="sample-caution">{L.sampleCaution}</p>
  <div className="analysis-tabs">{(Object.keys(titles)as(keyof typeof titles)[]).map(t=><button key={t} className={tab===t?'selected':''} onClick={()=>setTab(t)}>{titles[t]}</button>)}</div>
  {q.status==='running'&&<p role="status" className="panel-note">{L.searching} {q.progress.checked} {'\u691c\u8a0e'} / {q.progress.unique} {'\u5019\u88dc'}</p>}
  {q.error&&<p role="alert" className="error-banner">{'\u63a2\u7d22\u30a8\u30e9\u30fc'}: {q.error}</p>}
  {r&&r.unique===0&&<p className="error-banner">{L.noWorlds}</p>}
  {r&&r.unique>0&&(r.unique<80||r.effectiveWorlds<20)&&<p className="panel-note">{L.weakSample}</p>}
  {tab==='overview'&&<>
   {r&&<p className="metric-line">{r.unique} {'\u914d\u5f79\u5019\u88dc'} / {r.checked} {'\u691c\u8a0e'} / {(r.elapsedMs/1000).toFixed(1)}s</p>}
   <div className="compact-row"><button className="menu-option" onClick={()=>q.rerun(false)}>{L.explore}</button><button className="menu-option" onClick={()=>q.rerun(true)}>{L.deep}</button></div>
   <label className="check-label"><input type="checkbox" checked={q.meta} onChange={a=>q.setMeta(a.target.checked)}/>{L.meta}</label>
   {p&&ev?<>
    <div className="metrics-grid"><span>{L.evil}<strong>{pct(r?.unique?r.players[p]?.evil:undefined)}</strong></span><span>{L.demon}<strong>{pct(r?.unique?r.players[p]?.demon:undefined)}</strong></span><span>{L.drunk}<strong>{pct(r?.unique?r.players[p]?.drunk:undefined)}</strong></span></div>
    <p className="metric-line">{L.goodPoints}: {ev.good.toFixed(1)} / {L.evilPoints}: {ev.evil.toFixed(1)}</p><p className="panel-note">{L.countsHelp}</p>
    {ev.warnings.map((w,i)=><section className={`analysis-card border-${w.color}`} key={i}><h3>{warningLabel[w.color]} {w.cycle?`N${w.cycle}`:''}</h3><ReasonList reasons={w.reasons} g={g}/></section>)}
    <h3>{L.reasons}</h3><ReasonList reasons={ev.reasons} g={g}/>
    {r?.examples[p]&&(['good','evil'] as const).map(alignment=>{const w=r.examples[p][alignment];return <details className="analysis-card" key={alignment}><summary>{L[alignment]}{'\u3068\u3057\u3066\u306e\u8aac\u660e\u4f8b'}</summary>{w?<><p>{person(g,p)}: {ROLES[w.current[p]].symbol} / {L[w.currentAlignment[p]]}</p><ul className="reason-list">{worldReasons(w,g).map((text,i)=><li key={i}>{text}</li>)}</ul></>:<p className="panel-note">{'\u3053\u306e\u63a2\u7d22\u3067\u306f\u4f8b\u3092\u898b\u3064\u3051\u3089\u308c\u307e\u305b\u3093\u3067\u3057\u305f\u3002\u5168\u5019\u88dc\u306b\u3064\u3044\u3066\u306e\u4e0d\u53ef\u80fd\u8a3c\u660e\u3067\u306f\u3042\u308a\u307e\u305b\u3093\u3002'}</p>}</details>;})}
    {r&&r.unique>0&&<section className="analysis-card"><h3>{L.role} / {L.sampleLabel}</h3><div className="role-shares">{Object.entries(r.players[p]?.roles??{}).sort((a,b)=>(b[1]??0)-(a[1]??0)).slice(0,8).map(([role,x])=><span key={role}>{ROLES[role as RoleId].symbol} {pct(x)}</span>)}</div></section>}
   </>:<>
    <section className="analysis-card"><h3>{'\u914d\u5f79'}</h3><p>{Object.entries(setupCounts(g.playerCount)).map(([_t,num],i)=>`${L.nominalTypes[i]} ${num}`).join(' / ')}</p><p className="panel-note">{'\u7235\u304c\u3044\u308b\u914d\u5f79\u306f\u753a\u4eba\u3092\u4e8c\u4eba\u6e1b\u3089\u3057\u3001\u30a2\u30a6\u30c8\u30b5\u30a4\u30c0\u30fc\u3092\u4e8c\u4eba\u5897\u3084\u3057\u307e\u3059\u3002'}</p></section>
    {(['poisoner','spy','scarlet_woman','baron','drunk','mastermind']as RoleId[]).filter(role=>getSnapshotScriptRoleIds(g).includes(role)).map(role=><section className="analysis-card" key={role}><h3>{ROLES[role].symbol} {ROLES[role].name} <span className="metric-inline">{pct(r?.unique?r.presence[role]:undefined)}</span></h3><p className="panel-note">{'\u50be\u5411\u70b9'}: {(e.global[role]?.points??0).toFixed(1)}</p><ReasonList reasons={e.global[role]?.reasons??[]} g={g}/></section>)}
   </>}
   {e.issues.length>0&&<section className="analysis-card border-orange"><h3>{'\u5165\u529b\u78ba\u8a8d'}</h3><ReasonList reasons={e.issues} g={g}/></section>}
   <section className="analysis-card"><h3>{'\u65e5\u3068\u591c\u306e\u8a18\u9332\u78ba\u8a8d'}</h3><select aria-label={'\u56de'} value={n} onChange={a=>setN(Number(a.target.value))}>{Array.from({length:g.night},(_,i)=>i+1).map(k=><option key={k} value={k}>N{k} / D{k}</option>)}</select><label className="check-label"><input type="checkbox" checked={g.completedNights.includes(n)} onChange={a=>onCompleteness(n,'night',a.target.checked)}/>{L.completeNight}</label><label className="check-label"><input type="checkbox" checked={g.noExecutionDays.includes(n)} onChange={a=>onCompleteness(n,'day',a.target.checked)}/>{L.noExecution}</label><p className="panel-note">{L.completenessHelp}</p></section>
  </>}
  {tab==='info'&&<>{obs.length===0&&<p>{L.none}</p>}{obs.map(o=>{const s=r?.info[o.id];return <section className="analysis-card" key={o.id}><h3>{o.when} / {person(g,o.source)} / {ROLES[o.role].symbol}</h3><p>{o.direct?L.directObserved:L.reported}</p><p>{formatInfo(o.data,g)}</p>{s&&<div className="role-shares">{Object.entries(s).filter(([,x])=>x>.005).map(([key,x])=><span key={key}>{DISPOSITION_LABELS[key as keyof typeof DISPOSITION_LABELS]} {pct(x)}</span>)}</div>}<button className="menu-option" onClick={()=>setDetail(detail===o.id?null:o.id)}>{L.reasons}</button>{detail===o.id&&<><p className="panel-note">{'\u91cd\u8907\u3057\u305f\u4f1d\u805e\u306f\u72ec\u7acb\u3057\u305f\u78ba\u8a8d\u3068\u3057\u3066\u52a0\u7b97\u3057\u307e\u305b\u3093\u3002\u6bd2\u3084\u9152\u306e\u7d50\u679c\u3082\u3001\u5076\u7136\u6b63\u3057\u3044\u3053\u3068\u304c\u3042\u308a\u307e\u3059\u3002'}</p><ReasonList reasons={e.players[o.source]?.reasons.filter(x=>x.evidence.some(id=>o.aliases.includes(id)))??[]} g={g}/></>}</section>;})}</>}
  {tab==='worlds'&&<><div className="compact-row"><button className="menu-option" onClick={()=>q.rerun(false)}>{L.explore}</button><button className="menu-option" onClick={()=>q.rerun(true)}>{L.deep}</button></div>{r&&<p className="metric-line">{r.unique} {'候補'} / {r.checked} {'検討'} / {'有効候補'} {r.effectiveWorlds.toFixed(1)}</p>}<p className="panel-note">{'\u30b9\u30b3\u30a2\u4e0a\u4f4d\u306e\u4ee3\u8868\u4eee\u8aac\u3067\u3059\u3002\u63a2\u7d22\u6f0f\u308c\u306e\u5019\u88dc\u3082\u3042\u308a\u5f97\u307e\u3059\u3002'}</p>{r?.worlds.slice(0,12).map((w,i)=><details className="analysis-card" key={i} open={i===0}><summary>{'\u4eee\u8aac'} {i+1} / {L.demon}: {w.alive.filter(x=>ROLES[w.current[x]].type==='demon').map(x=>person(g,x)).join(' / ')||L.none}</summary><WorldBoard g={g} w={w}/><h4>{L.requires}</h4><ul className="reason-list">{worldReasons(w,g).map((s,j)=><li key={j}>{s}</li>)}</ul></details>)}</>}
  {tab==='advice'&&<AdvicePanel g={g} r={r}/>}
  {tab==='history'&&<>{events.length===0&&<p>{L.none}</p>}<p className="panel-note">{'\u8aa4\u5165\u529b\u306f\u524a\u9664\u3057\u3001\u6b63\u3057\u3044\u5185\u5bb9\u3092\u518d\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u9023\u52d5\u3059\u308b\u767a\u52d5\u3068\u6b7b\u4ea1\u306f\u4e00\u7dd2\u306b\u524a\u9664\u3055\u308c\u307e\u3059\u3002'}</p>{events.slice(0,250).map(({key,event})=><section key={`${key}-${event.id}`} className="analysis-card"><h3>{event.when} / {logLabel[key]}</h3><p>{formatEvent(key,event,g)}</p><small>#{String(event.id).slice(-6)}</small><button className="menu-option danger-button" onClick={()=>{if(window.confirm(L.deleteConfirm))onDelete(key,event.id);}}>{L.remove}</button></section>)}</>}
 </Sheet>;
}
const logLabel:Record<LogKey,string>={roleClaimLog:'役職主張',abilityClaimLog:'情報記録',deathLog:'死亡',revivalLog:'復活',nominationLog:'指名',abilityTriggerLog:'発動',talkLog:'会話',selfInfoLog:'自分の情報',selfActionLog:'自分の行動',demonActionLog:'デーモン襲撃',minionActionLog:'ミニオン行動'};
function formatInfo(d:import('../types').StructuredInfo,g:GameSnapshot):string{
 switch(d.kind){case'pairRole':return `${d.players.map(x=>person(g,x)).join(' / ')} \u2192 ${ROLES[d.shownRole].symbol}`;case'noOutsiders':return L.noOutsiders;case'number':return String(d.value);case'pairYesNo':return `${d.players.map(x=>person(g,x)).join(' / ')} \u2192 ${d.result==='yes'?L.yes:L.no}`;case'roleReveal':return `${person(g,d.player)} \u2192 ${ROLES[d.shownRole].symbol}`;case'action':return person(g,d.target);}
}
function formatEvent(key:LogKey,event:NonNullable<GameSnapshot[LogKey]>[number],g:GameSnapshot){
 if(key==='minionActionLog'){
  const e=event as import('../types').MinionActionEvent;
  if(e.roleId==='poisoner')return `${L.self} ${ROLES.poisoner.symbol} → ${person(g,e.target)}${e.note?` / ${e.note}`:''}`;
  if(e.roleId==='spy')return `${L.self} ${ROLES.spy.symbol}${e.poisonTarget?` / 毒: ${person(g,e.poisonTarget)}`:' / 毒未記録'}${e.note?` / ${e.note}`:''}`;
  return `${L.self} ${ROLES.pit_hag.symbol}: ${person(g,e.target)} → ${ROLES[e.newRole].symbol} ${ROLES[e.newRole].name}${e.note?` / ${e.note}`:''}`;
 }
 if('subject'in event){const s=event.subject;const subject=s.kind==='role'?ROLES[s.roleId].symbol:s.kind==='tag'?({FIRST_NIGHT_INFO:'\u521d\u591c\u60c5\u5831',CONTINUOUS_INFO:'\u7d99\u7d9a\u60c5\u5831',LACK_OF_INFO:'\u60c5\u5831\u306a\u3057',WANTS_DEMON_TARGET:'\u72d9\u308f\u308c\u305f\u3044',HIGH_SURVIVAL_VALUE:'\u751f\u5b58\u4fa1\u5024'}[s.tag]):s.kind==='type'?L.nominalTypes[['townsfolk','outsider','minion','demon'].indexOf(s.roleType)]:L[s.alignment];return `${person(g,event.playerId)}: ${subject}${event.claimType==='bluff'?' / \u30d6\u30e9\u30d5':''}`;}
 if('participants'in event)return event.participants.map(x=>person(g,x)).join(' \u2194 ')+(event.details?` / ${event.details}`:' / '+L.unknown);
 if('nominator'in event)return `${person(g,event.nominator)} \u2192 ${person(g,event.nominee)} / ${event.votingOccurred===false?'\u6295\u7968\u306a\u3057':event.voters.length+'\u7968'}`;
 if('rolePlayerId'in event)return `${person(g,event.rolePlayerId)} ${ROLES[event.roleId].symbol} \u2192 ${person(g,event.targetPlayerId)} / ${event.triggered?L.yes:L.no}`;
 if('reason'in event)return `${person(g,event.playerId)} / ${{execution:'\u51e6\u5211',night_death:'\u591c\u6b7b\u4ea1',ability:'\u80fd\u529b',storyteller:'\u30b9\u30c8\u30fc\u30ea\u30fc\u30c6\u30e9\u30fc',other:'\u305d\u306e\u4ed6'}[event.reason]}`;
 if(key==='revivalLog'&&'playerId'in event)return `${person(g,event.playerId)} / 復活`;
 if('structured'in event&&event.structured)return `${person(g,event.playerId)}: ${formatInfo(event.structured,g)}`;
 if('playerId'in event)return `${person(g,event.playerId)} ${'roleId'in event?ROLES[event.roleId].symbol:''} ${'result'in event?event.result??'':''}`;
 if('target'in event)return `${L.self} ${ROLES[event.roleId].symbol} \u2192 ${person(g,event.target)}`;
 if(key==='selfInfoLog')return `${ROLES[event.roleId].symbol} / ${'number'in event?event.number:'shownRole'in event&&event.shownRole?ROLES[event.shownRole].symbol:'result'in event?event.result:L.noOutsiders}`;
 return logLabel[key];
}
export function ManualReadForm({g,player,onSave,onClear,onBack}:{g:GameSnapshot;player:string;onSave:(r:ManualRead)=>void;onClear:()=>void;onBack:()=>void}){
 const old=g.manualReads[player];const[role,setRole]=useState<RoleId|null>(old?.roleId??null);const[align,setAlign]=useState<ManualRead['alignment']>(old?.alignment??'unknown');const[note,setNote]=useState(old?.note??'');
 return <><h2>{person(g,player)} / {L.read}</h2><p className="panel-note">{L.readHelp}</p><div className="form-section"><label>{L.role}</label><select value={role??''} onChange={e=>setRole(e.target.value as RoleId||null)}><option value="">{L.unknown}</option>{getSnapshotScriptRoleIds(g).map(id=>ROLES[id]).map(r=><option key={r.id} value={r.id}>{r.symbol} {r.name}</option>)}</select></div><div className="visibility-switch">{(['unknown','good','evil']as const).map(a=><button key={a} className={`visibility-button ${align===a?'visibility-selected':''}`} onClick={()=>setAlign(a)}>{L[a]}</button>)}</div><div className="form-section"><label>{L.note}</label><textarea value={note} maxLength={1000} onChange={e=>setNote(e.target.value)}/></div><button className="menu-option" onClick={()=>onSave({playerId:player,roleId:role,alignment:align,note,updatedAt:Date.now()})}>{L.confirm}</button>{old&&<button className="menu-option" onClick={onClear}>取り消し</button>}<button className="menu-option" onClick={onBack}>{L.back}</button></>;
}
