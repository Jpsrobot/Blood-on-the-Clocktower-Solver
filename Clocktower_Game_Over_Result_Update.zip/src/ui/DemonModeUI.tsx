import { useMemo, useState } from "react";
import { ROLES, type RoleId } from "../roles";
import { getSnapshotScriptRoleIds } from "../scripts";
import type { DemonActionEvent, DemonState, GameSnapshot, KnownMinion } from "../types";
import type { SearchResult } from "../engine/model";
import { exactClaim, seats, setupCounts } from "../engine/game";
import { eventId } from "../storage";
import { person } from "./text";

type Props = {
  g: GameSnapshot;
  state: DemonState;
  actions: DemonActionEvent[];
  result: SearchResult | null;
  onChange: (state: DemonState) => void;
  onChangeActions: (events: DemonActionEvent[]) => void;
  onBack: () => void;
};

type BluffStatus = "storyteller" | "opponent" | "ally" | "unclaimed";

function latestExactClaim(g: GameSnapshot, player: string): RoleId | null {
  return exactClaim(g, player);
}

function targetReasons(g: GameSnapshot, p: string, result: SearchResult | null): string[] {
  const roleId = latestExactClaim(g, p);
  const role = roleId ? ROLES[roleId] : null;
  const reasons: string[] = [];
  if (role?.tags.includes("HIGH_SURVIVAL_VALUE")) reasons.push("生存価値の高い主張");
  if (role?.tags.includes("CONTINUOUS_INFO")) reasons.push("継続情報役の主張");
  if (role?.tags.includes("WANTS_DEMON_TARGET")) reasons.push("攻撃を受けたい役職主張");
  const evil = result?.players[p]?.evil;
  if (evil !== undefined && evil < 0.2) reasons.push("候補盤面では善側に寄る");
  if (!role) reasons.push("役職主張未記録");
  return reasons;
}

function targetScore(g: GameSnapshot, p: string, result: SearchResult | null): number {
  const roleId = latestExactClaim(g, p);
  const role = roleId ? ROLES[roleId] : null;
  let score = 0;
  if (role?.tags.includes("HIGH_SURVIVAL_VALUE")) score += 4;
  if (role?.tags.includes("CONTINUOUS_INFO")) score += 2;
  if (role?.tags.includes("FIRST_NIGHT_INFO")) score -= 0.5;
  if (role?.tags.includes("WANTS_DEMON_TARGET")) score -= 5;
  if (roleId === "soldier" || roleId === "ravenkeeper") score -= 3;
  const evil = result?.players[p]?.evil;
  if (evil !== undefined) score += (0.5 - evil) * 3;
  if (!role) score -= 0.25;
  return score;
}

function publicNightResult(g: GameSnapshot, action: DemonActionEvent): string {
  const deaths = g.deathLog.filter((d) => d.when === action.when);
  const targetDeath = deaths.find((d) => d.playerId === action.target);
  if (targetDeath) return `対象死亡: ${person(g, action.target)}`;
  if (deaths.length > 0) return `別の死亡: ${deaths.map((d) => person(g, d.playerId)).join(" / ")}`;
  const n = Number(action.when.slice(1));
  if (g.completedNights.includes(n)) return "死亡なし";
  return "結果未確定";
}

export function DemonModePanel({ g, state, actions, result, onChange, onChangeActions, onBack }: Props) {
  const selfDemonId = g.selfRole.shownRole;
  if (!selfDemonId || ROLES[selfDemonId].type !== "demon") return <button className="menu-option" onClick={onBack}>戻る</button>;
  const selfDemon = ROLES[selfDemonId];
  const impMode = selfDemonId === "imp";
  const scriptRoles = getSnapshotScriptRoleIds(g).map(id => ROLES[id]);
  const GOOD_ROLES = scriptRoles.filter(role => role.type === "townsfolk" || role.type === "outsider");
  const MINION_ROLES = scriptRoles.filter(role => role.type === "minion");
  const [attackNight, setAttackNight] = useState(`N${Math.max(2, g.night)}`);
  const [attackTarget, setAttackTarget] = useState<string | null>(null);
  const [attackNote, setAttackNote] = useState("");
  const minionCount = setupCounts(g.playerCount).minion;
  const getsStartingInfo = g.playerCount >= 7;
  const allPlayers = seats(g.playerCount);
  const others = allPlayers.filter((p) => p !== "self");
  const known = new Set(state.knownMinions.map((m) => m.playerId));
  const livingOpponents = others.filter((p) => !known.has(p) && g.playerStatus[p]?.alive !== false);
  const nightOptions = Array.from({ length: Math.max(0, g.night - 1) }, (_, i) => `N${i + 2}`);

  const suggestions = useMemo(
    () =>
      livingOpponents
        .map((player) => ({
          player,
          score: targetScore(g, player, result),
          reasons: targetReasons(g, player, result),
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 3),
    [g, result, state.knownMinions]
  );

  function toggleKnownMinion(playerId: string) {
    const existing = state.knownMinions.find((m) => m.playerId === playerId);
    if (existing) {
      const bluffPlans = { ...state.bluffPlans };
      delete bluffPlans[playerId];
      onChange({
        ...state,
        knownMinions: state.knownMinions.filter((m) => m.playerId !== playerId),
        bluffPlans,
      });
      return;
    }
    if (state.knownMinions.length >= minionCount) return;
    const item: KnownMinion = {
      playerId,
      source: getsStartingInfo ? "demon_info" : "confirmed_later",
      roleId: null,
    };
    onChange({ ...state, knownMinions: [...state.knownMinions, item] });
  }


  function setKnownMinionRole(playerId: string, roleId: RoleId | null) {
    onChange({
      ...state,
      knownMinions: state.knownMinions.map((m) =>
        m.playerId === playerId ? { ...m, roleId } : m
      ),
    });
  }

  function toggleStorytellerBluff(roleId: RoleId) {
    if (!getsStartingInfo) return;
    const current = state.storytellerBluffs;
    if (current.includes(roleId)) {
      onChange({ ...state, storytellerBluffs: current.filter((r) => r !== roleId) });
      return;
    }
    if (current.length >= 3) return;
    onChange({ ...state, storytellerBluffs: [...current, roleId] });
  }

  function setBluffPlan(playerId: string, roleId: RoleId | null) {
    onChange({
      ...state,
      bluffPlans: { ...state.bluffPlans, [playerId]: roleId },
    });
  }

  function saveAttack() {
    if (!attackTarget || !nightOptions.includes(attackNight)) return;
    const old = actions.find((a) => a.when === attackNight);
    if (old && !window.confirm(`${attackNight}の襲撃対象は既に記録されています。置き換えますか？`)) return;
    const next: DemonActionEvent = {
      id: eventId(),
      roleId: "imp",
      when: attackNight,
      target: attackTarget,
      note: attackNote.trim() || null,
    };
    onChangeActions([...actions.filter((a) => a.when !== attackNight), next]);
    setAttackTarget(null);
    setAttackNote("");
  }

  function opponentClaimersFor(roleId: RoleId) {
    return others.filter((p) => !known.has(p) && latestExactClaim(g, p) === roleId);
  }

  const teamPlanUsers = new Map<RoleId, string[]>();
  for (const [player, role] of Object.entries(state.bluffPlans)) {
    if (!role) continue;
    const list = teamPlanUsers.get(role) ?? [];
    list.push(player);
    teamPlanUsers.set(role, list);
  }

  const bluffRows = GOOD_ROLES.map((role) => {
    const claimers = opponentClaimersFor(role.id);
    const allyUsers = teamPlanUsers.get(role.id) ?? [];
    let status: BluffStatus = "unclaimed";
    if (state.storytellerBluffs.includes(role.id)) status = "storyteller";
    else if (claimers.length) status = "opponent";
    else if (allyUsers.length) status = "ally";
    return { role, status, claimers, allyUsers };
  }).sort((a, b) => {
    const order: Record<BluffStatus, number> = { storyteller: 0, unclaimed: 1, ally: 2, opponent: 3 };
    return order[a.status] - order[b.status] || a.role.name.localeCompare(b.role.name, "ja");
  });

  const teamMembers = ["self", ...state.knownMinions.map((m) => m.playerId)];

  const attackHint = (() => {
    if (!attackTarget) return null;
    if (attackTarget === "self") {
      const livingKnown = state.knownMinions.filter((m) => g.playerStatus[m.playerId]?.alive !== false);
      const knownScarlet = livingKnown.find((m) => m.roleId === "scarlet_woman");
      if (knownScarlet) return `自分への襲撃 = スターパス。緋色の女が能力を使える状態で5人以上生存なら、${person(g, knownScarlet.playerId)} が先にインプになります。`;
      return livingKnown.length
        ? `自分への襲撃 = スターパス。記録上の生存ミニオン候補: ${livingKnown.map((m) => person(g, m.playerId)).join(" / ")}`
        : "自分への襲撃 = スターパス。生存ミニオンがいない場合は継承できません。";
    }
    if (g.playerStatus[attackTarget]?.alive === false) return "死亡済みプレイヤーへの襲撃です。新しい死亡は発生せず、キルを沈める記録として扱います。";
    if (known.has(attackTarget)) return "登録済みの味方ミニオンを襲撃します。作戦上必要か確認してください。";
    const claim = latestExactClaim(g, attackTarget);
    if (claim === "soldier") return "兵士主張への襲撃です。健康な本物なら死亡しません。";
    if (claim === "ravenkeeper") return "鴉飼い主張への襲撃です。本物なら死亡時に情報を得る可能性があります。";
    if (claim === "mayor") return "市長主張への襲撃です。本物なら別のプレイヤーが死亡する可能性があります。";
    return null;
  })();

  return (
    <>
      <h2>デーモンモード</h2>
      <div className="evil-mode-banner">
        <strong>{selfDemon.symbol} {selfDemon.name}</strong>
        <span>{impMode ? "悪チーム用の秘密情報・ブラフ・襲撃記録" : "悪チーム用の秘密情報・ブラフ計画"}</span>
      </div>

      <section className="evil-section">
        <h3>悪チーム</h3>
        {getsStartingInfo ? (
          <p className="panel-note">
            7人以上では、初夜にデーモンがミニオンのプレイヤーを知ります。役職そのものはここでは確定しません。
            {` ${state.knownMinions.length}/${minionCount}人登録`}
          </p>
        ) : (
          <p className="panel-note">
            5〜6人では開始時にデーモンとミニオンは互いを知りません。ここには後から確定した味方だけ登録します。
          </p>
        )}
        <div className="player-toggle-grid">
          {others.map((player) => (
            <button
              key={player}
              type="button"
              className={known.has(player) ? "player-toggle selected evil-selected" : "player-toggle"}
              onClick={() => toggleKnownMinion(player)}
            >
              {person(g, player)}
            </button>
          ))}
        </div>
        {state.knownMinions.length > 0 && (
          <div className="evil-team-list">
            {state.knownMinions.map((m) => {
              const claim = latestExactClaim(g, m.playerId);
              return (
                <div key={m.playerId} className="evil-team-row">
                  <strong>{person(g, m.playerId)}</strong>
                  <span>{claim ? `現在の主張: ${ROLES[claim].symbol} ${ROLES[claim].name}` : "現在の主張: 未記録"}</span>
                  <small>{m.source === "demon_info" ? "初夜のデーモン情報" : "後から味方と確認"}</small>
                  <label className="evil-team-role-label">
                    味方から実役職を確認した場合
                    <select
                      value={m.roleId ?? ""}
                      onChange={(e) => setKnownMinionRole(m.playerId, e.target.value ? (e.target.value as RoleId) : null)}
                    >
                      <option value="">未確認</option>
                      {MINION_ROLES.map((role) => {
                        const usedByOther = state.knownMinions.some((x) => x.playerId !== m.playerId && x.roleId === role.id);
                        return (
                          <option key={role.id} value={role.id} disabled={usedByOther}>
                            {role.symbol} {role.name}{usedByOther ? " — 他の味方で確認済み" : ""}
                          </option>
                        );
                      })}
                    </select>
                  </label>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="evil-section">
        <h3>ストーリーテラーからのブラフ</h3>
        {getsStartingInfo ? (
          <>
            <p className="panel-note">
              7人以上では3つの「ゲームに入っていない善側役職」を登録できます。ここは候補盤面の機械的制約として使います。
              {` ${state.storytellerBluffs.length}/3`}
            </p>
            <div className="role-grid">
              {GOOD_ROLES.map((role) => (
                <button
                  key={role.id}
                  type="button"
                  className={state.storytellerBluffs.includes(role.id) ? "role-choice role-choice-selected evil-role-selected" : "role-choice"}
                  onClick={() => toggleStorytellerBluff(role.id)}
                >
                  <span className="role-choice-symbol">{role.symbol}</span>
                  <span className="role-choice-name">{role.name}</span>
                </button>
              ))}
            </div>
          </>
        ) : (
          <p className="panel-note">5〜6人の通常ルールでは開始時のデーモンブラフはありません。</p>
        )}
      </section>

      <section className="evil-section">
        <h3>味方のブラフ計画</h3>
        <p className="panel-note">これは作戦メモです。候補盤面を機械的に固定しません。</p>
        {teamMembers.map((player) => (
          <div className="evil-plan-row" key={player}>
            <label>{person(g, player)}</label>
            <select
              value={state.bluffPlans[player] ?? ""}
              onChange={(e) => setBluffPlan(player, e.target.value ? (e.target.value as RoleId) : null)}
            >
              <option value="">未設定</option>
              {GOOD_ROLES.map((role) => (
                <option key={role.id} value={role.id}>
                  {role.symbol} {role.name}
                  {state.storytellerBluffs.includes(role.id)
                    ? " — ST安全"
                    : opponentClaimersFor(role.id).length
                      ? " — 相手主張"
                      : ""}
                </option>
              ))}
            </select>
          </div>
        ))}
      </section>

      <section className="evil-section">
        <h3>ブラフ候補 / 相手の主張</h3>
        <p className="panel-note">
          「ST安全」は確定で不在。「未主張」はまだ安全とは限りません。相手の現在の役職主張との衝突だけを見ています。
        </p>
        <div className="bluff-board">
          {bluffRows.map(({ role, status, claimers, allyUsers }) => (
            <div className={`bluff-row bluff-${status}`} key={role.id}>
              <span className="bluff-role"><strong>{role.symbol}</strong> {role.name}</span>
              <span className="bluff-status">
                {status === "unclaimed" && "未主張 / 不明"}
                {status === "storyteller" && "ST安全"}
                {claimers.length > 0 && `${status === "storyteller" ? " / " : ""}相手主張: ${claimers.map((p) => person(g, p)).join(" / ")}`}
                {allyUsers.length > 0 && `${status !== "unclaimed" || claimers.length > 0 ? " / " : ""}味方使用: ${allyUsers.map((p) => person(g, p)).join(" / ")}`}
              </span>
            </div>
          ))}
        </div>
      </section>

      {impMode ? (
      <section className="evil-section">
        <h3>襲撃対象</h3>
        {nightOptions.length === 0 ? (
          <p className="panel-note">インプは初夜には襲撃しません。N2以降に記録できます。</p>
        ) : (
          <>
            <div className="form-section">
              <label>いつ</label>
              <select value={attackNight} onChange={(e) => setAttackNight(e.target.value)}>
                {nightOptions.map((phase) => <option key={phase} value={phase}>{phase}</option>)}
              </select>
            </div>
            <div className="claim-option-title">選んだ相手</div>
            <div className="player-toggle-grid">
              {allPlayers.map((player) => (
                <button
                  key={player}
                  type="button"
                  className={attackTarget === player ? "player-toggle selected evil-selected" : "player-toggle"}
                  onClick={() => setAttackTarget(attackTarget === player ? null : player)}
                >
                  {person(g, player)}{g.playerStatus[player]?.alive === false ? " †" : ""}
                </button>
              ))}
            </div>
            {attackHint && <p className="panel-note demon-target-hint">{attackHint}</p>}
            <div className="form-section">
              <label>作戦メモ（任意）</label>
              <textarea value={attackNote} maxLength={500} onChange={(e) => setAttackNote(e.target.value)} placeholder="例：兵士ブラフ用に死者を選択、N3でスターパス予定" />
            </div>
            <button className="menu-option confirm-claim-button evil-confirm" disabled={!attackTarget || !nightOptions.includes(attackNight)} onClick={saveAttack}>
              襲撃を記録
            </button>
          </>
        )}

        {suggestions.length > 0 && (
          <div className="target-suggestions">
            <h4>標的候補</h4>
            <p className="panel-note">役職主張と現在の候補盤面から作る軽い優先候補です。兵士・鴉飼い系の餌主張は下げています。</p>
            {suggestions.map((s) => (
              <button key={s.player} className="target-suggestion" onClick={() => setAttackTarget(s.player)}>
                <strong>{person(g, s.player)}</strong>
                <span>{s.reasons.join(" / ") || "比較材料が少ない"}</span>
              </button>
            ))}
          </div>
        )}

        {actions.length > 0 && (
          <div className="claim-history">
            <div className="claim-history-title">襲撃履歴</div>
            {[...actions].sort((a, b) => Number(b.when.slice(1)) - Number(a.when.slice(1))).map((a) => (
              <div className="demon-action-row" key={a.id}>
                <div><strong>{a.when}</strong> → {person(g, a.target)}</div>
                <small>{publicNightResult(g, a)}</small>
                {a.note && <span>{a.note}</span>}
                <button
                  type="button"
                  className="mini-danger-button"
                  onClick={() => {
                    if (window.confirm(`${a.when}の襲撃記録を削除しますか？`)) onChangeActions(actions.filter((x) => x.id !== a.id));
                  }}
                >
                  削除
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      ) : (
        <section className="evil-section">
          <h3>専用能力</h3>
          <p className="panel-note">{selfDemon.name} の専用能力は現在「汎用推理」で扱います。チーム情報・STブラフ・ブラフ計画はスクリプトに応じてそのまま使えます。</p>
        </section>
      )}

      <button className="menu-option" onClick={onBack}>戻る</button>
    </>
  );
}
