import type { RoleId, RoleType } from "./roles";

export type Alignment = "good" | "evil";
export type Screen = "home" | "setup" | "game";
export type ClaimVisibility = "public" | "private";
export type RoleClaimType = "normal" | "bluff";
export type RoleClaimOrigin = "manual" | "ability_claim";
export type ClaimSubjectKind = "role" | "tag" | "type" | "alignment";

export type ClaimableRoleTag =
  | "FIRST_NIGHT_INFO"
  | "CONTINUOUS_INFO"
  | "LACK_OF_INFO"
  | "WANTS_DEMON_TARGET"
  | "HIGH_SURVIVAL_VALUE";

export type ClaimSubject =
  | { kind: "role"; roleId: RoleId }
  | { kind: "tag"; tag: ClaimableRoleTag }
  | { kind: "type"; roleType: RoleType }
  | { kind: "alignment"; alignment: Alignment };

export type RoleClaimEvent = {
  id: number;
  playerId: string;
  subject: ClaimSubject;
  claimType: RoleClaimType;
  origin: RoleClaimOrigin;
  sourceEventId?: number;
  visibility: ClaimVisibility;
  recipients: string[];
  when: string;
};

export type AbilityClaimEvent = {
  id: number;
  playerId: string;
  roleId: RoleId;
  when: string;
  targets: string[];
  result: string | null;
  structured?: StructuredInfo;
  reportedWhen?: string;
  sourcePlayerId?: string;
  visibility: ClaimVisibility;
  recipients: string[];
};

export type PlayerStatus = {
  alive: boolean;
  deadVoteAvailable: boolean;
};

export type DeathReasonId =
  | "storyteller"
  | "execution"
  | "night_death"
  | "ability"
  | "other";

export type DeathEvent = {
  id: number;
  playerId: string;
  when: string;
  reason: DeathReasonId;
  isExecution?: boolean;
  order?: number;
  sourceRoleId?: RoleId;
  sourcePlayerId?: string;
  sourceEventId?: number;
};

export type RevivalEvent = {
  id: number;
  playerId: string;
  when: string;
  order?: number;
  sourceRoleId?: RoleId;
};

export type DeathReasonDefinition = {
  id: DeathReasonId;
  label: string;
  phase: "day" | "night" | "any";
};

export type NominationEvent = {
  id: number;
  nominator: string;
  nominee: string;
  when: string;
  voters: string[];
  reason?: string;
  votingOccurred?: boolean;
  order?: number;
};

export type TalkTopic =
  | "role_claim"
  | "ability_claim"
  | "info"
  | "strategy"
  | "other";

export type TalkEvent = {
  id: number;
  participants: string[];
  when: string;
  topic: TalkTopic | null;
  details: string | null;
};

export type AbilityTriggerEvent = {
  id: number;
  roleId: "virgin" | "slayer";
  rolePlayerId: string;
  when: string;
  targetPlayerId: string;
  triggered: boolean;
  sourceEventId?: number;
};

export type TriggerDraft = {
  kind: "virgin" | "slayer";
  rolePlayerId: string;
  targetPlayerId: string | null;
  when: string;
  sourceEventId?: number;
  result: boolean | null;
};

export type SelfRoleState = {
  shownRole: RoleId | null;
};

export type KnownMinionSource = "demon_info" | "minion_info" | "confirmed_later";

export type KnownMinion = {
  playerId: string;
  source: KnownMinionSource;
  /** Optional exact character learned later from the teammate. Initial Demon info only reveals the player. */
  roleId?: RoleId | null;
};

export type DemonState = {
  knownMinions: KnownMinion[];
  storytellerBluffs: RoleId[];
  bluffPlans: Record<string, RoleId | null>;
};

export type DemonActionEvent = {
  id: number;
  roleId: "imp";
  when: string;
  target: string;
  note: string | null;
};

export type KnownDemonSource = "minion_info" | "confirmed_later";

export type KnownDemon = {
  playerId: string;
  source: KnownDemonSource;
};

export type MinionState = {
  /** Starting Minion info in 7+ players, or a Demon identified later in Teensyville. */
  knownDemon: KnownDemon | null;
  /** Other Minion players. Starting info only reveals seats, not exact Minion characters. */
  knownMinions: KnownMinion[];
  /** Storyteller bluffs explicitly shared by the real Demon. These are out of play. */
  sharedStorytellerBluffs: RoleId[];
  /** Team bluff plan only; never used as a mechanical solver constraint. */
  bluffPlans: Record<string, RoleId | null>;
  /** Spy-only: exact starting characters copied from the N1 Grimoire. Partial entry is allowed. */
  spyInitialRoles: Record<string, RoleId | null>;
  /** Spy-only: Fortune Teller red herring if copied from the Grimoire. */
  spyRedHerring: string | null;
  /** Direct self-observation that this Minion became the Imp. */
  becameDemonAt: string | null;
};

export type MinionActionEvent =
  | {
      id: number;
      roleId: "poisoner";
      kind: "poison";
      when: string;
      target: string;
      note: string | null;
    }
  | {
      id: number;
      roleId: "spy";
      kind: "grimoire";
      when: string;
      poisonTarget: string | null;
      note: string | null;
    }
  | {
      id: number;
      roleId: "pit_hag";
      kind: "transform";
      when: string;
      target: string;
      newRole: RoleId;
      note: string | null;
    };

export type SelfInfoEvent =
  | {
      id: number;
      roleId: "washerwoman" | "investigator";
      when: "N1";
      players: [string, string];
      shownRole: RoleId;
    }
  | {
      id: number;
      roleId: "librarian";
      when: "N1";
      noOutsiders: boolean;
      players?: [string, string];
      shownRole?: RoleId;
    }
  | {
      id: number;
      roleId: "chef";
      when: "N1";
      number: number;
    }
  | {
      id: number;
      roleId: "empath";
      when: string;
      number: 0 | 1 | 2;
    }
  | {
      id: number;
      roleId: "fortune_teller";
      when: string;
      players: [string, string];
      result: "yes" | "no";
    }
  | {
      id: number;
      roleId: "undertaker";
      when: string;
      player: string;
      shownRole: RoleId;
    }
  | {
      id: number;
      roleId: "ravenkeeper";
      when: string;
      player: string;
      shownRole: RoleId;
    };

export type SelfActionEvent =
  | {
      id: number;
      roleId: "monk";
      when: string;
      target: string;
    }
  | {
      id: number;
      roleId: "exorcist";
      when: string;
      target: string;
    }
  | {
      id: number;
      roleId: "slayer";
      when: string;
      target: string;
      killed: boolean;
    };

export type PlayerPanel =
  | "menu"
  | "identity"
  | "claim"
  | "ability_claim"
  | "nomination"
  | "status"
  | "death"
  | "talk"
  | "trigger"
  | "read"
  | "reported_info";

export type SelfPanel = "menu" | "role" | "info" | "action" | "demon" | "minion" | "advice";


export type StructuredInfo =
  | { kind: "pairRole"; players: [string, string]; shownRole: RoleId }
  | { kind: "noOutsiders" }
  | { kind: "number"; value: number }
  | { kind: "pairYesNo"; players: [string, string]; result: "yes" | "no" }
  | { kind: "roleReveal"; player: string; shownRole: RoleId }
  | { kind: "action"; target: string };
export type ManualRead = { playerId: string; roleId: RoleId | null; alignment: Alignment | "unknown"; note: string; updatedAt: number };
export type GameSnapshot = {
  schemaVersion: 2;
  playerCount: number;
  playset: string;
  /** Frozen script metadata so custom games remain valid even if the saved custom script is later edited/deleted. */
  scriptName?: string;
  scriptRoleIds?: RoleId[];
  night: number;
  playerNames: Record<string, string>;
  playerStatus: Record<string, PlayerStatus>;
  roleClaimLog: RoleClaimEvent[];
  abilityClaimLog: AbilityClaimEvent[];
  deathLog: DeathEvent[];
  /** Optional for backward compatibility with saves created before revival tracking. */
  revivalLog?: RevivalEvent[];
  nominationLog: NominationEvent[];
  abilityTriggerLog: AbilityTriggerEvent[];
  talkLog: TalkEvent[];
  selfRole: SelfRoleState;
  selfInfoLog: SelfInfoEvent[];
  selfActionLog: SelfActionEvent[];
  /** Optional for backward compatibility with pre-demon-mode saves. */
  demonState?: DemonState;
  /** Optional for backward compatibility with pre-demon-mode saves. */
  demonActionLog?: DemonActionEvent[];
  /** Optional for backward compatibility with pre-minion-mode saves. */
  minionState?: MinionState;
  /** Optional for backward compatibility with pre-minion-mode saves. */
  minionActionLog?: MinionActionEvent[];
  manualReads: Record<string, ManualRead>;
  completedNights: number[];
  noExecutionDays: number[];
};

export type GameLogOutcome = "unknown" | "good" | "evil" | "special";
export type GameLogStatus = "snapshot" | "finished";

export type GameLogReasoningSummary = {
  generatedAt: number;
  checked: number;
  unique: number;
  effectiveWorlds: number;
  meta: boolean;
  playerShares: Record<string, { evil: number; demon: number; drunk: number }>;
  presence: Partial<Record<RoleId, number>>;
  topWorlds: Array<{
    initial: Record<string, RoleId>;
    current: Record<string, RoleId>;
    /** Added in the S&V role/alignment split. Optional so old archived logs still load. */
    initialAlignment?: Record<string, Alignment>;
    currentAlignment?: Record<string, Alignment>;
    requiredPoison: Record<number, string>;
    assumptions: string[];
    changes: Array<
      | { when: string; from: string; to: string; kind: "scarlet" | "starpass" }
      | { when: string; playerId: string; fromRole: RoleId; toRole: RoleId; kind: "pit_hag" }
    >;
  }>;
};

export type GameLogEntry = {
  schemaVersion: 1;
  id: string;
  savedAt: number;
  status: GameLogStatus;
  outcome: GameLogOutcome;
  label: string;
  note: string;
  game: GameSnapshot;
  reasoning: GameLogReasoningSummary | null;
};
