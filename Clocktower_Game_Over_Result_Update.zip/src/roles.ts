export type RoleId =
  | "washerwoman"
  | "librarian"
  | "investigator"
  | "chef"
  | "empath"
  | "fortune_teller"
  | "undertaker"
  | "monk"
  | "ravenkeeper"
  | "virgin"
  | "slayer"
  | "soldier"
  | "mayor"
  | "butler"
  | "drunk"
  | "recluse"
  | "saint"
  | "poisoner"
  | "spy"
  | "scarlet_woman"
  | "baron"
  | "imp"
  | "grandmother"
  | "sailor"
  | "chambermaid"
  | "exorcist"
  | "innkeeper"
  | "gambler"
  | "gossip"
  | "courtier"
  | "professor"
  | "minstrel"
  | "tea_lady"
  | "pacifist"
  | "fool"
  | "goon"
  | "lunatic"
  | "tinker"
  | "moonchild"
  | "godfather"
  | "devils_advocate"
  | "assassin"
  | "mastermind"
  | "zombuul"
  | "pukka"
  | "shabaloth"
  | "po"
  | "clockmaker"
  | "dreamer"
  | "snake_charmer"
  | "mathematician"
  | "flowergirl"
  | "town_crier"
  | "oracle"
  | "savant"
  | "seamstress"
  | "philosopher"
  | "artist"
  | "juggler"
  | "sage"
  | "mutant"
  | "sweetheart"
  | "barber"
  | "klutz"
  | "evil_twin"
  | "witch"
  | "cerenovus"
  | "pit_hag"
  | "fang_gu"
  | "vigormortis"
  | "no_dashii"
  | "vortox";

export type RoleType = "townsfolk" | "outsider" | "minion" | "demon";

export type RoleTag =
  // Information / claim categories
  | "INFO_SOURCE"
  | "FIRST_NIGHT_INFO"
  | "CONTINUOUS_INFO"
  | "LACK_OF_INFO"

  // Night waking
  | "WAKES_FIRST_NIGHT"
  | "WAKES_OTHER_NIGHTS"
  | "CONDITIONAL_NIGHT_WAKE"

  // Ability timing / triggers
  | "ONE_TIME_ABILITY"
  | "DAY_ABILITY"
  | "PASSIVE"
  | "ON_NIGHT_DEATH"
  | "ON_EXECUTION"
  | "ON_NOMINATION"
  | "ON_DEATH"
  | "ON_DEMON_EXECUTION"

  // Targeting / effects
  | "TARGETS_PLAYER"
  | "TARGETS_CHARACTER"
  | "PREVENTS_DEATH"
  | "PREVENTS_EXECUTION_DEATH"
  | "KILLS"
  | "CAUSES_OWN_DEATH"
  | "BYPASSES_DEATH_PREVENTION"
  | "REVIVES"
  | "POISON_DRUNK_ABILITY"

  // Strategic claim categories
  | "HIGH_SURVIVAL_VALUE"
  | "WANTS_DEMON_TARGET"
  | "AVOIDS_DEMON_TARGET"
  | "AVOIDS_EXECUTION"

  // Special mechanics
  | "REGISTRATION_CHANGING"
  | "SECRET_INFORMATION_ACCESS"
  | "ROLE_HIDDEN_FROM_SELF"
  | "THINKS_TOWNSFOLK"
  | "THINKS_OUTSIDER"
  | "THINKS_MINION"
  | "THINKS_DEMON"
  | "VOTE_RESTRICTED"
  | "SETUP_EFFECT"
  | "OUTSIDER_COUNT_MODIFIER"
  | "DEMON_CHANGE"
  | "ALIGNMENT_CHANGING"
  | "ROLE_CHANGING"
  | "GAME_CONTINUATION"
  | "EXECUTION_LOSS"
  | "ALTERNATE_WIN_CONDITION"

  // Confirmation
  | "HIGH_CONFIRMABILITY"
  | "CONDITIONAL_CONFIRMABILITY";

export type NightSpeed = {
  first: number | null;
  other: number | null;
};

export type Role = {
  id: RoleId;
  symbol: string;
  name: string;
  type: RoleType;
  tags: RoleTag[];
  nightSpeed: NightSpeed;
  /** full = mechanically modelled by the current solver; generic = script/world support only. */
  solverSupport: "full" | "generic";
  /** Maximum number of players this Demon can kill in one night from its own ability. */
  maxKillsPerNight?: number;
};

/*
 * SPEED BANDS
 *
 * 10000s = Game-start / alignment effects
 *  9000s = Poison / drunk effects
 *  8000s = Protection effects
 *  7000s = Non-killing Minion effects
 *  6000s = Demon effects
 *  5000s = Non-Demon killing effects
 *  4000s = Reactive / response effects
 *  3000s = Information effects
 *  2000s = Reserved
 *  1000s = Slow / maintenance effects
 *
 * Higher speed resolves first.
 * A non-null speed does not automatically mean a player wakes every night;
 * the WAKES_* / CONDITIONAL_NIGHT_WAKE tags describe that separately.
 */

export const ROLES: Record<RoleId, Role> = {
  washerwoman: {
    id: "washerwoman",
    symbol: "洗",
    name: "洗濯婦",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "FIRST_NIGHT_INFO",
      "WAKES_FIRST_NIGHT",
      "HIGH_CONFIRMABILITY",
    ],
    nightSpeed: { first: 3900, other: null },
    solverSupport: "full",
  },

  librarian: {
    id: "librarian",
    symbol: "図",
    name: "司書",
    type: "townsfolk",
    tags: ["INFO_SOURCE", "FIRST_NIGHT_INFO", "WAKES_FIRST_NIGHT"],
    nightSpeed: { first: 3800, other: null },
    solverSupport: "full",
  },

  investigator: {
    id: "investigator",
    symbol: "探",
    name: "捜査官",
    type: "townsfolk",
    tags: ["INFO_SOURCE", "FIRST_NIGHT_INFO", "WAKES_FIRST_NIGHT"],
    nightSpeed: { first: 3700, other: null },
    solverSupport: "full",
  },

  chef: {
    id: "chef",
    symbol: "料",
    name: "料理人",
    type: "townsfolk",
    tags: ["INFO_SOURCE", "FIRST_NIGHT_INFO", "WAKES_FIRST_NIGHT"],
    nightSpeed: { first: 3600, other: null },
    solverSupport: "full",
  },

  empath: {
    id: "empath",
    symbol: "感",
    name: "共感者",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "CONTINUOUS_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "HIGH_SURVIVAL_VALUE",
    ],
    nightSpeed: { first: 3400, other: 3400 },
    solverSupport: "full",
  },

  fortune_teller: {
    id: "fortune_teller",
    symbol: "占",
    name: "占い師",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "CONTINUOUS_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "HIGH_SURVIVAL_VALUE",
    ],
    nightSpeed: { first: 3300, other: 3300 },
    solverSupport: "full",
  },

  undertaker: {
    id: "undertaker",
    symbol: "墓",
    name: "葬儀屋",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "CONTINUOUS_INFO",
      "WAKES_OTHER_NIGHTS",
      "HIGH_SURVIVAL_VALUE",
    ],
    nightSpeed: { first: null, other: 3500 },
    solverSupport: "full",
  },

  monk: {
    id: "monk",
    symbol: "僧",
    name: "僧侶",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "PREVENTS_DEATH",
      "HIGH_SURVIVAL_VALUE",
      "AVOIDS_DEMON_TARGET",
    ],
    nightSpeed: { first: null, other: 8900 },
    solverSupport: "full",
  },

  ravenkeeper: {
    id: "ravenkeeper",
    symbol: "烏",
    name: "鴉飼い",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "ONE_TIME_ABILITY",
      "CONDITIONAL_NIGHT_WAKE",
      "ON_NIGHT_DEATH",
      "TARGETS_PLAYER",
      "WANTS_DEMON_TARGET",
    ],
    nightSpeed: { first: null, other: 4800 },
    solverSupport: "full",
  },

  virgin: {
    id: "virgin",
    symbol: "生",
    name: "処女",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "PASSIVE",
      "ONE_TIME_ABILITY",
      "ON_NOMINATION",
      "CONDITIONAL_CONFIRMABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  slayer: {
    id: "slayer",
    symbol: "殺",
    name: "処刑人",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "DAY_ABILITY",
      "ONE_TIME_ABILITY",
      "TARGETS_PLAYER",
      "KILLS",
      "CONDITIONAL_CONFIRMABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  soldier: {
    id: "soldier",
    symbol: "兵",
    name: "兵士",
    type: "townsfolk",
    tags: ["LACK_OF_INFO", "PASSIVE", "PREVENTS_DEATH", "WANTS_DEMON_TARGET"],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  mayor: {
    id: "mayor",
    symbol: "市",
    name: "市長",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "PASSIVE",
      "HIGH_SURVIVAL_VALUE",
      "AVOIDS_DEMON_TARGET",
      "AVOIDS_EXECUTION",
      "ALTERNATE_WIN_CONDITION",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  butler: {
    id: "butler",
    symbol: "召",
    name: "執事",
    type: "outsider",
    tags: [
      "LACK_OF_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "VOTE_RESTRICTED",
    ],
    nightSpeed: { first: 1900, other: 1900 },
    solverSupport: "full",
  },

  drunk: {
    id: "drunk",
    symbol: "酒",
    name: "酔っ払い",
    type: "outsider",
    tags: ["LACK_OF_INFO", "ROLE_HIDDEN_FROM_SELF", "THINKS_TOWNSFOLK"],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  recluse: {
    id: "recluse",
    symbol: "篭",
    name: "隠者",
    type: "outsider",
    tags: ["LACK_OF_INFO", "PASSIVE", "REGISTRATION_CHANGING"],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  saint: {
    id: "saint",
    symbol: "聖",
    name: "聖人",
    type: "outsider",
    tags: [
      "LACK_OF_INFO",
      "PASSIVE",
      "ON_EXECUTION",
      "EXECUTION_LOSS",
      "ALTERNATE_WIN_CONDITION",
      "AVOIDS_EXECUTION",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  poisoner: {
    id: "poisoner",
    symbol: "毒",
    name: "毒殺者",
    type: "minion",
    tags: [
      "LACK_OF_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "POISON_DRUNK_ABILITY",
    ],
    nightSpeed: { first: 9900, other: 9900 },
    solverSupport: "full",
  },

  spy: {
    id: "spy",
    symbol: "密",
    name: "スパイ",
    type: "minion",
    tags: [
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "REGISTRATION_CHANGING",
      "SECRET_INFORMATION_ACCESS",
    ],
    nightSpeed: { first: 7900, other: 7900 },
    solverSupport: "full",
  },

  scarlet_woman: {
    id: "scarlet_woman",
    symbol: "紅",
    name: "緋色の女",
    type: "minion",
    tags: [
      "LACK_OF_INFO",
      "PASSIVE",
      "CONDITIONAL_NIGHT_WAKE",
      "DEMON_CHANGE",
    ],
    nightSpeed: { first: null, other: 4900 },
    solverSupport: "full",
  },

  baron: {
    id: "baron",
    symbol: "爵",
    name: "男爵",
    type: "minion",
    tags: ["LACK_OF_INFO", "SETUP_EFFECT", "OUTSIDER_COUNT_MODIFIER"],
    nightSpeed: { first: null, other: null },
    solverSupport: "full",
  },

  imp: {
    id: "imp",
    symbol: "戯",
    name: "インプ",
    type: "demon",
    tags: [
      "LACK_OF_INFO",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "KILLS",
      "DEMON_CHANGE",
    ],
    nightSpeed: { first: null, other: 6900 },
    solverSupport: "full",
    maxKillsPerNight: 1,
  },
  grandmother: {
    id: "grandmother",
    symbol: "祖",
    name: "Grandmother",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "FIRST_NIGHT_INFO",
      "WAKES_FIRST_NIGHT",
      "KILLS",
      "CAUSES_OWN_DEATH",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  sailor: {
    id: "sailor",
    symbol: "船",
    name: "Sailor",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "PREVENTS_DEATH",
      "PREVENTS_EXECUTION_DEATH",
      "POISON_DRUNK_ABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  chambermaid: {
    id: "chambermaid",
    symbol: "婢",
    name: "Chambermaid",
    type: "townsfolk",
    tags: [
      "INFO_SOURCE",
      "CONTINUOUS_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  exorcist: {
    id: "exorcist",
    symbol: "祓",
    name: "Exorcist",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "PREVENTS_DEATH",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  innkeeper: {
    id: "innkeeper",
    symbol: "宿",
    name: "Innkeeper",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "PREVENTS_DEATH",
      "POISON_DRUNK_ABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  gambler: {
    id: "gambler",
    symbol: "賭",
    name: "Gambler",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "TARGETS_CHARACTER",
      "KILLS",
      "CAUSES_OWN_DEATH",
      "CONDITIONAL_CONFIRMABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  gossip: {
    id: "gossip",
    symbol: "噂",
    name: "Gossip",
    type: "townsfolk",
    tags: ["LACK_OF_INFO", "DAY_ABILITY", "KILLS"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  courtier: {
    id: "courtier",
    symbol: "廷",
    name: "Courtier",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "ONE_TIME_ABILITY",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_CHARACTER",
      "POISON_DRUNK_ABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  professor: {
    id: "professor",
    symbol: "教",
    name: "Professor",
    type: "townsfolk",
    tags: [
      "LACK_OF_INFO",
      "ONE_TIME_ABILITY",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "REVIVES",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  minstrel: {
    id: "minstrel",
    symbol: "吟",
    name: "Minstrel",
    type: "townsfolk",
    tags: ["LACK_OF_INFO", "PASSIVE", "POISON_DRUNK_ABILITY"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  tea_lady: {
    id: "tea_lady",
    symbol: "茶",
    name: "Tea Lady",
    type: "townsfolk",
    tags: ["LACK_OF_INFO", "PASSIVE", "PREVENTS_DEATH", "PREVENTS_EXECUTION_DEATH"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  pacifist: {
    id: "pacifist",
    symbol: "和",
    name: "Pacifist",
    type: "townsfolk",
    tags: ["LACK_OF_INFO", "PASSIVE", "PREVENTS_EXECUTION_DEATH"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  fool: {
    id: "fool",
    symbol: "愚",
    name: "Fool",
    type: "townsfolk",
    tags: ["LACK_OF_INFO", "PASSIVE", "ONE_TIME_ABILITY", "PREVENTS_DEATH", "PREVENTS_EXECUTION_DEATH"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  goon: {
    id: "goon",
    symbol: "暴",
    name: "Goon",
    type: "outsider",
    tags: [
      "LACK_OF_INFO",
      "PASSIVE",
      "CONDITIONAL_NIGHT_WAKE",
      "POISON_DRUNK_ABILITY",
      "ALIGNMENT_CHANGING",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  lunatic: {
    id: "lunatic",
    symbol: "狂",
    name: "Lunatic",
    type: "outsider",
    tags: [
      "ROLE_HIDDEN_FROM_SELF",
      "THINKS_DEMON",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  tinker: {
    id: "tinker",
    symbol: "工",
    name: "Tinker",
    type: "outsider",
    tags: ["LACK_OF_INFO", "PASSIVE", "KILLS", "CAUSES_OWN_DEATH"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  moonchild: {
    id: "moonchild",
    symbol: "月",
    name: "Moonchild",
    type: "outsider",
    tags: ["LACK_OF_INFO", "ON_DEATH", "TARGETS_PLAYER", "KILLS"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  godfather: {
    id: "godfather",
    symbol: "父",
    name: "Godfather",
    type: "minion",
    tags: [
      "INFO_SOURCE",
      "FIRST_NIGHT_INFO",
      "WAKES_FIRST_NIGHT",
      "CONDITIONAL_NIGHT_WAKE",
      "TARGETS_PLAYER",
      "KILLS",
      "SETUP_EFFECT",
      "OUTSIDER_COUNT_MODIFIER",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  devils_advocate: {
    id: "devils_advocate",
    symbol: "弁",
    name: "Devil's Advocate",
    type: "minion",
    tags: [
      "LACK_OF_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "PREVENTS_EXECUTION_DEATH",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  assassin: {
    id: "assassin",
    symbol: "暗",
    name: "Assassin",
    type: "minion",
    tags: [
      "LACK_OF_INFO",
      "ONE_TIME_ABILITY",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "KILLS",
      "BYPASSES_DEATH_PREVENTION",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  mastermind: {
    id: "mastermind",
    symbol: "策",
    name: "Mastermind",
    type: "minion",
    tags: [
      "LACK_OF_INFO",
      "PASSIVE",
      "ON_DEMON_EXECUTION",
      "GAME_CONTINUATION",
      "ALTERNATE_WIN_CONDITION",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  zombuul: {
    id: "zombuul",
    symbol: "屍",
    name: "Zombuul",
    type: "demon",
    tags: [
      "LACK_OF_INFO",
      "CONDITIONAL_NIGHT_WAKE",
      "TARGETS_PLAYER",
      "KILLS",
      "PREVENTS_DEATH",
      "REGISTRATION_CHANGING",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
    maxKillsPerNight: 1,
  },
  pukka: {
    id: "pukka",
    symbol: "病",
    name: "Pukka",
    type: "demon",
    tags: [
      "LACK_OF_INFO",
      "WAKES_FIRST_NIGHT",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "KILLS",
      "POISON_DRUNK_ABILITY",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
    maxKillsPerNight: 1,
  },
  shabaloth: {
    id: "shabaloth",
    symbol: "喰",
    name: "Shabaloth",
    type: "demon",
    tags: [
      "LACK_OF_INFO",
      "WAKES_OTHER_NIGHTS",
      "TARGETS_PLAYER",
      "KILLS",
      "REVIVES",
    ],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
    maxKillsPerNight: 2,
  },
  po: {
    id: "po",
    symbol: "爆",
    name: "Po",
    type: "demon",
    tags: ["LACK_OF_INFO", "WAKES_OTHER_NIGHTS", "TARGETS_PLAYER", "KILLS"],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
    maxKillsPerNight: 3,
  },
  clockmaker: {
    id: "clockmaker",
    symbol: "時",
    name: "Clockmaker",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  dreamer: {
    id: "dreamer",
    symbol: "夢",
    name: "Dreamer",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  snake_charmer: {
    id: "snake_charmer",
    symbol: "蛇",
    name: "Snake Charmer",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  mathematician: {
    id: "mathematician",
    symbol: "数",
    name: "Mathematician",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  flowergirl: {
    id: "flowergirl",
    symbol: "花",
    name: "Flowergirl",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  town_crier: {
    id: "town_crier",
    symbol: "告",
    name: "Town Crier",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  oracle: {
    id: "oracle",
    symbol: "神",
    name: "Oracle",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  savant: {
    id: "savant",
    symbol: "賢",
    name: "Savant",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  seamstress: {
    id: "seamstress",
    symbol: "縫",
    name: "Seamstress",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  philosopher: {
    id: "philosopher",
    symbol: "哲",
    name: "Philosopher",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  artist: {
    id: "artist",
    symbol: "芸",
    name: "Artist",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  juggler: {
    id: "juggler",
    symbol: "曲",
    name: "Juggler",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  sage: {
    id: "sage",
    symbol: "慧",
    name: "Sage",
    type: "townsfolk",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  mutant: {
    id: "mutant",
    symbol: "変",
    name: "Mutant",
    type: "outsider",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  sweetheart: {
    id: "sweetheart",
    symbol: "恋",
    name: "Sweetheart",
    type: "outsider",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  barber: {
    id: "barber",
    symbol: "髪",
    name: "Barber",
    type: "outsider",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  klutz: {
    id: "klutz",
    symbol: "鈍",
    name: "Klutz",
    type: "outsider",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  evil_twin: {
    id: "evil_twin",
    symbol: "双",
    name: "Evil Twin",
    type: "minion",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  witch: {
    id: "witch",
    symbol: "魔",
    name: "Witch",
    type: "minion",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  cerenovus: {
    id: "cerenovus",
    symbol: "脳",
    name: "Cerenovus",
    type: "minion",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  pit_hag: {
    id: "pit_hag",
    symbol: "釜",
    name: "Pit-Hag",
    type: "minion",
    tags: ["WAKES_OTHER_NIGHTS", "TARGETS_PLAYER", "TARGETS_CHARACTER", "ROLE_CHANGING"],
    nightSpeed: { first: null, other: 7600 },
    solverSupport: "generic",
  },
  fang_gu: {
    id: "fang_gu",
    symbol: "牙",
    name: "Fang Gu",
    type: "demon",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  vigormortis: {
    id: "vigormortis",
    symbol: "死",
    name: "Vigormortis",
    type: "demon",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  no_dashii: {
    id: "no_dashii",
    symbol: "触",
    name: "No Dashii",
    type: "demon",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
  vortox: {
    id: "vortox",
    symbol: "渦",
    name: "Vortox",
    type: "demon",
    tags: [],
    nightSpeed: { first: null, other: null },
    solverSupport: "generic",
  },
};

export const TROUBLE_BREWING_ROLE_IDS: RoleId[] = [
  "washerwoman",
  "librarian",
  "investigator",
  "chef",
  "empath",
  "fortune_teller",
  "undertaker",
  "monk",
  "ravenkeeper",
  "virgin",
  "slayer",
  "soldier",
  "mayor",
  "butler",
  "drunk",
  "recluse",
  "saint",
  "poisoner",
  "spy",
  "scarlet_woman",
  "baron",
  "imp"
];

export function hasTag(roleId: RoleId, tag: RoleTag): boolean {
  return ROLES[roleId].tags.includes(tag);
}

export function getRolesWithTag(tag: RoleTag): Role[] {
  return Object.values(ROLES).filter((role) => role.tags.includes(tag));
}

export function getRolesByType(type: RoleType): Role[] {
  return Object.values(ROLES).filter((role) => role.type === type);
}

export function getNightSpeed(roleId: RoleId, nightNumber: number): number | null {
  return nightNumber === 1
    ? ROLES[roleId].nightSpeed.first
    : ROLES[roleId].nightSpeed.other;
}
