import { ROLES, type RoleId, type RoleTag } from "../roles";
import { getSnapshotScriptRoleIds } from "../scripts";
import type { GameSnapshot } from "../types";
import type { SearchResult, SearchOptions, HistoryWorld, PlayerShare, Reason } from "./model";
import { DEFAULT_SEARCH_OPTIONS } from "./model";
import { seats, setupCounts, priorRole, empathStableNeighbourShifts, type EmpathShiftSignal } from "./game";
import { evaluateAssignment } from "./mechanics";
import { analyzeEvidence } from "./evidence";
export function rng(seed: number) { return () => {seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;}; }

export function empathShiftLogBonus(w: HistoryWorld, signals: EmpathShiftSignal[], g: GameSnapshot): number {
  if (!signals.length) return 0;
  const allowed = new Set(getSnapshotScriptRoleIds(g));
  const rolesInWorld = new Set<RoleId>([...Object.values(w.initial), ...Object.values(w.current)]);
  const hasImpairmentRole = [...rolesInWorld].some(id => allowed.has(id) && ROLES[id].tags.includes("POISON_DRUNK_ABILITY"));
  const hasAlignmentChanger = [...rolesInWorld].some(id => allowed.has(id) && ROLES[id].tags.includes("ALIGNMENT_CHANGING"));
  let bonus = 0;
  for (const signal of signals) {
    const drunkExplanation = w.initial[signal.source] === "drunk" || w.current[signal.source] === "drunk";
    const exactPoisonExplanation = signal.nights.some(n => w.requiredPoison[n] === signal.source);
    const base = signal.direct ? 0.9 : 0.55;
    const explanation = drunkExplanation || exactPoisonExplanation ? 1 : hasImpairmentRole ? 0.35 : hasAlignmentChanger ? 0.12 : 0;
    bonus += base * explanation;
  }
  return Math.min(bonus, 1.8);
}
function shuffle<T>(a: T[], random:()=>number): T[] {const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}
function combinations<T>(a:T[],n:number):T[][] {if(n===0)return[[]];return a.flatMap((v,i)=>combinations(a.slice(i+1),n-1).map(rest=>[v,...rest]));}
function selfIsMinion(g:GameSnapshot):boolean {
  const shown=g.selfRole.shownRole;
  return !!shown && ROLES[shown].type==='minion';
}
function knownMinionPlayers(g:GameSnapshot):string[]{
  if(g.selfRole.shownRole && ROLES[g.selfRole.shownRole].type==='demon') return (g.demonState?.knownMinions??[]).map(m=>m.playerId);
  if(selfIsMinion(g)) {
    return (g.minionState?.knownMinions??[]).map(m=>m.playerId);
  }
  return [];
}
function knownDemonPlayer(g:GameSnapshot):string|null {
  if(!selfIsMinion(g)) return null;
  const state=g.minionState;
  if(state?.knownDemon?.playerId) return state.knownDemon.playerId;
  return null;
}
function knownDemonBluffs(g:GameSnapshot):Set<RoleId>{
  if(g.playerCount<=6) return new Set();
  if(g.selfRole.shownRole && ROLES[g.selfRole.shownRole].type==='demon') return new Set(g.demonState?.storytellerBluffs??[]);
  if(selfIsMinion(g)) return new Set(g.minionState?.sharedStorytellerBluffs??[]);
  return new Set();
}
function hiddenTagForShown(roleId:RoleId):RoleTag {
  const type=ROLES[roleId].type;
  return type==='townsfolk'?'THINKS_TOWNSFOLK':type==='outsider'?'THINKS_OUTSIDER':type==='minion'?'THINKS_MINION':'THINKS_DEMON';
}
function hiddenSelfRoles(g:GameSnapshot, shown:RoleId):RoleId[]{
  const tag=hiddenTagForShown(shown), allowed=new Set(getSnapshotScriptRoleIds(g));
  return [...allowed].filter(id=>ROLES[id].tags.includes(tag));
}
export function hardLocks(g:GameSnapshot): {locks:Record<string,RoleId>;issues:Reason[]} {
  const locks:Record<string,RoleId>={},issues:Reason[]=[];
  for(const t of g.abilityTriggerLog.filter(t=>t.triggered)) {
    if(locks[t.rolePlayerId]&&locks[t.rolePlayerId]!==t.roleId) issues.push({code:'incompatiblePublicEvents',players:[t.rolePlayerId],evidence:[t.id],strength:'input'});
    locks[t.rolePlayerId]=t.roleId;
  }
  const shown=g.selfRole.shownRole;
  if(shown&&ROLES[shown].type==='minion'){
    if(locks.self&&locks.self!==shown) issues.push({code:'selfRoleConflict',players:['self'],evidence:[],strength:'input'});
    locks.self=shown;
  }
  if(shown&&ROLES[shown].type==='demon'&&hiddenSelfRoles(g,shown).length===0){
    if(locks.self&&locks.self!==shown) issues.push({code:'selfRoleConflict',players:['self'],evidence:[],strength:'input'});
    locks.self=shown;
  }
  for(const m of g.demonState?.knownMinions ?? []){
    if(!g.selfRole.shownRole || ROLES[g.selfRole.shownRole].type!=='demon') break;
    const p=m.playerId;
    if(locks[p]&&ROLES[locks[p]].type!=='minion') issues.push({code:'knownMinionConflict',players:[p],evidence:[],strength:'input'});
    if(m.roleId){
      if(locks[p]&&locks[p]!==m.roleId) issues.push({code:'knownMinionConflict',players:[p],evidence:[],strength:'input'});
      locks[p]=m.roleId;
    }
  }
  if(selfIsMinion(g)){
    const state=g.minionState;
    const demon=state?.knownDemon?.playerId;
    if(demon&&locks[demon]&&ROLES[locks[demon]].type!=='demon') issues.push({code:'knownDemonConflict',players:[demon],evidence:[],strength:'input'});
    for(const m of state?.knownMinions ?? []){
      const p=m.playerId;
      if(locks[p]&&ROLES[locks[p]].type!=='minion') issues.push({code:'knownMinionConflict',players:[p],evidence:[],strength:'input'});
      if(m.roleId){
        if(locks[p]&&locks[p]!==m.roleId) issues.push({code:'knownMinionConflict',players:[p],roles:[m.roleId],evidence:[],strength:'input'});
        locks[p]=m.roleId;
      }
    }
  }
  const values=Object.values(locks);
  if(new Set(values).size!==values.length) issues.push({code:'duplicatePublicRole',players:Object.keys(locks),evidence:[],strength:'input'});
  if(shown&&locks.self&&locks.self!==shown&&!hiddenSelfRoles(g,shown).includes(locks.self)) issues.push({code:'selfRoleConflict',players:['self'],evidence:[],strength:'input'});
  return {locks,issues};
}
export function drawAssignment(g:GameSnapshot,random:()=>number,locks:Record<string,RoleId>):Record<string,RoleId>|null {
  const ps=seats(g.playerCount), fixed={...locks};
  const scriptIds=getSnapshotScriptRoleIds(g), all=scriptIds.map(id=>ROLES[id]);
  const knownMinions=knownMinionPlayers(g);
  const selfMinion=selfIsMinion(g);
  const m=setupCounts(g.playerCount).minion;
  const knownMinionTotal=knownMinions.length+(selfMinion?1:0);
  if(knownMinionTotal>m||knownMinions.some(p=>p==='self'||!ps.includes(p)))return null;
  const knownDemon=knownDemonPlayer(g);
  if(knownDemon&&(knownDemon==='self'||!ps.includes(knownDemon)||knownMinions.includes(knownDemon)))return null;

  const fixedMinionRoles=new Set(Object.values(fixed).filter(r=>ROLES[r]?.type==='minion'));
  const minionPool=all.filter(r=>r.type==='minion').map(r=>r.id);
  const minions=shuffle(combinations(minionPool,m).filter(set=>[...fixedMinionRoles].every(r=>set.includes(r))),random)[0];
  if(!minions)return null;
  const counts=setupCounts(g.playerCount,minions.includes('baron'));

  const shown=g.selfRole.shownRole;
  if(shown&&!fixed.self){
    const hidden=hiddenSelfRoles(g,shown).filter(id=>scriptIds.includes(id));
    const pickHidden=hidden.length>0&&random()<.2;
    fixed.self=pickHidden?hidden[Math.floor(random()*hidden.length)]:shown;
  }

  // A healthy Spy's Grimoire is extremely informative, so most samples are
  // guided toward the entered display. It is NOT a hard lock when the Spy may be poisoned.
  if(shown==='spy' && g.minionState && random()<.82){
    for(const [p,r] of Object.entries(g.minionState.spyInitialRoles)){
      if(!r || !ps.includes(p) || !scriptIds.includes(r)) continue;
      if(fixed[p] && fixed[p]!==r) return null;
      fixed[p]=r;
    }
  }

  const occupiedMinionRoles=new Set(Object.values(fixed).filter(r=>ROLES[r]?.type==='minion'));
  const remainingMinionRoles=shuffle(minions.filter(r=>!occupiedMinionRoles.has(r)),random);
  for(const p of shuffle(knownMinions,random)){
    if(fixed[p]){if(ROLES[fixed[p]].type!=='minion')return null;continue;}
    const role=remainingMinionRoles.shift();if(!role)return null;fixed[p]=role;
  }
  const knownSet=new Set(knownMinions);if(selfMinion)knownSet.add('self');
  for(const [p,r] of Object.entries(fixed)) if(ROLES[r]?.type==='minion'&&!knownSet.has(p)&&knownMinionTotal===m)return null;

  const required=Object.values(fixed);
  if(required.some(r=>!scriptIds.includes(r))||new Set(required).size!==required.length)return null;
  const demonBluffs=knownDemonBluffs(g);

  const outPool=all.filter(r=>r.type==='outsider'&&!demonBluffs.has(r.id)).map(r=>r.id);
  const outSets=combinations(outPool,counts.outsider).filter(set=>required.filter(r=>ROLES[r].type==='outsider').every(r=>set.includes(r)));
  if(!outSets.length)return null;
  const outs=outSets[Math.floor(random()*outSets.length)];

  const tfRequired=required.filter(r=>ROLES[r].type==='townsfolk');
  if(tfRequired.length>counts.townsfolk)return null;
  const excluded=shown&&fixed.self==='drunk'?shown:null;
  const pool=all.filter(r=>r.type==='townsfolk'&&!tfRequired.includes(r.id)&&r.id!==excluded&&!demonBluffs.has(r.id)).map(r=>r.id);
  if(pool.length<counts.townsfolk-tfRequired.length)return null;
  const tfs=[...tfRequired];
  while(tfs.length<counts.townsfolk){
    const available=pool.filter(r=>!tfs.includes(r));
    const weights=available.map(r=>1+ps.filter(p=>priorRole(g,p)===r).length*2);
    let x=random()*weights.reduce((a,b)=>a+b,0),pick=available[0];
    for(let i=0;i<available.length;i++){x-=weights[i];if(x<=0){pick=available[i];break;}}
    tfs.push(pick);
  }

  const demonRequired=required.filter(r=>ROLES[r].type==='demon');
  if(demonRequired.length>1)return null;
  const demonPool=all.filter(r=>r.type==='demon').map(r=>r.id);
  if(!demonPool.length)return null;
  const demon=demonRequired[0]??demonPool[Math.floor(random()*demonPool.length)];

  let roles:RoleId[]=[...minions,...outs,...tfs,demon];
  if(required.some(r=>!roles.includes(r)))return null;
  for(const r of required){const i=roles.indexOf(r);if(i<0)return null;roles.splice(i,1);}
  const result={...fixed};
  for(const p of shuffle(ps.filter(p=>!fixed[p]),random)) {
    const claim=priorRole(g,p);
    const weights=roles.map(r=>r===claim?12:r==='drunk'&&claim&&ROLES[claim].type==='townsfolk'&&!Object.values({...fixed}).includes(claim)?3:1);
    let x=random()*weights.reduce((a,b)=>a+b,0),index=0;
    for(let i=0;i<roles.length;i++){x-=weights[i];if(x<=0){index=i;break;}}
    result[p]=roles[index];roles.splice(index,1);
  }
  if(knownMinionTotal===m&&ps.some(p=>!knownSet.has(p)&&ROLES[result[p]].type==='minion'))return null;
  if(knownDemon&&ROLES[result[knownDemon]].type!=='demon')return null;
  return result;
}
export function runSearch(g:GameSnapshot, options:Partial<SearchOptions>={},progress?:(checked:number,unique:number)=>void):SearchResult {
  const opts={...DEFAULT_SEARCH_OPTIONS,...options},start=Date.now(),random=rng(opts.seed),ps=seats(g.playerCount);
  const {locks,issues}=hardLocks(g);
  const evidence=analyzeEvidence(g);
  const empathShifts=empathStableNeighbourShifts(g);
  const candidates=new Map<string,HistoryWorld[]>(); let checked=0,accepted=0;
  if(!issues.length)for(;checked<opts.attempts;checked++) {
    if(Date.now()-start>opts.maxMillis)break;
    const assignment=drawAssignment(g,random,locks); if(!assignment)continue;
    const key=ps.map(p=>assignment[p]).join('|');if(candidates.has(key))continue;
    const worlds=evaluateAssignment(assignment,g,opts.beamWidth);
    if(worlds.length){accepted++;candidates.set(key,worlds);}
    if(progress&&checked%100===0)progress(checked,candidates.size);
  }
  const shares:Record<string,PlayerShare>=Object.fromEntries(ps.map(p=>[p,{evil:0,demon:0,drunk:0,roles:{},poison:{}}]));
  const result:SearchResult={kind:'sample',checked,accepted,unique:candidates.size,elapsedMs:Date.now()-start,exhaustive:false,beamWidth:opts.beamWidth,seed:opts.seed,meta:opts.meta,effectiveWorlds:0,truncated:checked<opts.attempts,players:shares,presence:{},info:{},worlds:[],examples:{},issues:[...issues,...evidence.issues]};
  const weighted:{w:HistoryWorld;log:number}[]=[];
  for(const histories of candidates.values())for(const w of histories){
    let log=w.logScore-Math.log(histories.length);
    log += empathShiftLogBonus(w, empathShifts, g);
    if(opts.meta)for(const [r,e]of Object.entries(evidence.global))if(Object.values(w.initial).includes(r as RoleId))log+=Math.min(e.points,2)*.15;
    weighted.push({w,log});
  }
  if(!weighted.length)return result;
  const max=weighted.reduce((m,x)=>Math.max(m,x.log),-Infinity);let total=0,sq=0;
  const assignWeights=new Map<string,number>();
  for(const {w,log}of weighted){
    const weight=Math.exp(log-max);total+=weight;
    const key=ps.map(p=>w.initial[p]).join('|');assignWeights.set(key,(assignWeights.get(key)??0)+weight);
    for(const p of ps){
      const s=shares[p],r=w.current[p];
      if(w.currentAlignment[p] === "evil")s.evil+=weight;
      if(ROLES[r].type==='demon'&&w.alive.includes(p))s.demon+=weight;
      if(w.current[p]==='drunk')s.drunk+=weight;
      s.roles[r]=(s.roles[r]??0)+weight;
      for(const [n,who]of Object.entries(w.requiredPoison))if(who===p)s.poison[Number(n)]=(s.poison[Number(n)]??0)+weight;
    }
    for(const role of new Set(Object.values(w.initial)))result.presence[role]=(result.presence[role]??0)+weight;
    for(const [id,state]of Object.entries(w.info)){
      const slot=result.info[Number(id)]??{works:0,registration:0,poison:0,drunk:0,bluff:0,lie:0,missing:0};slot[state]+=weight;result.info[Number(id)]=slot;
    }
  }
  for(const w of assignWeights.values())sq+=w*w;
  result.effectiveWorlds=total*total/sq;
  for(const s of Object.values(shares)){s.evil/=total;s.demon/=total;s.drunk/=total;for(const r of Object.keys(s.roles)as RoleId[])s.roles[r]!/=total;for(const n of Object.keys(s.poison))s.poison[Number(n)]/=total;}
  for(const r of Object.keys(result.presence)as RoleId[])result.presence[r]!/=total;
  for(const v of Object.values(result.info)){const sum=Object.values(v).reduce((a,b)=>a+b,0);for(const k of Object.keys(v)as(keyof typeof v)[])v[k]/=sum;}
  weighted.sort((a,b)=>b.log-a.log);
  const topWorlds=weighted.slice(0,opts.worldLimit);
  result.worlds=topWorlds.map(x=>x.w);
  result.worldWeights=topWorlds.map(x=>Math.exp(x.log-max)/total);
  for(const p of ps){
    const good=weighted.find(x=>x.w.currentAlignment[p] === "good")?.w;
    const evil=weighted.find(x=>x.w.currentAlignment[p] === "evil")?.w;
    result.examples[p]={...(good?{good}:{}),...(evil?{evil}:{})};
  }
  result.elapsedMs=Date.now()-start;
  return result;
}
