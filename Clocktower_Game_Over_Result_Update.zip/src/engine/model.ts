import type { Alignment, GameSnapshot, StructuredInfo } from "../types";
import type { RoleId } from "../roles";
export type Snapshot = GameSnapshot;
export type Severity = "red" | "orange" | "yellow" | "green" | "blue";
export type Reason = { code: string; players: string[]; phase?: string; roles?: RoleId[]; evidence: number[]; detail?: string; strength: "mechanical" | "conditional" | "heuristic" | "input" };
export type Warning = { color: Severity; cycle?: number; reasons: Reason[] };
export type PlayerEvidence = { good: number; evil: number; inconsistency: number; reasons: Reason[]; warnings: Warning[]; confirmedRole?: RoleId };
export type EvidenceAnalysis = { players: Record<string, PlayerEvidence>; global: Record<string, { points: number; reasons: Reason[] }>; issues: Reason[] };
export type Observation = { id: number; aliases: number[]; source: string; role: RoleId; when: string; direct: boolean; data: StructuredInfo };
export type InfoDisposition = "works" | "registration" | "poison" | "drunk" | "bluff" | "lie" | "missing";
export type HistoryWorld = {
  /** Character identity and team alignment are independent. Pit-Hag can change the character without changing alignment. */
  initial: Record<string, RoleId>; current: Record<string, RoleId>;
  initialAlignment: Record<string, Alignment>; currentAlignment: Record<string, Alignment>;
  believedRoles: Record<string, RoleId>;
  alive: string[]; redHerring: string | null;
  poison: Record<number, string | null>;
  requiredPoison: Record<number, string>;
  info: Record<number, InfoDisposition>;
  changes: (
    | { when: string; from: string; to: string; kind: "scarlet" | "starpass" }
    | { when: string; playerId: string; fromRole: RoleId; toRole: RoleId; kind: "pit_hag" }
  )[];
  /** Nights where a newly-created Demon makes deaths mechanically arbitrary. */
  arbitraryDeathNights: number[];
  logScore: number; assumptions: string[]; ended: boolean; endReason?: "saint" | "mayor" | "demonDeath" | "twoAlive";
};
export type SearchOptions = { attempts: number; seed: number; maxMillis: number; beamWidth: number; meta: boolean; worldLimit: number };
export const DEFAULT_SEARCH_OPTIONS: SearchOptions = { attempts: 2400, seed: 71347, maxMillis: 4500, beamWidth: 3, meta: false, worldLimit: 40 };
export type PlayerShare = { evil: number; demon: number; drunk: number; roles: Partial<Record<RoleId, number>>; poison: Record<number, number> };
export type SearchResult = {
  kind: "sample"; checked: number; accepted: number; unique: number; elapsedMs: number;
  exhaustive: false; beamWidth: number; seed: number; meta: boolean;
  effectiveWorlds: number; truncated: boolean;
  players: Record<string, PlayerShare>; presence: Partial<Record<RoleId, number>>;
  info: Record<number, { works: number; registration: number; poison: number; drunk: number; bluff: number; lie: number; missing: number }>;
  worlds: HistoryWorld[];
  /** Normalized search weights aligned with `worlds`. Optional for backward compatibility. */
  worldWeights?: number[];
  examples: Record<string, {good?:HistoryWorld;evil?:HistoryWorld}>; issues: Reason[];
};
