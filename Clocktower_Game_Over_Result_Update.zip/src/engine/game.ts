import { ROLES, type RoleId } from "../roles";
import type { Alignment, GameSnapshot, RoleClaimEvent, SelfInfoEvent, StructuredInfo, PlayerStatus } from "../types";
import type { Observation } from "./model";

export function cycle(when: string): number { return Number(when.slice(1)); }
export function phaseIndex(when: string): number { return (cycle(when) - 1) * 2 + (when.startsWith("D") ? 1 : 0); }
export function validPhase(when: string): boolean { return /^[ND][1-9]\d*$/.test(when); }
export function compareEvents(a: { when: string; id: number; order?: number }, b: { when: string; id: number; order?: number }): number {
  return phaseIndex(a.when) - phaseIndex(b.when) || (a.order ?? a.id) - (b.order ?? b.id);
}
export function seats(count: number): string[] {
  const left = Math.ceil((count - 1) / 2), right = Math.floor((count - 1) / 2);
  // Circular order, NOT the two columns concatenated. First and last are neighbours.
  return ["self", ...Array.from({ length: left }, (_, i) => `${i + 1}L`), ...Array.from({ length: right }, (_, i) => `${right - i}R`)];
}
export function setupCounts(count: number, baron = false) {
  const table: Record<number, [number, number, number]> = {5:[3,0,1],6:[3,1,1],7:[5,0,1],8:[5,1,1],9:[5,2,1],10:[7,0,2],11:[7,1,2],12:[7,2,2],13:[9,0,3],14:[9,1,3],15:[9,2,3]};
  const v = table[count];
  if (!v) throw new Error("Only standard 5-15 player games are supported.");
  return { townsfolk: v[0] - (baron ? 2 : 0), outsider: v[1] + (baron ? 2 : 0), minion: v[2], demon: 1 };
}
export function defaultAlignmentForRole(role: RoleId): Alignment { return ROLES[role].type === "minion" || ROLES[role].type === "demon" ? "evil" : "good"; }
export function evilRole(role: RoleId): boolean { return defaultAlignmentForRole(role) === "evil"; }
export function evilAlignment(alignment: Alignment): boolean { return alignment === "evil"; }
export function latestClaim(g: GameSnapshot, player: string, before?: string): RoleClaimEvent | null {
  return g.roleClaimLog.filter(c => c.playerId === player && (!before || phaseIndex(c.when) <= phaseIndex(before))).sort(compareEvents).at(-1) ?? null;
}
export function exactClaim(g: GameSnapshot, player: string, before?: string): RoleId | null {
  if (player === "self" && g.selfRole.shownRole) return g.selfRole.shownRole;
  const c = g.roleClaimLog.filter(c => c.playerId === player && c.subject.kind === "role" && (!before || phaseIndex(c.when) <= phaseIndex(before))).sort(compareEvents).at(-1);
  return c?.subject.kind === "role" ? c.subject.roleId : null;
}
export function priorRole(g: GameSnapshot, player: string): RoleId | null {
  if (player === "self" && g.selfRole.shownRole) return g.selfRole.shownRole;
  const c = g.roleClaimLog.filter(c => c.playerId === player && c.claimType !== "bluff" && c.subject.kind === "role").sort(compareEvents).at(-1);
  return c?.subject.kind === "role" ? c.subject.roleId : null;
}
export function diedByExecution(d: GameSnapshot["deathLog"][number]): boolean { return d.reason === "execution" || d.isExecution === true || d.sourceRoleId === "virgin"; }
export function isAliveAt(g: GameSnapshot, player: string, when: string, id = Infinity): boolean {
  let alive = true;
  const events = [
    ...g.deathLog.map(d => ({ ...d, kind: "death" as const })),
    ...(g.revivalLog ?? []).map(r => ({ ...r, kind: "revival" as const })),
  ].sort(compareEvents);
  for (const e of events) {
    if (e.playerId !== player) continue;
    const before = phaseIndex(e.when) < phaseIndex(when) || (e.when === when && (e.order ?? e.id) < id);
    if (!before) continue;
    alive = e.kind === "revival";
  }
  return alive;
}
export function livingNeighbours(order: string[], player: string, alive: ReadonlySet<string>): string[] {
  const i = order.indexOf(player); if (i < 0) return [];
  const result: string[] = [];
  for (const dir of [-1, 1]) for (let d = 1; d < order.length; d++) {
    const p = order[(i + dir * d + order.length) % order.length];
    if (alive.has(p)) { result.push(p); break; }
  }
  return [...new Set(result)];
}
export function rebuildStatus(g: GameSnapshot): Record<string, PlayerStatus> {
  const result = Object.fromEntries(seats(g.playerCount).map(p => [p, { alive: true, deadVoteAvailable: true }]));
  const events = [
    ...g.deathLog.map(d => ({ ...d, kind: "death" as const })),
    ...(g.revivalLog ?? []).map(r => ({ ...r, kind: "revival" as const })),
    ...g.nominationLog.map(n => ({ ...n, kind: "nomination" as const })),
  ].sort(compareEvents);
  for (const e of events) {
    if (e.kind === "death" && result[e.playerId]) result[e.playerId] = { alive: false, deadVoteAvailable: true };
    if (e.kind === "revival" && result[e.playerId]) result[e.playerId] = { alive: true, deadVoteAvailable: true };
    if (e.kind === "nomination" && e.votingOccurred !== false) for (const p of e.voters) if (result[p] && !result[p].alive) result[p].deadVoteAvailable = false;
  }
  return result;
}
export function selfData(e: SelfInfoEvent): StructuredInfo | null {
  switch (e.roleId) {
    case "washerwoman": case "investigator": return { kind: "pairRole", players: e.players, shownRole: e.shownRole };
    case "librarian": return e.noOutsiders ? { kind: "noOutsiders" } : e.players && e.shownRole ? { kind: "pairRole", players: e.players, shownRole: e.shownRole } : null;
    case "chef": case "empath": return { kind: "number", value: e.number };
    case "fortune_teller": return { kind: "pairYesNo", players: e.players, result: e.result };
    case "undertaker": case "ravenkeeper": return { kind: "roleReveal", player: e.player, shownRole: e.shownRole };
  }
}
export function observations(g: GameSnapshot): Observation[] {
  const entries: Observation[] = [];
  for (const e of g.selfInfoLog) { const data = selfData(e); if (data) entries.push({ id: e.id, aliases: [e.id], source: "self", role: e.roleId, when: e.when, data, direct: true }); }
  for (const e of g.abilityClaimLog) if (e.structured && e.structured.kind !== "action") entries.push({ id: e.id, aliases: [e.id], source: e.sourcePlayerId || e.playerId, role: e.roleId, when: e.when, data: e.structured, direct: false });
  // Repeating the same report does NOT create additional evidence.
  const unique = new Map<string, Observation>();
  for (const e of entries) {
    const normalized = e.data.kind === "pairRole" || e.data.kind === "pairYesNo" ? {...e.data,players:[...e.data.players].sort()} : e.data;
    const key = JSON.stringify([e.source, e.role, e.when, normalized]);
    const old = unique.get(key); if (old) { old.aliases.push(...e.aliases); old.direct ||= e.direct; } else unique.set(key, e);
  }
  return [...unique.values()].sort(compareEvents);
}

export type EmpathShiftSignal = {
  source: string;
  fromWhen: string;
  toWhen: string;
  fromValue: number;
  toValue: number;
  neighbours: string[];
  evidence: number[];
  direct: boolean;
  nights: number[];
};

/**
 * Finds consecutive Empath reads that changed even though the Empath had the
 * same two living neighbours and neither neighbour died between those reads.
 * This is only a heuristic signal: drunkenness/poison are strong explanations,
 * but custom scripts may contain alignment-changing effects or unimplemented
 * mechanics that can also explain the change.
 */
export function empathStableNeighbourShifts(g: GameSnapshot): EmpathShiftSignal[] {
  const order = seats(g.playerCount);
  const grouped = new Map<string, Map<string, Observation[]>>();
  for (const o of observations(g)) {
    if (o.role !== "empath" || o.data.kind !== "number") continue;
    const byWhen = grouped.get(o.source) ?? new Map<string, Observation[]>();
    byWhen.set(o.when, [...(byWhen.get(o.when) ?? []), o]);
    grouped.set(o.source, byWhen);
  }

  const aliveSetAt = (when: string) => new Set(order.filter(p => isAliveAt(g, p, when, Infinity)));
  const out: EmpathShiftSignal[] = [];
  for (const [source, byWhen] of grouped) {
    const records = [...byWhen.entries()].flatMap(([when, entries]) => {
      const values = [...new Set(entries.map(o => o.data.kind === "number" ? o.data.value : NaN))];
      if (values.length !== 1 || !Number.isFinite(values[0])) return [];
      return [{
        when,
        value: values[0],
        evidence: [...new Set(entries.flatMap(o => o.aliases))],
        direct: entries.some(o => o.direct),
      }];
    }).sort((a,b) => phaseIndex(a.when) - phaseIndex(b.when));

    for (let i = 1; i < records.length; i++) {
      const prev = records[i - 1], curr = records[i];
      if (prev.value === curr.value || phaseIndex(prev.when) === phaseIndex(curr.when)) continue;
      if (!isAliveAt(g, source, prev.when, Infinity) || !isAliveAt(g, source, curr.when, Infinity)) continue;
      const prevNeighbours = livingNeighbours(order, source, aliveSetAt(prev.when));
      const currNeighbours = livingNeighbours(order, source, aliveSetAt(curr.when));
      if (prevNeighbours.length !== 2 || currNeighbours.length !== 2) continue;
      const sameNeighbours = [...prevNeighbours].sort().join("|") === [...currNeighbours].sort().join("|");
      if (!sameNeighbours) continue;
      const start = phaseIndex(prev.when), end = phaseIndex(curr.when);
      const nearbyDeath = g.deathLog.some(d => prevNeighbours.includes(d.playerId) && phaseIndex(d.when) > start && phaseIndex(d.when) <= end);
      if (nearbyDeath) continue;
      out.push({
        source, fromWhen: prev.when, toWhen: curr.when,
        fromValue: prev.value, toValue: curr.value, neighbours: prevNeighbours,
        evidence: [...new Set([...prev.evidence, ...curr.evidence])],
        direct: prev.direct || curr.direct,
        nights: [...new Set([cycle(prev.when), cycle(curr.when)])],
      });
    }
  }
  return out;
}
export function dataValid(role: RoleId, data: StructuredInfo, playerCount: number): boolean {
  if (role === "washerwoman" || role === "librarian" || role === "investigator") {
    if (role === "librarian" && data.kind === "noOutsiders") return true;
    return data.kind === "pairRole" && data.players[0] !== data.players[1] && ROLES[data.shownRole].type === (role === "washerwoman" ? "townsfolk" : role === "librarian" ? "outsider" : "minion");
  }
  if (role === "chef" || role === "empath") return data.kind === "number" && Number.isInteger(data.value) && data.value >= 0 && data.value <= (role === "empath" ? 2 : playerCount);
  if (role === "fortune_teller") return data.kind === "pairYesNo" && data.players[0] !== data.players[1];
  if (role === "undertaker" || role === "ravenkeeper") return data.kind === "roleReveal";
  return data.kind === "action";
}
export function observationTimingValid(role: RoleId, when: string): boolean {
  if (!validPhase(when) || !when.startsWith("N")) return false;
  if (["washerwoman","librarian","investigator","chef"].includes(role)) return when === "N1";
  if (role === "undertaker" || role === "monk" || role === "imp") return cycle(when) >= 2;
  return true;
}
