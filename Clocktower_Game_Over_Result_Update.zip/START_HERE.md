# Clocktower: Unified Information Recording Update

This is a complete **src-folder update** for the existing React + TypeScript + Vite project. It is not a standalone APK.

The app UI is Japanese. These installation notes and code identifiers are English.

## This update

This build adds the first exact Sects & Violets character-change mechanic: **Pit-Hag**. In Minion Mode, a Pit-Hag can record an N2+ target and new character. Candidate histories apply the change only when the chosen character is not currently in play, preserve the target's alignment, and treat a successful Demon creation as an arbitrary-death night.

The Pit-Hag history uses a bottom **取り消し** button for the latest entry. The underlying role/alignment split from the previous build remains in place.


## Unified information recording

Tap a player and choose `情報を記録`. The tapped player is treated as the speaker. Pick `元の人` (person A), A's role, and then A's role-specific information or generic ability details. The old separate `その他の能力主張` button is no longer shown.

Structured TB information roles still use their dedicated controls; other script roles use target + free-text fields until a dedicated parser/evaluator is implemented. The bottom `取り消し` removes the newest information record from that speaker.

## Install

1. Stop Vite with **Ctrl + C**.
2. Back up `C:\Users\naoki\clocktower-solver\src` somewhere outside the project.
3. Extract this ZIP and copy its entire `src` folder into `C:\Users\naoki\clocktower-solver`, replacing matching files. Copy the `engine` and `ui` subfolders too.
4. Keep the existing `package.json`, `package-lock.json`, `node_modules`, `index.html`, and Vite configuration. This update adds no new runtime package.

`App.css` in this package is the complete current stylesheet. **Replace the old stylesheet; do not append it.**

Run:

```bat
cd /d "%USERPROFILE%\clocktower-solver"
npm run dev
```

For a local compile/build check:

```bat
npm run build
```

The exact npm/Vite build could not be run in the delivery environment, but the source passed the offline checks listed in `docs/TEST_RESULTS.md`.

## Self-role modes

Tap your own circle and choose a role.

- **Townsfolk**: existing shown-role, structured information, and action workflow. A shown Townsfolk can still be analyzed as the Drunk where appropriate.
- **Minion**: dedicated Minion mode includes the existing Trouble Brewing tools plus the new Pit-Hag transformation recorder.
- **Demon**: dedicated Imp mode with teammates, Storyteller bluffs, bluff plans, attacks, and starpass support.

Switching alignment/role asks before clearing role-specific information where necessary. Shared Minion team/bluff-planning information is preserved when switching between Minion characters, while character-specific action records are cleared after confirmation.

## Minion mode highlights

### Shared evil-team information

For 7+ players, record the Demon and other Minion players shown at setup. Their seats are direct information; exact fellow-Minion characters are only fixed after you explicitly record that they were confirmed later.

For 5-6 players, Minion mode does not assume normal starting evil-team information.

Known evil teammates are privately marked on the board:

- `魔` = known Demon
- `味` = known fellow Minion

### Shared Storyteller bluffs versus plans

A Storyteller bluff that the Demon explicitly shares with you is an out-of-play hard constraint for Possible Worlds. A planned bluff for yourself or a teammate is only a strategy note and **never feeds back into the solver**.

### Poisoner

Record one poison target per night from N1. Your own target selection is direct information, so candidate histories must use that target while you remain the Poisoner. The board shows a numbered green marker for the recorded cycle.

### Spy

Copy the N1 Grimoire, Fortune Teller red herring, and nightly visible Poisoner reminder target. Spy information is conditional rather than universally hard: if your Spy is itself poisoned, the Storyteller may show false information, and those candidate worlds remain possible.

Spy mode now also runs an **automatic bluff-world advisor**. It builds a counterfactual good-team view with your secret evil information removed, searches candidate worlds from that perspective, and ranks every good-role bluff by how many distinct/effective candidate assignments can still explain you as that role, as the Drunk who thinks they are that role, or as evil bluffing it. The top practical recommendation avoids known Grimoire collisions, existing opponent claims, and teammate bluff-plan collisions; a separate `世界数1位` badge shows the raw maximum-world option even if it has a collision risk.

The advisor is deliberately bounded/sample-based rather than exhaustive. It automatically recalculates while Spy mode is open and has a `深く再計算` control for a larger search. Choosing `このブラフを採用` writes the role into the existing team bluff plan, which is saved/logged but never fed back into the mechanical solver.


### Pit-Hag

From N2 onward, record the chosen player and the character you attempted to create. The engine checks whether that character is currently in play in each candidate history. Successful transformations change character but keep alignment. Creating a Demon makes that night use the Pit-Hag arbitrary-death rule instead of normal Imp kill-count validation.

### Scarlet Woman

Record the exact phase if you actually become the Imp. Possible Worlds then require a legal Demon transition at that phase. Successor Imp attacks begin on the following night, not a second time during the takeover night.

### Baron

The solver applies Baron's setup modification from your own direct Baron token. The UI shows the normal and Baron-modified setup counts plus currently recorded Outsider claims.

See `docs/MINION_MODE.md` for the full behavior and hard-vs-soft information boundary.

## Reasoning and Possible Worlds

The reasoning button at the top of the board opens analysis. The menu also has **候補盤面を確認** for a direct jump into candidate worlds.

The engine searches a bounded sample of legal assignments from the selected frozen script. Trouble Brewing has the deepest exact coverage; newer BMR/S&V mechanics are added character by character, with unsupported abilities kept conservative rather than guessed. Surface percentages are shares of the weighted candidates found, **not calibrated real-world probabilities**.

Important distinctions:

- your own token/setup/team information is much stronger than another player's claim;
- planned evil bluffs do not influence the search;
- structured information can be mechanically evaluated; free-text notes are not silently parsed;
- missing data is not automatically interpreted as “nothing happened”;
- poisoned/drunk information can remain false without forcing a player to be lying.

## Warning badges

| Badge | Meaning |
| --- | --- |
| Red `!` | Strong evil concentration in a sufficiently broad explored candidate set, with supporting information/public evidence |
| Orange `!` | Claim, information, or input inconsistency worth examining |
| Yellow `!` | Your saved manual read conflicts with public evidence/current candidate analysis |
| Blue `!` | Drunk is a significant explanation in explored candidates |
| Green number | Poisoning on that numbered cycle is required by many candidates **or directly recorded by your Poisoner/Spy view**; tap for the exact reason |
| Neutral dot | Conversation recorded; not an evil accusation |

A direct Poisoner marker is strong because it is your own action. A Spy-displayed poison marker is explicitly labeled conditional because a poisoned Spy can be shown false information.

## Game logs and saves

The current game autosaves to browser localStorage. The menu can save a mid-game archive entry; ending the game adds a finished Game Log entry. Archived raw game states can later be reloaded and re-analyzed with a newer solver.

JSON export/import is available for backups and moving games. Keep important exports outside browser storage. The archive is capped at 40 entries.

`夜を戻す` restores the complete checkpoint from before the previous night advance rather than merely decrementing the night number.

## Included docs

- `docs/MINION_MODE.md` - new Minion-mode behavior
- `docs/DEMON_MODE.md` - Imp/Demon workflow
- `docs/GAME_LOG_AND_REASONING.md` - archive and solver concepts
- `docs/RULES_AND_LIMITS.md` - current mechanical coverage and known limits
- `docs/IMPLEMENTATION_NOTES.md` - developer architecture notes
- `docs/TEST_RESULTS.md` - verification results

## Current major limits

This is still Trouble Brewing only. Travellers and other scripts are not modeled. Search is bounded rather than exhaustive, strategy suggestions are heuristic, and rare interactions may still need additional regression cases. There is no production APK/PWA package in this ZIP.

## Script Manager update

From the home screen open `スクリプト管理`.

`新規スクリプト` shows the 72 core roles as ON/OFF buttons. Press `保存`, type the script name, and it will appear both in Script Manager and in the game setup script selector.

Built-in scripts included:
- Trouble Brewing
- Bad Moon Rising
- Sects and Violets

Trouble Brewing has the full existing mechanical solver. BMR/S&V currently use generic candidate-world support for their unimplemented unique abilities; see `docs/SCRIPT_MANAGER.md`.
