# Spy bluff-world advisor

## Goal

Recommend which good role the Spy should claim when the stated objective is to leave the opposing team with the largest, broadest set of mechanically plausible Trouble Brewing worlds.

## Why the normal solver cannot answer this directly

The ordinary solver knows the user's actual Spy token, evil teammates, Grimoire, shared Storyteller bluffs, and private evil actions. From that perspective `self = Spy` is already fixed, so changing the planned bluff should not change the real candidate worlds.

The advisor therefore creates a second, counterfactual **opponent view** and runs its own bounded search in a Worker.

## Opponent-view projection

Removed as secret:

- self true role;
- Minion/Demon team knowledge;
- Storyteller bluff knowledge known only to evil;
- Spy Grimoire/red herring/reminder data;
- Poison/Demon private action logs;
- manual reads;
- self's current role/ability bluff.

Kept:

- deaths, nominations, votes, public mechanical triggers;
- completed-night/no-execution facts;
- public claims/reports;
- private claims/reports that at least one non-known-evil recipient could know.

Internal `claimType = bluff` labels are normalized to normal claims in this view because an opponent cannot see the private label.

## World-coverage metric

For every good role, a candidate opponent world counts as supporting the bluff if self is:

- genuinely that role;
- Drunk and could believe that Townsfolk role; or
- evil and therefore able to bluff it.

Support is aggregated by distinct starting assignment. The UI shows:

- **成立配役**: distinct represented assignments supporting the bluff;
- **有効世界**: effective number of supported assignments after search weights;
- **善側の顔で成立**: share of support coming from genuinely-good/Drunk interpretations rather than only evil-bluff interpretations.

The list is ordered primarily by effective-world diversity.

## Recommendation versus raw winner

`世界数1位` is the raw highest-diversity role.

`推奨` is the highest-diversity role after excluding currently known practical collisions:

- Spy Grimoire shows the character in play;
- a visible opponent already claims it;
- a teammate already plans to use it.

This lets the user see both the mathematical ambiguity maximum and the safer operational choice.

## Important limitation

This version optimizes the **role bluff itself**. It does not yet search over every possible fabricated Chef/Empath/FT/etc. information statement. That can be built next as a second optimization layer: choose the role first, then choose the fake information line that preserves the most opponent worlds while staying compatible with the Spy's private Grimoire knowledge.
