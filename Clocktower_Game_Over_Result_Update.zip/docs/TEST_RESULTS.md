# Latest verification - Unified information recording

- Engine/data regression suite: **84 / 84 passed** after the UI/storage compatibility changes.
- TS/TSX syntax transpile check: **passed**.
- The unified form preserves the existing `abilityClaimLog` schema, so older saves remain compatible.
- The user's exact Windows `npm run build` should still be run after copying the updated `src` folder.

# Current verification

**84 / 84 engine/data regression tests passed.**

The newest checks cover changed Empath reads with stable neighbours, suppression of the heuristic after a nearby death, and increased weighting for Drunk/poison explanations.

# Empath stable-neighbour heuristic verification

New regression coverage checks that:

1. A changed Empath read with the same two living neighbours creates the new impairment heuristic.
2. A nearby neighbour death suppresses that heuristic.
3. Candidate weighting prefers Drunk or required-poison explanations over an otherwise identical healthy Empath world.

# Current verification

## Sects & Violets Pit-Hag update

**80 / 80 engine/data regression tests passed.**

New checks cover:

1. Pit-Hag character-change metadata.
2. N2+ snapshot validation for direct Pit-Hag transformations.
3. Character changes preserving alignment.
4. Demon creation allowing arbitrary deaths for that night.

A full offline TS/TSX source check also passed using the existing test-only React declaration shim.

# Test and verification results

## Current Minion-mode build

The engine/data regression suite was run after the Minion-mode changes:

**72 / 72 tests passed.**

The suite includes the existing Trouble Brewing regression coverage plus Minion-mode and Spy bluff-advisor cases.

### New Minion-mode regression checks

1. Self Minion character, known Demon, fellow Minion identities/exact roles, and shared Storyteller bluffs correctly constrain candidate assignments.
2. The user's own Poisoner action fixes that night's poison target and produces a direct numbered green marker.
3. A Spy Grimoire mismatch remains possible only through an applicable self-poison explanation rather than being accepted unconditionally.
4. A healthy Spy's displayed Poisoner reminder matches the real poison target, while a poisoned Spy may be shown a different target; the conditional green display marker is produced.
5. A Scarlet Woman takeover can be recorded as a direct self Demon-succession phase and enforced by candidate history.
6. Snapshot validation rejects self as the known Demon and rejects non-Minion characters as exact fellow-Minion roles.
7. The Spy opponent projection strips secret evil knowledge, the user's existing self bluff, and self-only whispers, while keeping public information and normalizing hidden bluff labels.
8. The Spy bluff advisor returns only good-role bluff candidates, produces an opponent-view candidate set, and marks Grimoire-confirmed in-play roles as collision risks rather than recommended safe choices.

### Existing regression areas retained

Coverage also includes:

- seat ring/setup counts and Baron setup;
- living-neighbour history;
- Spy/Recluse registrations;
- Chef pair registration;
- Fortune Teller red herring/poison/Drunk behavior;
- unique roles and fixed Drunk believed character;
- one Poisoner target per cycle;
- Slayer/Virgin public events;
- Scarlet Woman and Imp succession;
- Saint/Soldier/Monk mechanics;
- explicit missing-versus-none death handling;
- ghost votes;
- claim timing and relay deduplication;
- evidence feedback-loop guards;
- linked-event deletion;
- import validation;
- sparse-sample warning/advice guards;
- Demon-mode hard knowledge, attacks, dead-target sinking, and self-kill succession.

## TypeScript / TSX check

A full offline source type check passed using TypeScript and a minimal test-only React declaration shim because the delivery workspace does not contain the user's installed `node_modules` tree.

**Result: passed with no reported TS/TSX errors.**

This catches source-level type issues but is not identical to compiling against the user's exact installed React/Vite package versions.

## What was not run here

- The user's exact `npm run build` against their Windows `node_modules`.
- The physical Redmi Note 11 Pro 5G.
- A complete browser click-through of every new Minion-mode control.
- Exhaustive enumeration of all legal Trouble Brewing worlds.

The existing code has no new runtime dependencies. After installing the source update, the user should run:

```bat
cd /d "%USERPROFILE%\clocktower-solver"
npm run dev
```

and optionally:

```bat
npm run build
```

A successful local Vite build plus a quick Minion-mode click-through is the final environment-specific verification.


### BMR Mastermind / Exorcist checks

- Direct self Exorcist choice on a completed zero-death night raises suspicion on the chosen player.
- Repeating the same Exorcist target is flagged as inconsistent.
- An execution followed by a completed zero-death night surfaces Mastermind risk.
- Imported/saved snapshots accept direct self Exorcist actions.

**Current result: 72 / 72 tests passed.**

## Game-over result selection regression

- Existing reasoning regression suite: **84/84 passed** after the game-over result changes.
- `tsc -p tsconfig.engine.json` passed, including the updated game-log outcome type and storage validation.
- `App.tsx`, `GameLogUI.tsx`, `storage.ts`, and `types.ts` were syntax-checked with the TypeScript compiler API.
