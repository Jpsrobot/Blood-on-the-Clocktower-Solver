const assert=require('node:assert/strict');
const {seats,setupCounts,livingNeighbours,rebuildStatus,observations,latestClaim,diedByExecution,empathStableNeighbourShifts}=require('../.engine-test/engine/game.js');
const {validSetup,evaluateAssignment,canRegisterRole,infoMatches,chefRange}=require('../.engine-test/engine/mechanics.js');
const {runSearch,empathShiftLogBonus}=require('../.engine-test/engine/search.js');
const {analyzeEvidence}=require('../.engine-test/engine/evidence.js');
const {nominationAdvice}=require('../.engine-test/engine/advice.js');
const {buildSpyOpponentProjection,runSpyBluffAdvisor}=require('../.engine-test/engine/spyBluff.js');
const {validateSnapshot,deleteEventGroup}=require('../.engine-test/storage.js');
const {ROLES}=require('../.engine-test/roles.js');
let passed=0;const tests=[];
function test(name,fn){try{fn();passed++;tests.push({name,passed:true});console.log('PASS',name);}catch(e){tests.push({name,passed:false,error:String(e)});console.error('FAIL',name,e.message);process.exitCode=1;}}
function game(n=5){return{schemaVersion:2,playerCount:n,playset:'trouble_brewing',night:1,playerNames:{},playerStatus:Object.fromEntries(seats(n).map(p=>[p,{alive:true,deadVoteAvailable:true}])),roleClaimLog:[],abilityClaimLog:[],deathLog:[],revivalLog:[],nominationLog:[],abilityTriggerLog:[],talkLog:[],selfRole:{shownRole:null},selfInfoLog:[],selfActionLog:[],manualReads:{},completedNights:[],noExecutionDays:[]};}
function context(roles,poisonTarget=null,redHerring=null){return{roles,initial:roles,alive:new Set(Object.keys(roles)),poisonTarget,redHerring,order:Object.keys(roles)};}
function claim(g,p,r,id=1,when='D1'){g.roleClaimLog.push({id,playerId:p,subject:{kind:'role',roleId:r},claimType:'normal',origin:'manual',visibility:'public',recipients:[],when});}
const base={self:'fortune_teller','1L':'empath','2L':'virgin','2R':'poisoner','1R':'imp'};
const noPoison={self:'fortune_teller','1L':'empath','2L':'virgin','2R':'spy','1R':'imp'};
const ftPair={players:['1L','2L']};
test('Seat ring and counts for every supported game size',()=>{for(let n=5;n<=15;n++){const p=seats(n);assert.equal(p.length,n);assert.equal(new Set(p).size,n);for(const b of[false,true])assert.equal(Object.values(setupCounts(n,b)).reduce((a,b)=>a+b,0),n);}assert.deepEqual(seats(5),['self','1L','2L','2R','1R']);});
test('15-player Baron setup is 7/4/3/1',()=>assert.deepEqual(setupCounts(15,true),{townsfolk:7,outsider:4,minion:3,demon:1}));
test('Living neighbours bridge deaths and wrap correctly',()=>assert.deepEqual(livingNeighbours(seats(9),'self',new Set(['self','2L','3R','4L'])),['3R','2L']));
test('Registration directions are constrained',()=>{assert(canRegisterRole('spy','monk'));assert(!canRegisterRole('spy','imp'));assert(canRegisterRole('recluse','poisoner'));assert(!canRegisterRole('recluse','saint'));assert(!canRegisterRole('spy','monk',true));});
test('Chef registration varies per PAIR, not one global alignment',()=>{const c=context({a:'imp',b:'recluse',c:'poisoner',d:'chef',e:'monk'});assert.deepEqual(chefRange(c),[0,2]);assert(infoMatches('chef','d',{kind:'number',value:1},c));});
test('Character role and team alignment are independent',()=>{const c=context({a:'imp',b:'poisoner',c:'chef',d:'empath',e:'monk'});c.alignment={a:'good',b:'evil',c:'good',d:'good',e:'good'};assert.deepEqual(chefRange(c),[0,0]);assert(infoMatches('chef','c',{kind:'number',value:0},c));});
test('Fortune Teller detects dead Imp',()=>{const c=context(base,null,'2L');c.alive.delete('1R');assert(infoMatches('fortune_teller','self',{kind:'pairYesNo',players:['1R','1L'],result:'yes'},c));assert(!infoMatches('fortune_teller','self',{kind:'pairYesNo',players:['1R','1L'],result:'no'},c));});
test('Fortune Teller red herring stays a positive even when dead',()=>{const c=context(base,null,'1L');c.alive.delete('1L');assert(!infoMatches('fortune_teller','self',{kind:'pairYesNo',players:['1L','2L'],result:'no'},c));});
test('Recluse can register either way to Fortune Teller',()=>{const c=context({...base,'1L':'recluse'},null,'self');for(const result of ['yes','no'])assert(infoMatches('fortune_teller','self',{kind:'pairYesNo',players:['1L','2L'],result},c));});
test('Poisoned Recluse cannot supply optional positive',()=>{const c=context({...base,'1L':'recluse'},'1L','self');assert(!infoMatches('fortune_teller','self',{kind:'pairYesNo',players:['1L','2L'],result:'yes'},c));});
test('Undertaker may read executed Recluse as Imp',()=>assert(infoMatches('undertaker','self',{kind:'roleReveal',player:'1L',shownRole:'imp'},context({...base,'1L':'recluse'}))));
test('Drunk is revealed as Drunk, not as believed Townsfolk',()=>{const c=context({...base,'1L':'drunk'});assert(infoMatches('undertaker','self',{kind:'roleReveal',player:'1L',shownRole:'drunk'},c));assert(!infoMatches('undertaker','self',{kind:'roleReveal',player:'1L',shownRole:'empath'},c));});
test('Legal setup requires unique roles',()=>{assert(validSetup(base,game()));assert(!validSetup({...base,'1L':'fortune_teller'},game()));});
test('Own shown Townsfolk can be Drunk, but token cannot duplicate actual role',()=>{const g=game();g.selfRole.shownRole='fortune_teller';const w={self:'drunk','1L':'chef','2L':'baron','2R':'saint','1R':'imp'};assert(validSetup(w,g));assert(!validSetup({...w,'1L':'fortune_teller'},g));});
test('Claims alone never exclude a legal good bluff world',()=>{const g=game();claim(g,'1L','imp');assert(evaluateAssignment(base,g).length>0);});
test('FT red herring must be consistent across nights',()=>{const g=game();g.night=2;g.selfRole.shownRole='fortune_teller';g.selfInfoLog=[{id:1,roleId:'fortune_teller',when:'N1',...ftPair,result:'yes'},{id:2,roleId:'fortune_teller',when:'N2',...ftPair,result:'no'}];assert.equal(evaluateAssignment(noPoison,g).length,0);});
test('Poison can rescue a changing direct FT reading',()=>{const g=game();g.night=2;g.selfRole.shownRole='fortune_teller';g.selfInfoLog=[{id:1,roleId:'fortune_teller',when:'N1',...ftPair,result:'yes'},{id:2,roleId:'fortune_teller',when:'N2',...ftPair,result:'no'}];assert(evaluateAssignment(base,g).length>0);});
test('Poison does not imply the received answer must be false',()=>{const g=game();g.selfRole.shownRole='fortune_teller';g.selfInfoLog=[{id:1,roleId:'fortune_teller',when:'N1',players:['1R','2L'],result:'yes'}];const w=evaluateAssignment(base,g,8);assert(w.some(w=>w.info[1]==='works'));});
test('Drunk direct inconsistent readings are observations, not truth',()=>{const g=game();g.night=2;g.selfRole.shownRole='fortune_teller';g.selfInfoLog=[{id:1,roleId:'fortune_teller',when:'N1',...ftPair,result:'yes'},{id:2,roleId:'fortune_teller',when:'N2',...ftPair,result:'no'}];const w={self:'drunk','1L':'chef','2L':'baron','2R':'saint','1R':'imp'};const hs=evaluateAssignment(w,g);assert(hs.length);assert(hs.every(h=>h.info[1]==='drunk'&&h.info[2]==='drunk'));});
test('Different players cannot both be poisoned on the same cycle',()=>{const g=game();g.abilityClaimLog=[{id:1,playerId:'self',roleId:'fortune_teller',when:'N1',targets:['1R','1L'],result:null,structured:{kind:'pairYesNo',players:['1R','1L'],result:'no'},visibility:'public',recipients:[]},{id:2,playerId:'1L',roleId:'empath',when:'N1',targets:[],result:null,structured:{kind:'number',value:2},visibility:'public',recipients:[]}];const hs=evaluateAssignment(base,g,12);assert(hs.length);assert(hs.every(h=>!(h.info[1]==='poison'&&h.info[2]==='poison')));});
test('Failed Slayer shot does not confirm shooter or target',()=>{const g=game();g.abilityTriggerLog=[{id:1,roleId:'slayer',rolePlayerId:'1L',targetPlayerId:'1R',when:'D1',triggered:false}];assert(evaluateAssignment(base,g).length>0);assert.equal(analyzeEvidence(g).players['1L'].confirmedRole,undefined);});
test('Slayer miss on actual Imp requires impaired/spent/fake shooter',()=>{const g=game();g.abilityTriggerLog=[{id:1,roleId:'slayer',rolePlayerId:'1L',targetPlayerId:'1R',when:'D1',triggered:false}];assert.equal(evaluateAssignment({...noPoison,'1L':'slayer'},g).length,0);assert(evaluateAssignment({...base,'1L':'slayer'},g).some(w=>w.requiredPoison[1]==='1L'));});
test('Successful Slayer can kill Recluse',()=>{const g=game();const w={self:'slayer','1L':'recluse','2L':'baron','2R':'saint','1R':'imp'};g.abilityTriggerLog=[{id:1,roleId:'slayer',rolePlayerId:'self',targetPlayerId:'1L',when:'D1',triggered:true}];g.deathLog=[{id:2,playerId:'1L',when:'D1',reason:'ability',sourceRoleId:'slayer',sourceEventId:1}];assert(evaluateAssignment(w,g).length);});
test('Virgin first nomination by Townsfolk must trigger if healthy',()=>{const g=game();g.nominationLog=[{id:1,nominator:'self',nominee:'2L',when:'D1',voters:[]}];g.abilityTriggerLog=[{id:2,roleId:'virgin',rolePlayerId:'2L',targetPlayerId:'self',when:'D1',triggered:false,sourceEventId:1}];assert.equal(evaluateAssignment(noPoison,g).length,0);assert(evaluateAssignment(base,g).some(w=>w.requiredPoison[1]==='2L'));});
test('Failed first Virgin test uses the ability',()=>{const g=game();g.night=2;g.nominationLog=[{id:1,nominator:'2R',nominee:'2L',when:'D1',voters:[]},{id:3,nominator:'self',nominee:'2L',when:'D2',voters:[]}];g.abilityTriggerLog=[{id:2,roleId:'virgin',rolePlayerId:'2L',targetPlayerId:'2R',when:'D1',triggered:false,sourceEventId:1},{id:4,roleId:'virgin',rolePlayerId:'2L',targetPlayerId:'self',when:'D2',triggered:true,sourceEventId:3}];assert.equal(evaluateAssignment(noPoison,g).length,0);});
test('Spy may trigger Virgin but stays evil',()=>{const g=game();g.nominationLog=[{id:1,nominator:'2R',nominee:'2L',when:'D1',voters:[],votingOccurred:false}];g.abilityTriggerLog=[{id:2,roleId:'virgin',rolePlayerId:'2L',targetPlayerId:'2R',when:'D1',triggered:true,sourceEventId:1}];g.deathLog=[{id:3,playerId:'2R',when:'D1',reason:'execution',sourceRoleId:'virgin',sourceEventId:2}];assert(evaluateAssignment(noPoison,g).length);assert.equal(analyzeEvidence(g).players['2R'].confirmedRole,undefined);});
test('Virgin death counts as execution for Undertaker',()=>{const g=game();g.night=2;g.selfRole.shownRole='undertaker';g.deathLog=[{id:2,playerId:'1L',when:'D1',reason:'ability',sourceRoleId:'virgin'}];g.selfInfoLog=[{id:3,roleId:'undertaker',when:'N2',player:'1L',shownRole:'empath'}];assert(diedByExecution(g.deathLog[0]));assert(evaluateAssignment({...noPoison,self:'undertaker'},g).length);});
test('Scarlet Woman takes over when Imp is executed with FIVE alive before death',()=>{const g=game();g.night=2;g.deathLog=[{id:1,playerId:'1R',when:'D1',reason:'execution'}];const hs=evaluateAssignment({...base,'2R':'scarlet_woman'},g);assert(hs.length);assert(hs.every(w=>w.current['2R']==='imp'));});
test('Scarlet Woman does NOT save executed Imp with FOUR alive',()=>{const g=game();g.night=2;g.deathLog=[{id:1,playerId:'1L',when:'D1',reason:'ability'},{id:2,playerId:'1R',when:'D1',reason:'execution'}];assert.equal(evaluateAssignment({...base,'2R':'scarlet_woman'},g).length,0);});
test('Imp night self-kill can pass to a living minion',()=>{const g=game();g.night=2;g.deathLog=[{id:1,playerId:'1R',when:'N2',reason:'night_death'}];const hs=evaluateAssignment(base,g);assert(hs.length);assert(hs.every(w=>w.current['2R']==='imp'));});
test('Poison effect ends when Poisoner becomes Imp',()=>{const g=game();g.night=2;g.selfRole.shownRole='fortune_teller';g.deathLog=[{id:1,playerId:'1R',when:'N2',reason:'night_death'}];g.selfInfoLog=[{id:2,roleId:'fortune_teller',when:'N2',players:['2R','1L'],result:'no'}];assert.equal(evaluateAssignment(base,g).length,0);});
test('Healthy Saint execution cannot allow another night',()=>{const g=game();g.night=2;g.deathLog=[{id:1,playerId:'2R',when:'D1',reason:'execution'}];const w={self:'fortune_teller','1L':'butler','2L':'baron','2R':'saint','1R':'imp'};assert.equal(evaluateAssignment(w,g).length,0);});
test('Soldier cannot die to ordinary Imp attack while healthy',()=>{const g=game();g.night=2;g.deathLog=[{id:1,playerId:'1L',when:'N2',reason:'night_death'}];assert.equal(evaluateAssignment({...noPoison,'1L':'soldier'},g).length,0);assert(evaluateAssignment({...base,'1L':'soldier'},g).some(w=>w.requiredPoison[2]==='1L'));});
test('Monk chosen protection is conditional on being genuine and healthy',()=>{const g=game();g.night=2;g.selfRole.shownRole='monk';g.selfActionLog=[{id:1,roleId:'monk',when:'N2',target:'1L'}];g.deathLog=[{id:2,playerId:'1L',when:'N2',reason:'night_death'}];assert.equal(evaluateAssignment({...noPoison,self:'monk'},g).length,0);assert(evaluateAssignment({...base,self:'monk'},g).some(w=>w.requiredPoison[2]==='self'));});
test('Missing night death is not automatically a confirmed no-kill night',()=>{const g=game();g.night=2;assert(evaluateAssignment(noPoison,g).length);g.completedNights=[2];assert.equal(evaluateAssignment(noPoison,g).length,0);});
test('On a completed night Imp can target an already dead player',()=>{const g=game();g.night=2;g.completedNights=[2];g.deathLog=[{id:1,playerId:'1L',when:'D1',reason:'execution'}];assert(evaluateAssignment(noPoison,g).length);});
test('Own dead vote is consumed, living vote is not',()=>{const g=game();g.deathLog=[{id:1,playerId:'self',when:'D1',reason:'ability'}];g.nominationLog=[{id:2,nominator:'1L',nominee:'1R',when:'D1',voters:['self','2L']}];const s=rebuildStatus(g);assert.equal(s.self.deadVoteAvailable,false);assert.equal(s['2L'].deadVoteAvailable,true);});
test('Virgin event before voting consumes NO ghost votes',()=>{const g=game();g.deathLog=[{id:1,playerId:'self',when:'D1',reason:'ability'}];g.nominationLog=[{id:2,nominator:'1L',nominee:'1R',when:'D1',voters:['self'],votingOccurred:false}];assert.equal(rebuildStatus(g).self.deadVoteAvailable,true);});
test('Historical role claim uses occurrence time, not time entered',()=>{const g=game();claim(g,'1L','empath',1,'D2');claim(g,'1L','chef',2,'D1');assert.equal(latestClaim(g,'1L').subject.roleId,'empath');});
test('Repeated relayed info, even swapped pair order, is one observation',()=>{const g=game();for(let i=0;i<3;i++)g.abilityClaimLog.push({id:i+1,playerId:'2L',sourcePlayerId:'1L',roleId:'fortune_teller',when:'N1',targets:[],result:null,structured:{kind:'pairYesNo',players:i===1?['1R','self']:['self','1R'],result:'yes'},visibility:'public',recipients:[]});assert.equal(observations(g).length,1);});
test('Saint claim alone adds no evil points',()=>{const g=game();claim(g,'1L','saint');assert.equal(analyzeEvidence(g).players['1L'].evil,0);});
test('Unknown conversation alone adds no evil or good points',()=>{const g=game();g.talkLog=[{id:1,participants:['1L','2L'],when:'D1',topic:null,details:null}];const e=analyzeEvidence(g);assert.equal(e.players['1L'].evil,0);assert.equal(e.players['1L'].good,0);});
test('Failed Virgin test alone adds no evil points',()=>{const g=game();g.abilityTriggerLog=[{id:1,roleId:'virgin',rolePlayerId:'1L',targetPlayerId:'2L',when:'D1',triggered:false}];const e=analyzeEvidence(g);assert.equal(e.players['1L'].evil,0);assert.equal(e.players['2L'].evil,0);});
test('Manual read does not feed back into scoring',()=>{const g=game();g.manualReads['1L']={playerId:'1L',roleId:'imp',alignment:'evil',note:'guess',updatedAt:1};assert.equal(analyzeEvidence(g).players['1L'].evil,0);});
test('Deleting linked Virgin nomination removes trigger and execution atomically',()=>{const g=game();g.nominationLog=[{id:1,nominator:'self',nominee:'1L',when:'D1',voters:[],votingOccurred:false}];g.abilityTriggerLog=[{id:2,roleId:'virgin',rolePlayerId:'1L',targetPlayerId:'self',when:'D1',triggered:true,sourceEventId:1}];g.deathLog=[{id:3,playerId:'self',when:'D1',reason:'execution',sourceRoleId:'virgin',sourceEventId:2}];const next=deleteEventGroup(g,'deathLog',3);assert.equal(next.nominationLog.length+next.deathLog.length+next.abilityTriggerLog.length,0);assert.equal(next.playerStatus.self.alive,true);});
test('Malformed import is rejected; proper snapshot accepted',()=>{assert(validateSnapshot(game()));assert(!validateSnapshot({}));assert(!validateSnapshot({...game(),playerCount:900}));});
test('Barely explored samples never cause red/blue/green confidence warnings',()=>{const g=game();const r={players:{'1L':{evil:.99,drunk:.9,poison:{1:.99},roles:{imp:.99}}},unique:1,effectiveWorlds:1};assert.equal(analyzeEvidence(g,r).players['1L'].warnings.length,0);});
test('Sparse data nomination guidance stays HOLD',()=>{const g=game();assert.equal(nominationAdvice(g,null,'1L').verdict,'hold');});
test('Sampler returns bounded exploratory shares, not proof flags',()=>{const g=game();const r=runSearch(g,{attempts:150,seed:123,maxMillis:3000});assert(r.unique>0);assert.equal(r.exhaustive,false);assert(Math.abs(Object.values(r.players).reduce((s,p)=>s+p.evil,0)-2)<1e-9);});
test('Import rejects unknown participant ids',()=>{const g=game();g.talkLog=[{id:1,participants:['1L','not-a-player'],when:'D1',topic:null,details:null}];assert(!validateSnapshot(g));});
test('Import rejects duplicate event ids',()=>{const g=game();claim(g,'1L','saint',1);claim(g,'1R','saint',1);assert(!validateSnapshot(g));});
test('Dead poisoned information character cannot receive later nightly info',()=>{const g=game();g.night=2;g.selfRole.shownRole='fortune_teller';g.deathLog=[{id:1,playerId:'self',when:'D1',reason:'execution'}];g.selfInfoLog=[{id:2,roleId:'fortune_teller',when:'N2',players:['1L','2L'],result:'yes'}];assert.equal(evaluateAssignment(base,g).length,0);});
test('Dead Drunk cannot keep receiving fake recurring info',()=>{const g=game();g.night=2;g.selfRole.shownRole='fortune_teller';g.deathLog=[{id:1,playerId:'self',when:'D1',reason:'execution'}];g.selfInfoLog=[{id:2,roleId:'fortune_teller',when:'N2',players:['1L','2L'],result:'yes'}];const w={self:'drunk','1L':'chef','2L':'baron','2R':'saint','1R':'imp'};assert.equal(evaluateAssignment(w,g).length,0);});
test('Drunk has one fixed believed character, not a different one each report',()=>{const g=game();const w={self:'chef','1L':'drunk','2L':'baron','2R':'saint','1R':'imp'};g.abilityClaimLog=[{id:1,playerId:'1L',roleId:'fortune_teller',when:'N1',targets:[],result:null,structured:{kind:'pairYesNo',players:['1R','self'],result:'yes'},visibility:'public',recipients:[]},{id:2,playerId:'1L',roleId:'empath',when:'N1',targets:[],result:null,structured:{kind:'number',value:0},visibility:'public',recipients:[]}];const hs=evaluateAssignment(w,g,10);assert(hs.length);assert(hs.every(h=>!(h.info[1]==='drunk'&&h.info[2]==='drunk')));});
test('Two living players with a Demon cannot continue to another night',()=>{const g=game();g.night=3;g.deathLog=[{id:1,playerId:'2L',when:'D1',reason:'execution'},{id:2,playerId:'1L',when:'N2',reason:'night_death'},{id:3,playerId:'self',when:'D2',reason:'execution'}];assert.equal(evaluateAssignment(base,g).length,0);});
test('Public proof can flag contradictory manual read without sampling',()=>{const g=game();g.abilityTriggerLog=[{id:1,roleId:'virgin',rolePlayerId:'1L',targetPlayerId:'self',when:'D1',triggered:true}];g.manualReads['1L']={playerId:'1L',roleId:'spy',alignment:'evil',note:'guess',updatedAt:1};assert(analyzeEvidence(g).players['1L'].warnings.some(w=>w.color==='yellow'));});
test('Demon mode locks self, known Minion seats, exact teammate roles, and Storyteller bluffs',()=>{
  const g=game(10);g.selfRole.shownRole='imp';g.demonState={knownMinions:[{playerId:'1L',source:'demon_info',roleId:'poisoner'},{playerId:'2R',source:'demon_info',roleId:'scarlet_woman'}],storytellerBluffs:['soldier','mayor','monk'],bluffPlans:{self:'chef','1L':'empath'}};g.demonActionLog=[];
  const r=runSearch(g,{attempts:1800,seed:947,maxMillis:5000,beamWidth:2});
  assert(r.worlds.length>0);
  for(const w of r.worlds){
    assert.equal(w.initial.self,'imp');assert.equal(w.initial['1L'],'poisoner');assert.equal(w.initial['2R'],'scarlet_woman');
    for(const bluff of g.demonState.storytellerBluffs)assert(!Object.values(w.initial).includes(bluff));
  }
});
test('Demon attack record constrains ordinary night death to the selected target',()=>{
  const g=game(10);g.night=2;g.selfRole.shownRole='imp';g.demonState={knownMinions:[{playerId:'1L',source:'demon_info',roleId:'poisoner'},{playerId:'2L',source:'demon_info',roleId:'spy'}],storytellerBluffs:[],bluffPlans:{}};g.demonActionLog=[{id:10,roleId:'imp',when:'N2',target:'3L',note:null}];g.deathLog=[{id:11,playerId:'3L',when:'N2',reason:'night_death'}];
  const w={self:'imp','1L':'poisoner','2L':'spy','3L':'washerwoman','4L':'librarian','5L':'investigator','4R':'chef','3R':'empath','2R':'fortune_teller','1R':'undertaker'};
  assert(evaluateAssignment(w,g).length>0);
  g.deathLog=[{id:11,playerId:'4L',when:'N2',reason:'night_death'}];
  assert.equal(evaluateAssignment(w,g).length,0);
});
test('Demon may deliberately sink a kill into an already-dead player',()=>{
  const g=game(10);g.night=2;g.selfRole.shownRole='imp';g.completedNights=[2];g.demonActionLog=[{id:10,roleId:'imp',when:'N2',target:'3L',note:null}];g.deathLog=[{id:9,playerId:'3L',when:'D1',reason:'execution'}];
  const w={self:'imp','1L':'poisoner','2L':'spy','3L':'washerwoman','4L':'librarian','5L':'investigator','4R':'chef','3R':'empath','2R':'fortune_teller','1R':'undertaker'};
  assert(evaluateAssignment(w,g).length>0);
});
test('Imp self-kill with a healthy Scarlet Woman passes to Scarlet Woman first',()=>{
  const g=game(10);g.night=2;g.selfRole.shownRole='imp';g.demonActionLog=[{id:10,roleId:'imp',when:'N2',target:'self',note:null}];g.deathLog=[{id:11,playerId:'self',when:'N2',reason:'night_death'}];
  const w={self:'imp','1L':'scarlet_woman','2L':'spy','3L':'washerwoman','4L':'librarian','5L':'investigator','4R':'chef','3R':'empath','2R':'fortune_teller','1R':'undertaker'};
  const hs=evaluateAssignment(w,g);assert(hs.length>0);assert(hs.every(x=>x.current['1L']==='imp'&&x.current['2L']==='spy'));
});
test('Demon-state import rejects a non-Minion exact teammate role',()=>{
  const g=game(10);g.selfRole.shownRole='imp';g.demonState={knownMinions:[{playerId:'1L',source:'demon_info',roleId:'chef'}],storytellerBluffs:[],bluffPlans:{}};g.demonActionLog=[];assert.equal(validateSnapshot(g),false);
});

test('Minion mode locks self, known Demon, fellow Minions, and shared ST bluffs',()=>{
  const g=game(10);g.selfRole.shownRole='poisoner';
  g.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[{playerId:'1L',source:'minion_info',roleId:'spy'}],sharedStorytellerBluffs:['soldier','mayor','monk'],bluffPlans:{self:'chef'},spyInitialRoles:{},spyRedHerring:null,becameDemonAt:null};
  g.minionActionLog=[];g.demonActionLog=[];
  const r=runSearch(g,{attempts:1800,seed:195,maxMillis:5000,beamWidth:2});
  assert(r.worlds.length>0);
  for(const w of r.worlds){
    assert.equal(w.initial.self,'poisoner');assert.equal(w.initial['1R'],'imp');assert.equal(w.initial['1L'],'spy');
    for(const bluff of g.minionState.sharedStorytellerBluffs)assert(!Object.values(w.initial).includes(bluff));
  }
});
test('Own Poisoner action fixes that nights poison target and produces a direct green marker',()=>{
  const g=game(10);g.selfRole.shownRole='poisoner';g.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[{playerId:'1L',source:'minion_info',roleId:'spy'}],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{},spyRedHerring:null,becameDemonAt:null};g.minionActionLog=[{id:40,roleId:'poisoner',kind:'poison',when:'N1',target:'2L',note:null}];
  const w={self:'poisoner','1L':'spy','2L':'washerwoman','3L':'librarian','4L':'investigator','5L':'chef','4R':'empath','3R':'fortune_teller','2R':'undertaker','1R':'imp'};
  const hs=evaluateAssignment(w,g);assert(hs.length>0);assert(hs.every(x=>x.poison[1]==='2L'));
  assert(analyzeEvidence(g).players['2L'].warnings.some(x=>x.color==='green'&&x.cycle===1));
});
test('A mismatching Spy Grimoire remains possible only through Spy poisoning',()=>{
  const g=game(10);g.selfRole.shownRole='spy';g.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[{playerId:'1L',source:'minion_info',roleId:'poisoner'}],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{'2L':'mayor'},spyRedHerring:null,becameDemonAt:null};g.minionActionLog=[];
  const w={self:'spy','1L':'poisoner','2L':'washerwoman','3L':'librarian','4L':'investigator','5L':'chef','4R':'empath','3R':'fortune_teller','2R':'undertaker','1R':'imp'};
  const hs=evaluateAssignment(w,g,20);assert(hs.length>0);assert(hs.every(x=>x.poison[1]==='self'));
});
test('Healthy Spy poison reminder matches the real poison target, but a poisoned Spy can be misinformed',()=>{
  const g=game(10);g.selfRole.shownRole='spy';g.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[{playerId:'1L',source:'minion_info',roleId:'poisoner'}],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{},spyRedHerring:null,becameDemonAt:null};g.minionActionLog=[{id:41,roleId:'spy',kind:'grimoire',when:'N1',poisonTarget:'2L',note:null}];
  const w={self:'spy','1L':'poisoner','2L':'washerwoman','3L':'librarian','4L':'investigator','5L':'chef','4R':'empath','3R':'fortune_teller','2R':'undertaker','1R':'imp'};
  const hs=evaluateAssignment(w,g,20);assert(hs.length>0);assert(hs.every(x=>x.poison[1]==='2L'||x.poison[1]==='self'));
  assert(analyzeEvidence(g).players['2L'].warnings.some(x=>x.color==='green'&&x.cycle===1));
});
test('Scarlet Woman takeover can be recorded as direct self Demon succession',()=>{
  const g=game(10);g.night=2;g.selfRole.shownRole='scarlet_woman';g.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[{playerId:'1L',source:'minion_info',roleId:'spy'}],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{},spyRedHerring:null,becameDemonAt:'D1'};g.minionActionLog=[];g.deathLog=[{id:50,playerId:'1R',when:'D1',reason:'execution'}];
  const w={self:'scarlet_woman','1L':'spy','2L':'washerwoman','3L':'librarian','4L':'investigator','5L':'chef','4R':'empath','3R':'fortune_teller','2R':'undertaker','1R':'imp'};
  const hs=evaluateAssignment(w,g);assert(hs.length>0);assert(hs.every(x=>x.current.self==='imp'&&x.changes.some(c=>c.to==='self'&&c.when==='D1')));
});
test('Minion-state import rejects self as known Demon and non-Minion teammate roles',()=>{
  const a=game(10);a.selfRole.shownRole='poisoner';a.minionState={knownDemon:{playerId:'self',source:'minion_info'},knownMinions:[],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{},spyRedHerring:null,becameDemonAt:null};a.minionActionLog=[];assert.equal(validateSnapshot(a),false);
  const b=game(10);b.selfRole.shownRole='poisoner';b.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[{playerId:'1L',source:'minion_info',roleId:'chef'}],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{},spyRedHerring:null,becameDemonAt:null};b.minionActionLog=[];assert.equal(validateSnapshot(b),false);
});


test('Spy opponent projection strips private evil knowledge and self-only whispers',()=>{
  const g=game(7);g.selfRole.shownRole='spy';
  g.minionState={knownDemon:{playerId:'1R',source:'minion_info'},knownMinions:[],sharedStorytellerBluffs:['mayor'],bluffPlans:{self:'chef'},spyInitialRoles:{'1L':'washerwoman'},spyRedHerring:'2L',becameDemonAt:null};
  g.minionActionLog=[{id:71,roleId:'spy',kind:'grimoire',when:'N1',poisonTarget:null,note:'secret'}];
  g.roleClaimLog=[
    {id:72,playerId:'self',subject:{kind:'role',roleId:'chef'},claimType:'bluff',origin:'manual',visibility:'public',recipients:[],when:'D1'},
    {id:73,playerId:'1L',subject:{kind:'role',roleId:'empath'},claimType:'normal',origin:'manual',visibility:'private',recipients:['self'],when:'D1'},
    {id:74,playerId:'2L',subject:{kind:'role',roleId:'fortune_teller'},claimType:'bluff',origin:'manual',visibility:'public',recipients:[],when:'D1'},
  ];
  const projected=buildSpyOpponentProjection(g);
  assert.equal(projected.selfRole.shownRole,null);
  assert.equal(projected.minionState.knownDemon,null);
  assert.equal(projected.minionActionLog.length,0);
  assert(!projected.roleClaimLog.some(c=>c.playerId==='self'));
  assert(!projected.roleClaimLog.some(c=>c.id===73));
  assert.equal(projected.roleClaimLog.find(c=>c.id===74).claimType,'normal');
});

test('Spy bluff advisor ranks only good roles and returns a collision-aware recommendation',()=>{
  const g=game(5);g.selfRole.shownRole='spy';
  g.minionState={knownDemon:null,knownMinions:[],sharedStorytellerBluffs:[],bluffPlans:{},spyInitialRoles:{'1L':'washerwoman','2L':'chef','2R':'empath','1R':'imp'},spyRedHerring:null,becameDemonAt:null};
  g.minionActionLog=[];g.demonActionLog=[];
  const r=runSpyBluffAdvisor(g,false);
  assert(r.candidates.length>0);
  assert(r.candidates.every(c=>['townsfolk','outsider'].includes(require('../.engine-test/roles.js').ROLES[c.roleId].type)));
  assert(r.recommendedRoleId);
  assert(r.baseUnique>0);
  const washer=r.candidates.find(c=>c.roleId==='washerwoman');
  assert.equal(washer.spyShownInPlayAt,'1L');
  assert.equal(washer.safeEligible,false);
});


test('Direct Exorcist no-death choice adds suspicion to the chosen player',()=>{
  const g=game(7);g.playset='bad_moon_rising';g.scriptRoleIds=['grandmother','sailor','exorcist','innkeeper','goon','mastermind','po'];g.night=2;g.completedNights=[2];g.selfRole.shownRole='exorcist';g.selfActionLog=[{id:90,roleId:'exorcist',when:'N2',target:'1L'}];
  const e=analyzeEvidence(g);assert(e.players['1L'].evil>=2);assert(e.players['1L'].reasons.some(r=>r.code==='exorcistNoDeathDirect'));
});
test('Reported Exorcist repeated target is flagged as inconsistent',()=>{
  const g=game(7);g.playset='bad_moon_rising';g.scriptRoleIds=['grandmother','sailor','exorcist','innkeeper','goon','mastermind','po'];g.night=3;g.completedNights=[2,3];g.abilityClaimLog=[
    {id:91,playerId:'1L',roleId:'exorcist',when:'N2',targets:['2L'],result:null,visibility:'public',recipients:[]},
    {id:92,playerId:'1L',roleId:'exorcist',when:'N3',targets:['2L'],result:null,visibility:'public',recipients:[]},
  ];
  const e=analyzeEvidence(g);assert(e.players['1L'].inconsistency>=1.5);assert(e.players['1L'].reasons.some(r=>r.code==='exorcistRepeatTarget'));
});
test('Mastermind risk is surfaced after an execution followed by a completed no-death night',()=>{
  const g=game(7);g.playset='bad_moon_rising';g.scriptRoleIds=['grandmother','sailor','exorcist','innkeeper','goon','mastermind','po'];g.night=3;g.completedNights=[3];g.deathLog=[{id:93,playerId:'1L',when:'D2',reason:'execution'}];
  const e=analyzeEvidence(g);assert((e.global.mastermind?.points??0)>=1);assert(e.global.mastermind.reasons.some(r=>r.code==='mastermindNoDeathAfterExecution'));
  const a=nominationAdvice(g,null,'2L');assert(a.risks.some(r=>r.code==='mastermindRisk'));assert.equal(a.verdict,'hold');
});
test('Snapshot validation accepts a direct self Exorcist action',()=>{
  const g=game(7);g.playset='bad_moon_rising';g.scriptRoleIds=['grandmother','sailor','exorcist','innkeeper','goon','mastermind','po'];g.night=2;g.selfRole.shownRole='exorcist';g.selfActionLog=[{id:94,roleId:'exorcist',when:'N2',target:'1L'}];assert(validateSnapshot(g));
});


test('BMR protection tags distinguish general death prevention from execution-death prevention',()=>{
  for(const id of ['monk','soldier','sailor','exorcist','innkeeper','tea_lady','fool','zombuul']){
    assert(ROLES[id].tags.includes('PREVENTS_DEATH'),`${id} should prevent death`);
  }
  for(const id of ['sailor','tea_lady','fool','pacifist','devils_advocate']){
    assert(ROLES[id].tags.includes('PREVENTS_EXECUTION_DEATH'),`${id} should prevent execution death`);
  }
  for(const id of ['pacifist','devils_advocate']){
    assert(!ROLES[id].tags.includes('PREVENTS_DEATH'),`${id} should use only the execution-specific tag`);
  }
});


test('Revival returns a dead player to alive status',()=>{
  const g=game(7);g.night=2;g.deathLog=[{id:200,playerId:'1L',when:'D1',reason:'execution'}];g.revivalLog=[{id:201,playerId:'1L',when:'N2'}];
  const s=rebuildStatus(g);assert.equal(s['1L'].alive,true);assert.equal(s['1L'].deadVoteAvailable,true);
});
test('A revived player can die again later',()=>{
  const g=game(7);g.night=3;g.deathLog=[{id:210,playerId:'1L',when:'D1',reason:'execution'},{id:212,playerId:'1L',when:'N3',reason:'night_death'}];g.revivalLog=[{id:211,playerId:'1L',when:'N2'}];
  const s=rebuildStatus(g);assert.equal(s['1L'].alive,false);assert.equal(s['1L'].deadVoteAvailable,true);assert(validateSnapshot(g));
});


test('Pit-Hag metadata marks character-changing night targeting',()=>{
  for(const tag of ['WAKES_OTHER_NIGHTS','TARGETS_PLAYER','TARGETS_CHARACTER','ROLE_CHANGING']) assert(ROLES.pit_hag.tags.includes(tag),tag);
});

test('Snapshot validation accepts Pit-Hag transformations only from N2 onward',()=>{
  const g=game(7);g.playset='sects_and_violets';g.scriptRoleIds=['clockmaker','dreamer','mathematician','flowergirl','town_crier','pit_hag','imp','witch','vortox'];g.night=2;g.selfRole.shownRole='pit_hag';
  g.minionActionLog=[{id:300,roleId:'pit_hag',kind:'transform',when:'N2',target:'2L',newRole:'witch',note:null}];assert(validateSnapshot(g));
  g.minionActionLog=[{id:301,roleId:'pit_hag',kind:'transform',when:'N1',target:'2L',newRole:'witch',note:null}];assert.equal(validateSnapshot(g),false);
});

test('Direct Pit-Hag action changes character but preserves alignment',()=>{
  const g=game(7);g.playset='sects_and_violets';g.scriptRoleIds=['clockmaker','dreamer','mathematician','flowergirl','town_crier','pit_hag','imp','witch','vortox'];g.night=2;g.selfRole.shownRole='pit_hag';g.minionActionLog=[{id:310,roleId:'pit_hag',kind:'transform',when:'N2',target:'2L',newRole:'witch',note:null}];
  const w={self:'pit_hag','1L':'dreamer','2L':'clockmaker','3L':'mathematician','3R':'flowergirl','2R':'town_crier','1R':'imp'};
  const hs=evaluateAssignment(w,g);assert(hs.length>0);assert(hs.every(x=>x.current['2L']==='witch'));assert(hs.every(x=>x.currentAlignment['2L']==='good'));assert(hs.every(x=>x.changes.some(c=>c.kind==='pit_hag'&&c.playerId==='2L'&&c.fromRole==='clockmaker'&&c.toRole==='witch')));
});

test('Pit-Hag Demon creation makes that nights deaths arbitrary',()=>{
  const script=['clockmaker','dreamer','mathematician','flowergirl','town_crier','pit_hag','imp','vortox'];
  const w={self:'pit_hag','1L':'dreamer','2L':'clockmaker','3L':'mathematician','3R':'flowergirl','2R':'town_crier','1R':'imp'};
  const base=game(7);base.playset='custom:test';base.scriptName='Pit-Hag test';base.scriptRoleIds=script;base.night=2;base.selfRole.shownRole='pit_hag';base.deathLog=[{id:320,playerId:'3L',when:'N2',reason:'night_death'},{id:321,playerId:'3R',when:'N2',reason:'night_death'}];
  assert.equal(evaluateAssignment(w,base).length,0);
  base.minionActionLog=[{id:322,roleId:'pit_hag',kind:'transform',when:'N2',target:'2L',newRole:'vortox',note:null}];
  const hs=evaluateAssignment(w,base);assert(hs.length>0);assert(hs.every(x=>x.current['2L']==='vortox'));assert(hs.every(x=>x.currentAlignment['2L']==='good'));assert(hs.every(x=>x.arbitraryDeathNights.includes(2)));
});


test('Empath repeating the same result on different nights is not an input conflict',()=>{
  const g=game(7);g.night=2;
  g.abilityClaimLog=[
    {id:201,playerId:'1L',roleId:'empath',when:'N1',targets:[],result:null,structured:{kind:'number',value:1},visibility:'public',recipients:[]},
    {id:202,playerId:'1L',roleId:'empath',when:'N2',targets:[],result:null,structured:{kind:'number',value:1},visibility:'public',recipients:[]},
  ];
  const e=analyzeEvidence(g);
  assert.equal(e.players['1L'].inconsistency,0);
  assert(!e.players['1L'].warnings.some(w=>w.color==='orange'||w.color==='yellow'));
});

test('Empath changed read with stable neighbours creates impairment signal',()=>{
  const g=game(7);g.night=2;g.abilityClaimLog=[
    {id:401,playerId:'1L',roleId:'empath',when:'N1',targets:[],result:null,structured:{kind:'number',value:1},visibility:'public',recipients:[]},
    {id:402,playerId:'1L',roleId:'empath',when:'N2',targets:[],result:null,structured:{kind:'number',value:0},visibility:'public',recipients:[]},
  ];
  const shifts=empathStableNeighbourShifts(g);assert.equal(shifts.length,1);assert.equal(shifts[0].source,'1L');
  const e=analyzeEvidence(g);assert(e.players['1L'].reasons.some(r=>r.code==='empathShiftStableNeighbours'));
});

test('Nearby neighbour death prevents Empath stable-neighbour impairment signal',()=>{
  const g=game(7);g.night=2;g.deathLog=[{id:410,playerId:'self',when:'N2',reason:'night_death'}];g.abilityClaimLog=[
    {id:411,playerId:'1L',roleId:'empath',when:'N1',targets:[],result:null,structured:{kind:'number',value:1},visibility:'public',recipients:[]},
    {id:412,playerId:'1L',roleId:'empath',when:'N2',targets:[],result:null,structured:{kind:'number',value:0},visibility:'public',recipients:[]},
  ];
  assert.equal(empathStableNeighbourShifts(g).length,0);
});

test('Empath stable-neighbour shift rewards Drunk or poison explanations',()=>{
  const g=game(5);g.night=2;g.abilityClaimLog=[
    {id:421,playerId:'1L',roleId:'empath',when:'N1',targets:[],result:null,structured:{kind:'number',value:1},visibility:'public',recipients:[]},
    {id:422,playerId:'1L',roleId:'empath',when:'N2',targets:[],result:null,structured:{kind:'number',value:0},visibility:'public',recipients:[]},
  ];
  const signals=empathStableNeighbourShifts(g);assert.equal(signals.length,1);
  const mk=(role,requiredPoison={})=>({initial:{self:'chef','1L':role,'2L':'baron','2R':'saint','1R':'imp'},current:{self:'chef','1L':role,'2L':'baron','2R':'saint','1R':'imp'},initialAlignment:{self:'good','1L':'good','2L':'evil','2R':'good','1R':'evil'},currentAlignment:{self:'good','1L':'good','2L':'evil','2R':'good','1R':'evil'},believedRoles:role==='drunk'?{'1L':'empath'}:{},alive:['self','1L','2L','2R','1R'],redHerring:null,poison:{},requiredPoison,info:{},changes:[],arbitraryDeathNights:[],logScore:0,assumptions:[],ended:false});
  const healthy=empathShiftLogBonus(mk('empath'),signals,g);
  const drunk=empathShiftLogBonus(mk('drunk'),signals,g);
  const poisoned=empathShiftLogBonus(mk('empath',{2:'1L'}),signals,g);
  assert(drunk>healthy);assert(poisoned>healthy);
});

console.log(`\n${passed}/${tests.length} tests passed`);
require('fs').writeFileSync(require('path').join(__dirname,'results.json'),JSON.stringify({passed,total:tests.length,tests},null,2));
