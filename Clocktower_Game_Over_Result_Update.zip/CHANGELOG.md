## 2026-10-02 - Unified information recording

- Merged the separate `その他の能力主張` and structured information-report UI into one `情報を記録` flow.
- The tapped player is always the speaker. `元の人` is the player whose ability/information is being described.
- `元の人の役職` can be any role on the frozen script. Existing structured forms are used automatically for the eight supported information roles; every other role gets generic target + free-text fields.
- Player history now shows one combined `情報記録` section, including `元:` when a speaker relays another player's information.
- The bottom `取り消し` removes the most recent information record regardless of whether it used a structured or generic role form.
- Free-text records are no longer surfaced as input errors merely because the solver cannot mechanically parse them yet.
- Existing save compatibility is preserved by retaining the `abilityClaimLog` storage field internally.

## Empath stable-neighbour impairment heuristic

- Changing Empath numbers across consecutive nights no longer look like an ordinary healthy-information change when the same two living neighbours remain and neither neighbour died between reads.
- Such patterns now increase search weight for Drunk explanations and for worlds that require poison on the Empath.
- Worlds containing an in-script `POISON_DRUNK_ABILITY` character also receive a smaller generic boost so BMR/custom scripts can express impairment before every exact role mechanic is implemented.
- Alignment-changing scripts reduce this boost, because a neighbour changing alignment can also change a healthy Empath number.
- The pattern is shown as a heuristic reason, not an inconsistency or hard confirmation.

- Added a regression guard so Empath reports from different nights (for example N1=1 and N2=1) are never treated as conflicting information.
- Added a bottom `取り消し` button to saved `見立て` so stale personal reads—and their yellow warning badge—can be cleared directly.
## Sects & Violets Pit-Hag action update

- Added `ROLE_CHANGING` as a broad role tag and assigned Pit-Hag: `WAKES_OTHER_NIGHTS`, `TARGETS_PLAYER`, `TARGETS_CHARACTER`, `ROLE_CHANGING`.
- Added direct self Pit-Hag action entry from N2 onward: choose night, player, new character, and optional note.
- Pit-Hag action history now has a bottom `取り消し` control for the most recent transformation record.
- Candidate histories apply a healthy Pit-Hag transformation only when the chosen character is not currently in play.
- Pit-Hag transformations change `current` character only; `currentAlignment` is preserved.
- Creating a Demon marks that night as an arbitrary-death night, so ordinary Imp kill-count/target constraints are not used for that night.
- Multiple living Demons created through character change no longer cause the first Demon death to end the world immediately.
- Saved/imported Pit-Hag actions are validated as N2+ events and the created character must belong to the frozen script.
- Analysis history and candidate-world explanations now show Pit-Hag transformations and arbitrary-death nights.
- Engine/data regression suite: **80 / 80 passed**.
- Full TS/TSX offline source check with local React stubs: **passed**.

## Sects & Violets role/alignment groundwork

- Changed Chambermaid symbol from `侍` to `婢`.
- Changed Cerenovus symbol from `狂` to `脳`, removing the Lunatic/Cerenovus symbol collision.
- Added a first-class `Alignment` type (`good` / `evil`).
- Candidate worlds now store character identity and alignment independently as `initial/current` roles plus `initialAlignment/currentAlignment`.
- Chef/Empath alignment checks and displayed evil percentages now read the player's actual world alignment instead of inferring alignment from the current character type.
- Representative worlds now display both current character and current alignment.
- Archived reasoning summaries now include alignment maps while remaining backward-compatible with older logs.
- Added regression coverage proving that a good-aligned Demon/Minion character can be represented without being treated as evil merely because of its character type.
- This is the foundation for Pit-Hag: changing a character will preserve alignment unless another ability explicitly changes alignment.

## Revival + undo UI

- Added revival tracking (`revivalLog`) with a `復活` button for dead players when the selected script contains a role tagged `REVIVES`.
- Revival currently records at the current night and restores the player to alive status; revived players can die again later.
- Added revival events to save/import validation, history, status rebuilding, and the generic world timeline.
- Simplified correction UI: role claims, information claims, other ability claims, self information, and self actions now use a single `取り消し` button at the bottom instead of tiny per-row delete buttons.
- Existing history/analysis deletion remains available for targeted older-event cleanup.

## BMR protection tag correction

- Sailor, Tea Lady, and Fool now also carry `PREVENTS_EXECUTION_DEATH` while retaining `PREVENTS_DEATH`.
- Pacifist and Devil's Advocate remain execution-specific protection.
- Updated protection regression coverage and docs.

## BMR protection tag split

- Added `PREVENTS_EXECUTION_DEATH` as a separate tag from `PREVENTS_DEATH`.
- Pacifist and Devil's Advocate now use `PREVENTS_EXECUTION_DEATH`: the execution still occurs, but the executed player may survive.
- General death-prevention roles stay on `PREVENTS_DEATH`, including Monk, Soldier, Sailor, Exorcist, Innkeeper, Tea Lady, Fool, and Zombuul.
- Minion-mode protection heuristics now recognize both tags while displaying distinct reasons for general death protection vs execution-death protection.
- Added a regression test for the BMR protection-tag split.

# 2026-10-02 - BMR effect-tag groundwork

- Renamed the generic `POISONING` role tag to `POISON_DRUNK_ABILITY` so the same metadata can represent both poisoning and drunkenness effects.
- Renamed `PROTECTIVE` to `PREVENTS_DEATH` and assigned it to Monk, Soldier, Sailor, Innkeeper, Tea Lady, Pacifist, and Fool.
- Renamed `KILLING` to `KILLS`; assigned it to the existing Slayer/Imp plus BMR Gossip, Moonchild, Godfather, Assassin, Zombuul, Pukka, Shabaloth, and Po.
- Added the `REVIVES` tag and assigned it to Professor and Shabaloth.
- Added BMR poison/drunk metadata to Sailor, Innkeeper, Courtier, Minstrel, Goon, and Pukka, in addition to Poisoner.
- Added `maxKillsPerNight` Demon metadata: Imp 1, Zombuul 1, Pukka 1, Shabaloth 2, Po 3. This is a ceiling for the character's own kill ability, not a complete timing model.
- Updated Minion-mode target heuristics to use `PREVENTS_DEATH`.

# Script Manager update

- Added main-menu `スクリプト管理`.
- Added ON/OFF custom-script creator with name-on-save flow.
- Added built-in Trouble Brewing, Bad Moon Rising, and Sects and Violets definitions.
- Added the 72 core player characters to the role catalog.
- Script role lists now drive role selectors, evil bluff tools, Spy tools, and candidate-world role pools.
- Game saves freeze script name + exact role list so later custom-script edits do not alter old games.
- Added generic solver fallback for BMR/S&V roles instead of applying incorrect TB-only mechanics.
- Drunk/Lunatic hidden-role possibilities are now script-gated.
- Existing 68/68 Trouble Brewing reasoning regression tests still pass.

# Changelog

## Information-entry and history usability fix

### Fixed

- Information roles can no longer be accidentally saved through the generic free-text ability-claim form.
- If a player already has an exact information-role claim, opening `その他の能力主張` now routes directly to the structured `情報主張` form.
- The generic ability-role dropdown excludes Washerwoman, Librarian, Investigator, Chef, Empath, Fortune Teller, Undertaker, and Ravenkeeper.
- Legacy information-role ability entries without structured data are now labeled `旧形式・詳細なし（削除して情報主張から再入力）` instead of the misleading `内容未記録`.
- Structured information history is separated from other ability claims and shows the actual role-specific result.
- Undertaker and Ravenkeeper reported information can only be entered from N2 onward.

### History / deletion UX

- Role-claim and information/ability history rows now have visible inline `削除` buttons.
- Deleting a linked record still removes its automatically generated dependent records atomically.
- `自分の情報` now shows `過去の情報` directly above the entry form, with inline delete controls.
- `自分の行動` now shows `過去の行動` directly above the entry form, with inline delete controls.
- Information-role input is consistently labeled `情報主張`; the old generic route is labeled `その他の能力主張`.

### Checked role-specific structured inputs

- Washerwoman: two players + shown Townsfolk.
- Librarian: two players + shown Outsider, or no Outsiders.
- Investigator: two players + shown Minion.
- Chef: numeric result.
- Empath: night + 0/1/2.
- Fortune Teller: night + two targets + YES/NO.
- Undertaker: N2+ + executed player + shown role.
- Ravenkeeper: N2+ + chosen player + shown role.

### Verification

- Engine/data regression suite: **68 / 68 passed**.
- Full TS/TSX offline syntax/type pass with local React stubs: **passed**.
- No new runtime dependency added.


## Spy bluff-world advisor update

### Added

- Automatic Spy-only bluff recommendations ranked by opponent-view candidate-world diversity.
- Counterfactual good-team projection that removes the user's true Spy token, evil-team setup knowledge, Grimoire contents, Poisoner reminder information, Minion/Demon actions, private manual reads, and the user's existing bluff before searching.
- Private reports are included in the opponent projection only when at least one non-known-evil recipient could know them; internal `bluff` labels are normalized because opponents do not know a claim is a bluff.
- Candidate support includes three explanations: genuinely that good role, Drunk believing that Townsfolk role, or evil bluffing the role.
- Distinct-assignment count, effective-world count, and good-facade share for each recommended role.
- `推奨` = maximum-world option after avoiding known in-play role collisions, current opponent claims, and teammate bluff-plan collisions.
- `世界数1位` = raw maximum-world option even when a practical collision exists.
- Grimoire/ST/claim/team-plan badges on every recommendation.
- One-tap `このブラフを採用` integration with the existing evil-team bluff plan.
- Automatic debounced recomputation plus normal/deep manual reruns in a dedicated Web Worker.
- Search-result support for a larger returned representative-world pool used by counterfactual strategy analysis, without changing the normal Possible Worlds display limit.

### Verification

- Engine/data regression suite: **68 / 68 passed**.
- Full source TS/TSX offline type check: **passed**.
- No new runtime dependency added.

## Minion Mode update

### Added

- Dedicated self-role Minion mode for Poisoner, Spy, Scarlet Woman, and Baron.
- Standard 7+ Minion team-knowledge entry: known Demon and other Minion player identities.
- 5-6 player handling that does not assume starting evil-team information.
- Later confirmation of exact fellow-Minion characters without pretending those characters were known at setup.
- Storyteller bluffs explicitly shared by the Demon, treated as out-of-play hard constraints.
- Team bluff-plan board that is intentionally excluded from solver evidence.
- Private board markers: `魔` for known Demon and `味` for known fellow Minions.
- Poisoner nightly target log, replacement confirmation, target hints, lightweight target suggestions, and direct green cycle marker.
- Spy N1 Grimoire editor, Fortune Teller red-herring entry, nightly Grimoire/Poisoner-reminder log, and bluff-planning classifications.
- Conditional Spy reasoning: healthy Spy observations constrain worlds; a Spy poisoned by a teammate may receive false Grimoire information.
- Scarlet Woman direct Demon-succession entry with exact N/D phase.
- Baron setup-count display and hard Baron setup modification from the user's own token.
- Successor-Imp attack logging after a Minion becomes the Demon, beginning the following night.
- Minion actions in analysis history, autosave, JSON import/export, checkpoints, and archived game logs.
- New Minion-mode regression tests.

### Solver changes

- Own exact Minion character is a hard assignment constraint.
- Directly known Demon is locked to Imp.
- Directly known fellow Minion seats are constrained to Minion characters; exact character only when explicitly confirmed.
- Shared Storyteller bluffs are excluded from actual starting assignments.
- Bluff plans never alter world generation or weights.
- Own Poisoner target fixes that night's actual poison target while the player remains a valid Poisoner.
- Spy Grimoire observations are no longer incorrectly treated as unconditional hard truth: self-poison worlds can explain false displays.
- Direct `became Demon` observations require a matching legal starpass/Scarlet Woman transition.
- Minion-specific actions cease after the transition cycle; normal successor-Imp attacks begin the next night.

### Verification

- Engine/data regression suite: **66 / 66 passed**.
- Full source TS/TSX offline type check: **passed**.
- No new runtime dependency added.

## Previous Demon Mode update

- Dedicated Imp mode.
- Known Minion seats and later exact teammate-role confirmation.
- Three Storyteller bluff records for standard 7+ Demon information.
- Team bluff planner and opponent-claim availability board.
- Imp attack history, self-kill/starpass support, dead-target sinking, and target suggestions.
- Scarlet Woman priority on eligible Imp self-kill.
- Demon-mode data included in solver, logs, exports, and checkpoints.

## Previous Game Log + Possible Worlds update

- Multi-game archive with outcome/note editing and snapshot/finished entries.
- Direct `候補盤面を確認` menu route.
- Reload archived games into current Possible Worlds.
- Export/import support for archive data.

## Previous reasoning-engine update

- Bounded candidate-world search for Trouble Brewing.
- Mechanical information checks, poison/Drunk explanations, registration, Demon changes, and historical states.
- Red/orange/yellow/blue/green warnings with Japanese explanation drawers.
- Reasoning Web Worker, overview, information audit, candidate worlds, chronological history, and action heuristics.
- Browser save/resume and full pre-night checkpoints.

## Explicitly not included

- Travellers.
- Non-Trouble-Brewing scripts.
- Exhaustive/calibrated probability computation.
- Complete generic counterfactual strategy optimization.
- Production APK/PWA packaging.

## Vote order / Drunk visibility / structured history
- Player summaries now show Evil / Demon / Drunk candidate shares together.
- Nomination advice also shows Drunk candidate share.
- Vote buttons now follow the physical clockwise seating order, beginning immediately after the nominee and ending with the nominee.
- Saved voter arrays are normalized to that same clockwise order instead of click order.
- Structured reported information now renders its actual value in player history (fixes Chef showing "内容未記録").

## Self menu merge
- Removed the extra `自分の会話・指名・状態` hop.
- Self social claims, reported information, nominations, conversations and status are now opened directly from the self menu.
- The name editor is never shown for self.
- Saving/backing out of a self social form returns to the self hub.
- Added documentation of the current hard-coded Trouble Brewing script architecture and its limitations.

## BMR Mastermind / Exorcist pass

- Added `ON_DEATH`, `ON_DEMON_EXECUTION`, `TARGETS_CHARACTER`, `CAUSES_OWN_DEATH`, `BYPASSES_DEATH_PREVENTION`, `ALIGNMENT_CHANGING`, and `GAME_CONTINUATION` role tags.
- Completed the discussed BMR metadata pass for Grandmother, Chambermaid, Exorcist, Gambler, Courtier, Goon, Lunatic, Tinker, Moonchild, Godfather, Devil's Advocate, Assassin, Mastermind, and Zombuul.
- Added `PREVENTS_DEATH` to Exorcist and Devil's Advocate.
- Added direct self Exorcist action recording with the no-repeat-target rule.
- Added heuristic Exorcist no-death suspicion scoring.
- Added Mastermind no-death-after-execution evidence and nomination-risk warnings.
- Added Mastermind to the reasoning overview cards.
- Regression suite: 72 / 72 tests passed.

## Clockwise candidate-world board
- Candidate-world seat displays now mirror the main board: left seats on the left, right seats on the right, and self at the bottom center.
- Added an explicit clockwise-order hint so neighbour relationships are visually obvious.
- Dead seats are dimmed/dashed in candidate worlds.
- Candidate-world Demon labels now recognize any current Demon character, not only Imp.

## Game-over result selection

- `ゲーム終了` now asks for `デーモン勝利`, `町勝利`, or `特殊条件勝利`.
- Finished game logs store the selected result immediately.
- Added `special` as a backwards-compatible game-log outcome.
- Game Log labels now use the same result terminology.
- Ending a game clears the active resume snapshot/checkpoints after the finished log is safely saved.
